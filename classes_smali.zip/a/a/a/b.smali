.class public final La/a/a/b;
.super La/a/a;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, La/a/a;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, La/a/a;-><init>(Ljava/lang/String;)V

    return-void
.end method
