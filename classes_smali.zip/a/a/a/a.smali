.class public final La/a/a/a;
.super La/a/a;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, La/a/a;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .registers 3

    invoke-direct {p0, p1, p2}, La/a/a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
