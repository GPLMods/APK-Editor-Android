.class public final La/a/b/b/g;
.super Ljava/lang/Object;

# interfaces
.implements La/a/b/b/k;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static a(Landroid/graphics/Bitmap;III)V
    .registers 5

    :goto_0
    if-gt p2, p3, :cond_a

    const/high16 v0, -0x1000000

    invoke-virtual {p0, p2, p1, v0}, Landroid/graphics/Bitmap;->setPixel(III)V

    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_a
    return-void
.end method

.method private static a(Ljava/io/DataInput;)V
    .registers 4

    const/16 v0, 0x8

    invoke-interface {p0, v0}, Ljava/io/DataInput;->skipBytes(I)I

    :goto_5
    :try_start_5
    invoke-interface {p0}, Ljava/io/DataInput;->readInt()I
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_8} :catch_13

    move-result v0

    invoke-interface {p0}, Ljava/io/DataInput;->readInt()I

    move-result v1

    const v2, 0x6e705463

    if-ne v1, v2, :cond_1c

    return-void

    :catch_13
    move-exception v0

    new-instance v1, La/a/a/a;

    const-string v2, "Cant find nine patch chunk"

    invoke-direct {v1, v2, v0}, La/a/a/a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1

    :cond_1c
    add-int/lit8 v0, v0, 0x4

    invoke-interface {p0, v0}, Ljava/io/DataInput;->skipBytes(I)I

    goto :goto_5
.end method

.method private static b(Landroid/graphics/Bitmap;III)V
    .registers 5

    :goto_0
    if-gt p2, p3, :cond_a

    const/high16 v0, -0x1000000

    invoke-virtual {p0, p1, p2, v0}, Landroid/graphics/Bitmap;->setPixel(III)V

    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_a
    return-void
.end method


# virtual methods
.method public final a(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    .registers 16

    const/4 v7, 0x0

    :try_start_1
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    invoke-static {p1, v0}, Lcom/gmail/heagoo/a/c/a;->b(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0

    const/4 v1, 0x0

    array-length v2, v0

    invoke-static {v0, v1, v2}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v9

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v10

    add-int/lit8 v2, v9, 0x2

    add-int/lit8 v3, v10, 0x2

    sget-object v4, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v2, v3, v4}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v11

    new-instance v2, Landroid/graphics/Canvas;

    invoke-direct {v2, v11}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    new-instance v3, Landroid/graphics/Paint;

    invoke-direct {v3}, Landroid/graphics/Paint;-><init>()V

    const/high16 v4, 0x3f800000  # 1.0f

    const/high16 v5, 0x3f800000  # 1.0f

    invoke-virtual {v2, v1, v4, v5, v3}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V
    :try_end_36
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_36} :catch_f4

    const/4 v8, 0x0

    :try_start_37
    new-instance v6, La/d/f;

    new-instance v1, Ljava/io/ByteArrayInputStream;

    invoke-direct {v1, v0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-direct {v6, v1}, La/d/f;-><init>(Ljava/io/InputStream;)V

    invoke-static {v6}, La/a/b/b/g;->a(Ljava/io/DataInput;)V

    const/4 v0, 0x1

    invoke-virtual {v6, v0}, La/d/f;->skipBytes(I)I

    invoke-virtual {v6}, La/d/f;->readByte()B

    move-result v0

    invoke-virtual {v6}, La/d/f;->readByte()B

    move-result v12

    const/4 v1, 0x1

    invoke-virtual {v6, v1}, La/d/f;->skipBytes(I)I

    const/16 v1, 0x8

    invoke-virtual {v6, v1}, La/d/f;->skipBytes(I)I

    invoke-virtual {v6}, La/d/f;->readInt()I

    move-result v1

    invoke-virtual {v6}, La/d/f;->readInt()I

    move-result v2

    invoke-virtual {v6}, La/d/f;->readInt()I

    move-result v3

    invoke-virtual {v6}, La/d/f;->readInt()I

    move-result v4

    const/4 v5, 0x4

    invoke-virtual {v6, v5}, La/d/f;->skipBytes(I)I

    invoke-virtual {v6, v0}, La/d/f;->a(I)[I

    move-result-object v5

    invoke-virtual {v6, v12}, La/d/f;->a(I)[I

    move-result-object v6

    new-instance v0, La/a/b/b/h;

    invoke-direct/range {v0 .. v6}, La/a/b/b/h;-><init>(IIII[I[I)V
    :try_end_7a
    .catch Ljava/lang/Exception; {:try_start_37 .. :try_end_7a} :catch_b5
    .catch Ljava/io/IOException; {:try_start_37 .. :try_end_7a} :catch_f4

    move-object v1, v0

    :goto_7b
    if-eqz v1, :cond_d6

    add-int/lit8 v0, v10, 0x1

    :try_start_7f
    iget v2, v1, La/a/b/b/h;->a:I

    add-int/lit8 v2, v2, 0x1

    iget v3, v1, La/a/b/b/h;->b:I

    sub-int v3, v9, v3

    invoke-static {v11, v0, v2, v3}, La/a/b/b/g;->a(Landroid/graphics/Bitmap;III)V

    add-int/lit8 v0, v9, 0x1

    iget v2, v1, La/a/b/b/h;->c:I

    add-int/lit8 v2, v2, 0x1

    iget v3, v1, La/a/b/b/h;->d:I

    sub-int v3, v10, v3

    invoke-static {v11, v0, v2, v3}, La/a/b/b/g;->b(Landroid/graphics/Bitmap;III)V

    iget-object v2, v1, La/a/b/b/h;->e:[I

    move v0, v7

    array-length v3, v2

    if-nez v3, :cond_a4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v11, v3, v4, v9}, La/a/b/b/g;->a(Landroid/graphics/Bitmap;III)V

    goto :goto_b8

    :goto_a3
    array-length v3, v2

    :cond_a4
    if-ge v0, v3, :cond_b8

    const/4 v3, 0x0

    aget v4, v2, v0

    add-int/lit8 v4, v4, 0x1

    add-int/lit8 v5, v0, 0x1

    aget v5, v2, v5

    invoke-static {v11, v3, v4, v5}, La/a/b/b/g;->a(Landroid/graphics/Bitmap;III)V

    add-int/lit8 v0, v0, 0x2

    goto :goto_a3

    :catch_b5
    move-exception v0

    move-object v1, v8

    goto :goto_7b

    :cond_b8
    :goto_b8
    iget-object v1, v1, La/a/b/b/h;->f:[I

    move v0, v7

    array-length v2, v1

    if-nez v2, :cond_c5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v11, v2, v3, v10}, La/a/b/b/g;->b(Landroid/graphics/Bitmap;III)V

    goto :goto_ec

    :goto_c4
    array-length v2, v1

    :cond_c5
    if-ge v0, v2, :cond_ec

    const/4 v2, 0x0

    aget v3, v1, v0

    add-int/lit8 v3, v3, 0x1

    add-int/lit8 v4, v0, 0x1

    aget v4, v1, v4

    invoke-static {v11, v2, v3, v4}, La/a/b/b/g;->b(Landroid/graphics/Bitmap;III)V

    add-int/lit8 v0, v0, 0x2

    goto :goto_c4

    :cond_d6
    add-int/lit8 v0, v10, 0x1

    const/4 v1, 0x1

    invoke-static {v11, v0, v1, v9}, La/a/b/b/g;->a(Landroid/graphics/Bitmap;III)V

    add-int/lit8 v0, v9, 0x1

    const/4 v1, 0x1

    invoke-static {v11, v0, v1, v10}, La/a/b/b/g;->b(Landroid/graphics/Bitmap;III)V

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {v11, v0, v1, v9}, La/a/b/b/g;->a(Landroid/graphics/Bitmap;III)V

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {v11, v0, v1, v10}, La/a/b/b/g;->b(Landroid/graphics/Bitmap;III)V

    :cond_ec
    :goto_ec
    sget-object v0, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v1, 0x64

    invoke-virtual {v11, v0, v1, p2}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z
    :try_end_f3
    .catch Ljava/io/IOException; {:try_start_7f .. :try_end_f3} :catch_f4

    return-void

    :catch_f4
    move-exception v0

    new-instance v1, La/a/a;

    invoke-direct {v1, v0}, La/a/a;-><init>(Ljava/lang/Throwable;)V

    throw v1
.end method
