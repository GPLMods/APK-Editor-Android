.class public final La/a/b/b/d;
.super Ljava/lang/Object;


# instance fields
.field public final a:S

.field public final b:I

.field public final c:I


# direct methods
.method private constructor <init>(SIII)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-short p1, p0, La/a/b/b/d;->a:S

    iput p4, p0, La/a/b/b/d;->b:I

    add-int v0, p4, p3

    iput v0, p0, La/a/b/b/d;->c:I

    return-void
.end method

.method public static a(La/d/f;La/a/b/a/a;)La/a/b/b/d;
    .registers 9

    const/4 v6, 0x0

    invoke-virtual {p1}, La/a/b/a/a;->a()I

    move-result v1

    const/16 v0, 0x8

    :try_start_7
    new-array v0, v0, [B

    invoke-virtual {p0, v0}, La/d/f;->readFully([B)V

    const/4 v2, 0x1

    aget-byte v2, v0, v2

    and-int/lit16 v2, v2, 0xff

    shl-int/lit8 v2, v2, 0x8

    const/4 v3, 0x0

    aget-byte v3, v0, v3

    and-int/lit16 v3, v3, 0xff

    or-int/2addr v2, v3

    int-to-short v2, v2

    const/4 v3, 0x3

    aget-byte v3, v0, v3

    and-int/lit16 v3, v3, 0xff

    shl-int/lit8 v3, v3, 0x8

    const/4 v4, 0x2

    aget-byte v4, v0, v4

    and-int/lit16 v4, v4, 0xff

    or-int/2addr v3, v4

    const/4 v4, 0x7

    aget-byte v4, v0, v4

    and-int/lit16 v4, v4, 0xff

    shl-int/lit8 v4, v4, 0x18

    const/4 v5, 0x6

    aget-byte v5, v0, v5

    and-int/lit16 v5, v5, 0xff

    shl-int/lit8 v5, v5, 0x10

    or-int/2addr v4, v5

    const/4 v5, 0x5

    aget-byte v5, v0, v5

    and-int/lit16 v5, v5, 0xff

    shl-int/lit8 v5, v5, 0x8

    or-int/2addr v4, v5

    const/4 v5, 0x4

    aget-byte v0, v0, v5

    and-int/lit16 v0, v0, 0xff

    or-int/2addr v4, v0

    new-instance v0, La/a/b/b/d;

    invoke-direct {v0, v2, v3, v4, v1}, La/a/b/b/d;-><init>(SIII)V
    :try_end_49
    .catch Ljava/io/EOFException; {:try_start_7 .. :try_end_49} :catch_4a

    :goto_49
    return-object v0

    :catch_4a
    move-exception v0

    new-instance v0, La/a/b/b/d;

    const/4 v1, -0x1

    invoke-virtual {p1}, La/a/b/a/a;->a()I

    move-result v2

    invoke-direct {v0, v1, v6, v6, v2}, La/a/b/b/d;-><init>(SIII)V

    goto :goto_49
.end method
