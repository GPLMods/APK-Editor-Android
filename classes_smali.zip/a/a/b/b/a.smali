.class public La/a/b/b/a;
.super Ljava/lang/Object;


# static fields
.field private static final u:Ljava/util/logging/Logger;


# instance fields
.field private a:La/a/b/b/m;

.field private b:[Z

.field private c:Z

.field private d:Z

.field private e:[B

.field private final f:La/d/f;

.field private final g:Lcom/gmail/heagoo/a/c/a;

.field private final h:La/a/b/a/a;

.field private final i:Ljava/util/List;

.field private final j:Z

.field private k:La/a/b/b/d;

.field private l:La/a/b/b/n;

.field private m:La/a/b/b/n;

.field private n:La/a/b/b/n;

.field private o:La/a/b/a/e;

.field private p:La/a/b/a/i;

.field private q:La/a/b/a/h;

.field private r:I

.field private s:[Z

.field private t:Ljava/util/HashMap;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, La/a/b/b/a;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v0

    sput-object v0, La/a/b/b/a;->u:Ljava/util/logging/Logger;

    return-void
.end method

.method private constructor <init>(Ljava/io/InputStream;Lcom/gmail/heagoo/a/c/a;La/a/b/b/m;ZZZ)V
    .registers 10

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xc

    new-array v0, v0, [B

    iput-object v0, p0, La/a/b/b/a;->e:[B

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, La/a/b/b/a;->t:Ljava/util/HashMap;

    iput-object p3, p0, La/a/b/b/a;->a:La/a/b/b/m;

    iput-boolean p6, p0, La/a/b/b/a;->d:Z

    new-instance v0, La/a/b/a/a;

    invoke-direct {v0, p1}, La/a/b/a/a;-><init>(Ljava/io/InputStream;)V

    iput-object v0, p0, La/a/b/b/a;->h:La/a/b/a/a;

    if-eqz p4, :cond_35

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La/a/b/b/a;->i:Ljava/util/List;

    :goto_24
    new-instance v1, La/d/f;

    new-instance v2, La/a/b/a/b;

    invoke-direct {v2, v0}, La/a/b/a/b;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v1, v2}, La/d/f;-><init>(La/a/b/a/b;)V

    iput-object v1, p0, La/a/b/b/a;->f:La/d/f;

    iput-object p2, p0, La/a/b/b/a;->g:Lcom/gmail/heagoo/a/c/a;

    iput-boolean p5, p0, La/a/b/b/a;->j:Z

    return-void

    :cond_35
    const/4 v1, 0x0

    iput-object v1, p0, La/a/b/b/a;->i:Ljava/util/List;

    goto :goto_24
.end method

.method private a(BI)La/a/b/a/a/p;
    .registers 8

    const/4 v2, 0x0

    const-string v1, ""

    const-string v0, ""

    iget v3, p0, La/a/b/b/a;->r:I

    const/high16 v4, -0x1000000

    and-int/2addr v3, v4

    const/high16 v4, 0x1000000

    if-eq v3, v4, :cond_6f

    iget-object v0, p0, La/a/b/b/a;->l:La/a/b/b/n;

    invoke-virtual {v0, p2}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v1

    iget-object v0, p0, La/a/b/b/a;->l:La/a/b/b/n;

    invoke-virtual {v0, p2, v1}, La/a/b/b/n;->b(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, La/a/b/b/a;->l:La/a/b/b/n;

    invoke-virtual {v2}, La/a/b/b/n;->b()Z

    move-result v2

    move v3, v2

    move-object v2, v1

    move-object v1, v0

    :goto_23
    const/4 v0, 0x3

    if-ne p1, v0, :cond_63

    iget-object v0, p0, La/a/b/b/a;->o:La/a/b/a/e;

    invoke-virtual {v0}, La/a/b/a/e;->g()La/a/b/a/a/x;

    iget-boolean v0, p0, La/a/b/b/a;->c:Z

    if-eqz v1, :cond_37

    const-string v4, ""

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3d

    :cond_37
    new-instance v0, La/a/b/a/a/u;

    invoke-direct {v0, v1, p2}, La/a/b/a/a/u;-><init>(Ljava/lang/String;I)V

    :goto_3c
    return-object v0

    :cond_3d
    if-nez v0, :cond_57

    const-string v0, "res/"

    invoke-virtual {v1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_57

    const-string v0, "r/"

    invoke-virtual {v1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_57

    const-string v0, "R/"

    invoke-virtual {v1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_5d

    :cond_57
    new-instance v0, La/a/b/a/a/i;

    invoke-direct {v0, v2, p2}, La/a/b/a/a/i;-><init>(Ljava/lang/String;I)V

    goto :goto_3c

    :cond_5d
    new-instance v0, La/a/b/a/a/u;

    invoke-direct {v0, v1, p2, v2, v3}, La/a/b/a/a/u;-><init>(Ljava/lang/String;ILjava/lang/String;Z)V

    goto :goto_3c

    :cond_63
    iget-object v0, p0, La/a/b/b/a;->o:La/a/b/a/e;

    invoke-virtual {v0}, La/a/b/a/e;->g()La/a/b/a/a/x;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, p1, p2, v1}, La/a/b/a/a/x;->a(IILjava/lang/String;)La/a/b/a/a/t;

    move-result-object v0

    goto :goto_3c

    :cond_6f
    move v3, v2

    move-object v2, v1

    move-object v1, v0

    goto :goto_23
.end method

.method public static a(Ljava/io/InputStream;ZZLcom/gmail/heagoo/a/c/a;La/a/b/b/m;Z)La/a/b/b/b;
    .registers 20

    :try_start_0
    new-instance v1, La/a/b/b/a;

    const/4 v5, 0x0

    move-object v2, p0

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move/from16 v6, p2

    move/from16 v7, p5

    invoke-direct/range {v1 .. v7}, La/a/b/b/a;-><init>(Ljava/io/InputStream;Lcom/gmail/heagoo/a/c/a;La/a/b/b/m;ZZZ)V

    invoke-direct {v1}, La/a/b/b/a;->f()La/a/b/b/d;

    const/4 v2, 0x2

    invoke-direct {v1, v2}, La/a/b/b/a;->b(I)V

    iget-object v2, v1, La/a/b/b/a;->f:La/d/f;

    invoke-virtual {v2}, La/d/f;->readInt()I

    move-result v6

    iget-object v2, v1, La/a/b/b/a;->f:La/d/f;

    invoke-static {v2}, La/a/b/b/n;->a(La/d/f;)La/a/b/b/n;

    move-result-object v2

    iput-object v2, v1, La/a/b/b/a;->l:La/a/b/b/n;

    new-array v7, v6, [La/a/b/a/e;

    invoke-direct {v1}, La/a/b/b/a;->f()La/a/b/b/d;

    const/4 v2, 0x0

    move v5, v2

    :goto_2b
    if-ge v5, v6, :cond_1e2

    const/16 v2, 0x200

    invoke-direct {v1, v2}, La/a/b/b/a;->b(I)V

    iget-object v2, v1, La/a/b/b/a;->f:La/d/f;

    invoke-virtual {v2}, La/d/f;->readInt()I

    move-result v2

    int-to-byte v2, v2

    if-nez v2, :cond_1fb

    const/4 v2, 0x2

    move v4, v2

    :goto_3d
    iget-object v2, v1, La/a/b/b/a;->f:La/d/f;

    const/16 v3, 0x80

    const/4 v8, 0x1

    invoke-virtual {v2, v3, v8}, La/d/f;->a(IZ)Ljava/lang/String;

    move-result-object v8

    iget-object v2, v1, La/a/b/b/a;->f:La/d/f;

    const/4 v3, 0x4

    invoke-virtual {v2, v3}, La/d/f;->skipBytes(I)I

    iget-object v2, v1, La/a/b/b/a;->f:La/d/f;

    const/4 v3, 0x4

    invoke-virtual {v2, v3}, La/d/f;->skipBytes(I)I

    iget-object v2, v1, La/a/b/b/a;->f:La/d/f;

    const/4 v3, 0x4

    invoke-virtual {v2, v3}, La/d/f;->skipBytes(I)I

    iget-object v2, v1, La/a/b/b/a;->f:La/d/f;

    const/4 v3, 0x4

    invoke-virtual {v2, v3}, La/d/f;->skipBytes(I)I

    iget-object v2, v1, La/a/b/b/a;->f:La/d/f;

    invoke-static {v2}, La/a/b/b/n;->a(La/d/f;)La/a/b/b/n;

    move-result-object v2

    iput-object v2, v1, La/a/b/b/a;->m:La/a/b/b/n;

    iget-object v2, v1, La/a/b/b/a;->f:La/d/f;

    invoke-static {v2}, La/a/b/b/n;->a(La/d/f;)La/a/b/b/n;

    move-result-object v2

    iput-object v2, v1, La/a/b/b/a;->n:La/a/b/b/n;

    iget-boolean v2, v1, La/a/b/b/a;->d:Z

    if-eqz v2, :cond_133

    const/4 v3, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v9, 0x5f

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v9, 0x72

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v9, 0x72

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const/4 v2, 0x0

    move v13, v2

    move v2, v3

    move v3, v13

    :goto_8f
    iget-object v10, v1, La/a/b/b/a;->n:La/a/b/b/n;

    invoke-virtual {v10}, La/a/b/b/n;->a()I

    move-result v10

    if-ge v3, v10, :cond_133

    iget-object v10, v1, La/a/b/b/a;->n:La/a/b/b/n;

    invoke-virtual {v10, v3}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v10

    if-eqz v10, :cond_ca

    const-string v11, ""

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_ca

    const-string v11, "[a-zA-Z0-9_\\.]+"

    invoke-virtual {v10, v11}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v11

    if-nez v11, :cond_ca

    iget-object v10, v1, La/a/b/b/a;->n:La/a/b/b/n;

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v3, v11}, La/a/b/b/n;->a(ILjava/lang/String;)V

    add-int/lit8 v2, v2, 0x1

    :cond_c7
    :goto_c7
    add-int/lit8 v3, v3, 0x1

    goto :goto_8f

    :cond_ca
    const-string v11, "do"

    invoke-virtual {v11, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_ed

    iget-object v10, v1, La/a/b/b/a;->n:La/a/b/b/n;

    new-instance v11, Ljava/lang/StringBuilder;

    const-string v12, "do"

    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v3, v11}, La/a/b/b/n;->a(ILjava/lang/String;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_c7

    :cond_ed
    const-string v11, "if"

    invoke-virtual {v11, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_110

    iget-object v10, v1, La/a/b/b/a;->n:La/a/b/b/n;

    new-instance v11, Ljava/lang/StringBuilder;

    const-string v12, "if"

    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v3, v11}, La/a/b/b/n;->a(ILjava/lang/String;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_c7

    :cond_110
    const-string v11, "for"

    invoke-virtual {v11, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_c7

    iget-object v10, v1, La/a/b/b/a;->n:La/a/b/b/n;

    new-instance v11, Ljava/lang/StringBuilder;

    const-string v12, "for"

    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v3, v11}, La/a/b/b/n;->a(ILjava/lang/String;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_c7

    :cond_133
    iget-object v2, v1, La/a/b/b/a;->m:La/a/b/b/n;

    invoke-virtual {v2}, La/a/b/b/n;->a()I

    move-result v2

    add-int/lit8 v2, v2, 0x20

    new-array v2, v2, [Z

    iput-object v2, v1, La/a/b/b/a;->b:[Z

    iget-object v2, v1, La/a/b/b/a;->b:[Z

    const/4 v3, 0x0

    invoke-static {v2, v3}, Ljava/util/Arrays;->fill([ZZ)V

    const/4 v2, 0x0

    :goto_146
    iget-object v3, v1, La/a/b/b/a;->m:La/a/b/b/n;

    invoke-virtual {v3}, La/a/b/b/n;->a()I

    move-result v3

    if-ge v2, v3, :cond_1ac

    iget-object v3, v1, La/a/b/b/a;->m:La/a/b/b/n;

    invoke-virtual {v3, v2}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v3

    const-string v9, "ani"

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1a4

    const-string v9, "animator"

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1a4

    const-string v9, "drawable"

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1a4

    const-string v9, "interpolator"

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1a4

    const-string v9, "layout"

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1a4

    const-string v9, "menu"

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1a4

    const-string v9, "mipmap"

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1a4

    const-string v9, "raw"

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1a4

    const-string v9, "transition"

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1a4

    const-string v9, "xml"

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1a9

    :cond_1a4
    iget-object v3, v1, La/a/b/b/a;->b:[Z

    const/4 v9, 0x1

    aput-boolean v9, v3, v2

    :cond_1a9
    add-int/lit8 v2, v2, 0x1

    goto :goto_146

    :cond_1ac
    shl-int/lit8 v2, v4, 0x18

    iput v2, v1, La/a/b/b/a;->r:I

    new-instance v2, La/a/b/a/e;

    iget-object v3, v1, La/a/b/b/a;->g:Lcom/gmail/heagoo/a/c/a;

    invoke-direct {v2, v3, v4, v8}, La/a/b/a/e;-><init>(Lcom/gmail/heagoo/a/c/a;ILjava/lang/String;)V

    iput-object v2, v1, La/a/b/b/a;->o:La/a/b/a/e;

    invoke-direct {v1}, La/a/b/b/a;->f()La/a/b/b/d;

    const/4 v0, 0x1

    :goto_1bd
    if-eqz v0, :cond_1d9

    iget-object v2, v1, La/a/b/b/a;->k:La/a/b/b/d;

    iget-short v2, v2, La/a/b/b/d;->a:S

    packed-switch v2, :pswitch_data_1fe

    const/4 v0, 0x0

    goto :goto_1bd

    :pswitch_1c8  #0x203
    invoke-direct {v1}, La/a/b/b/a;->a()V

    goto :goto_1bd

    :pswitch_1cc  #0x202
    invoke-direct {v1}, La/a/b/b/a;->b()La/a/b/a/i;

    goto :goto_1bd
    :try_end_1d0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_1d0} :catch_1d0

    :catch_1d0
    move-exception v1

    new-instance v2, La/a/a;

    const-string v3, "Could not decode arsc file"

    invoke-direct {v2, v3, v1}, La/a/a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v2

    :cond_1d9
    :try_start_1d9
    iget-object v2, v1, La/a/b/b/a;->o:La/a/b/a/e;

    aput-object v2, v7, v5

    add-int/lit8 v2, v5, 0x1

    move v5, v2

    goto/16 :goto_2b

    :cond_1e2
    new-instance v2, La/a/b/b/b;

    iget-object v3, v1, La/a/b/b/a;->i:Ljava/util/List;

    if-nez v3, :cond_1ef

    const/4 v1, 0x0

    :goto_1e9
    move-object/from16 v0, p3

    invoke-direct {v2, v7, v1, v0}, La/a/b/b/b;-><init>([La/a/b/a/e;[La/a/b/b/c;Lcom/gmail/heagoo/a/c/a;)V

    return-object v2

    :cond_1ef
    iget-object v1, v1, La/a/b/b/a;->i:Ljava/util/List;

    const/4 v3, 0x0

    new-array v3, v3, [La/a/b/b/c;

    invoke-interface {v1, v3}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [La/a/b/b/c;
    :try_end_1fa
    .catch Ljava/io/IOException; {:try_start_1d9 .. :try_end_1fa} :catch_1d0

    goto :goto_1e9

    :cond_1fb
    move v4, v2

    goto/16 :goto_3d

    :pswitch_data_1fe
    .packed-switch 0x202
        :pswitch_1cc  #00000202
        :pswitch_1c8  #00000203
    .end packed-switch
.end method

.method private a(I)Ljava/lang/String;
    .registers 5

    new-instance v1, Ljava/lang/StringBuilder;

    const/16 v0, 0x10

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    :goto_7
    add-int/lit8 v0, p1, -0x1

    if-eqz p1, :cond_1a

    iget-object v2, p0, La/a/b/b/a;->f:La/d/f;

    invoke-virtual {v2}, La/d/f;->readByte()B

    move-result v2

    int-to-short v2, v2

    if-eqz v2, :cond_1a

    int-to-char v2, v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move p1, v0

    goto :goto_7

    :cond_1a
    iget-object v2, p0, La/a/b/b/a;->f:La/d/f;

    invoke-virtual {v2, v0}, La/d/f;->skipBytes(I)I

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private a(II)Ljava/lang/String;
    .registers 4

    iget-object v0, p0, La/a/b/b/a;->a:La/a/b/b/m;

    if-nez v0, :cond_b

    iget-object v0, p0, La/a/b/b/a;->n:La/a/b/b/n;

    invoke-virtual {v0, p2}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v0

    :cond_a
    :goto_a
    return-object v0

    :cond_b
    iget-object v0, p0, La/a/b/b/a;->a:La/a/b/b/m;

    invoke-interface {v0, p1}, La/a/b/b/m;->a(I)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_a

    iget-object v0, p0, La/a/b/b/a;->n:La/a/b/b/n;

    invoke-virtual {v0, p2}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_a
.end method

.method private a()V
    .registers 10

    const/4 v8, 0x1

    const/4 v1, 0x0

    const/16 v0, 0x203

    invoke-direct {p0, v0}, La/a/b/b/a;->b(I)V

    iget-object v0, p0, La/a/b/b/a;->f:La/d/f;

    invoke-virtual {v0}, La/d/f;->readInt()I

    move-result v2

    move v0, v1

    :goto_e
    if-ge v0, v2, :cond_37

    iget-object v3, p0, La/a/b/b/a;->f:La/d/f;

    invoke-virtual {v3}, La/d/f;->readInt()I

    move-result v3

    iget-object v4, p0, La/a/b/b/a;->f:La/d/f;

    const/16 v5, 0x80

    invoke-virtual {v4, v5, v8}, La/d/f;->a(IZ)Ljava/lang/String;

    move-result-object v4

    sget-object v5, La/a/b/b/a;->u:Ljava/util/logging/Logger;

    const-string v6, "Decoding (%s), pkgId: %d"

    const/4 v7, 0x2

    new-array v7, v7, [Ljava/lang/Object;

    aput-object v4, v7, v1

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v7, v8

    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v3}, Ljava/util/logging/Logger;->info(Ljava/lang/String;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_e

    :cond_37
    :goto_37
    invoke-direct {p0}, La/a/b/b/a;->f()La/a/b/b/d;

    move-result-object v0

    iget-short v0, v0, La/a/b/b/d;->a:S

    const/16 v1, 0x201

    if-ne v0, v1, :cond_45

    invoke-direct {p0}, La/a/b/b/a;->b()La/a/b/a/i;

    goto :goto_37

    :cond_45
    return-void
.end method

.method private a(La/a/b/a/i;)V
    .registers 4

    iget-object v0, p0, La/a/b/b/a;->t:Ljava/util/HashMap;

    invoke-virtual {p1}, La/a/b/a/i;->b()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private static a(BBC)[C
    .registers 10

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x1

    shr-int/lit8 v0, p0, 0x7

    and-int/lit8 v0, v0, 0x1

    if-ne v0, v4, :cond_2a

    and-int/lit8 v1, p1, 0x1f

    and-int/lit16 v0, p1, 0xe0

    shr-int/lit8 v0, v0, 0x5

    and-int/lit8 v2, p0, 0x3

    shl-int/lit8 v2, v2, 0x3

    add-int/2addr v2, v0

    and-int/lit8 v0, p0, 0x7c

    shr-int/lit8 v3, v0, 0x2

    const/4 v0, 0x3

    new-array v0, v0, [C

    add-int/2addr v1, p2

    int-to-char v1, v1

    aput-char v1, v0, v5

    add-int v1, v2, p2

    int-to-char v1, v1

    aput-char v1, v0, v4

    add-int v1, v3, p2

    int-to-char v1, v1

    aput-char v1, v0, v6

    :goto_29
    return-object v0

    :cond_2a
    new-array v0, v6, [C

    int-to-char v1, p0

    aput-char v1, v0, v5

    int-to-char v1, p1

    aput-char v1, v0, v4

    goto :goto_29
.end method

.method private b()La/a/b/a/i;
    .registers 35

    invoke-direct/range {p0 .. p0}, La/a/b/b/a;->c()La/a/b/a/i;

    move-result-object v4

    move-object/from16 v0, p0

    iput-object v4, v0, La/a/b/b/a;->p:La/a/b/a/i;

    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->p:La/a/b/a/i;

    move-object/from16 v0, p0

    invoke-direct {v0, v4}, La/a/b/b/a;->a(La/a/b/a/i;)V

    invoke-direct/range {p0 .. p0}, La/a/b/b/a;->f()La/a/b/b/d;

    move-result-object v4

    iget-short v4, v4, La/a/b/b/d;->a:S

    :goto_17
    const/16 v5, 0x202

    if-ne v4, v5, :cond_5f

    invoke-direct/range {p0 .. p0}, La/a/b/b/a;->c()La/a/b/a/i;

    move-result-object v4

    move-object/from16 v0, p0

    invoke-direct {v0, v4}, La/a/b/b/a;->a(La/a/b/a/i;)V

    invoke-direct/range {p0 .. p0}, La/a/b/b/a;->f()La/a/b/b/d;

    move-result-object v4

    iget-short v4, v4, La/a/b/b/d;->a:S

    goto :goto_17

    :cond_2b
    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->q:La/a/b/a/h;

    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->h:La/a/b/a/a;

    invoke-virtual {v4}, La/a/b/a/a;->a()I

    move-result v4

    move-object/from16 v0, p0

    iget-object v5, v0, La/a/b/b/a;->k:La/a/b/b/d;

    iget v5, v5, La/a/b/b/d;->c:I

    if-ge v4, v5, :cond_56

    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->h:La/a/b/a/a;

    move-object/from16 v0, p0

    iget-object v5, v0, La/a/b/b/a;->k:La/a/b/b/d;

    iget v5, v5, La/a/b/b/d;->c:I

    move-object/from16 v0, p0

    iget-object v6, v0, La/a/b/b/a;->h:La/a/b/a/a;

    invoke-virtual {v6}, La/a/b/a/a;->a()I

    move-result v6

    sub-int/2addr v5, v6

    int-to-long v6, v5

    invoke-virtual {v4, v6, v7}, La/a/b/a/a;->skip(J)J

    :cond_56
    invoke-direct/range {p0 .. p0}, La/a/b/b/a;->f()La/a/b/b/d;

    move-result-object v4

    iget-short v4, v4, La/a/b/b/d;->a:S

    invoke-direct/range {p0 .. p0}, La/a/b/b/a;->e()V

    :cond_5f
    const/16 v5, 0x201

    if-ne v4, v5, :cond_400

    const/16 v4, 0x201

    move-object/from16 v0, p0

    invoke-direct {v0, v4}, La/a/b/b/a;->b(I)V

    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->f:La/d/f;

    move-object/from16 v0, p0

    iget-object v5, v0, La/a/b/b/a;->e:[B

    invoke-virtual {v4, v5}, La/d/f;->readFully([B)V

    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->e:[B

    const/4 v5, 0x0

    aget-byte v4, v4, v5

    and-int/lit16 v5, v4, 0xff

    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->t:Ljava/util/HashMap;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_be

    const/high16 v4, -0x1000000

    move-object/from16 v0, p0

    iget v6, v0, La/a/b/b/a;->r:I

    and-int/2addr v6, v4

    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->t:Ljava/util/HashMap;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v4, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/a/b/a/i;

    invoke-virtual {v4}, La/a/b/a/i;->b()I

    move-result v4

    shl-int/lit8 v4, v4, 0x10

    or-int/2addr v4, v6

    move-object/from16 v0, p0

    iput v4, v0, La/a/b/b/a;->r:I

    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->t:Ljava/util/HashMap;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/a/b/a/i;

    move-object/from16 v0, p0

    iput-object v4, v0, La/a/b/b/a;->p:La/a/b/a/i;

    :cond_be
    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->b:[Z

    array-length v4, v4

    if-ge v5, v4, :cond_159

    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->b:[Z

    add-int/lit8 v5, v5, -0x1

    aget-boolean v4, v4, v5

    move-object/from16 v0, p0

    iput-boolean v4, v0, La/a/b/b/a;->c:Z

    :goto_d1
    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->e:[B

    const/4 v5, 0x7

    aget-byte v4, v4, v5

    and-int/lit16 v4, v4, 0xff

    shl-int/lit8 v4, v4, 0x18

    move-object/from16 v0, p0

    iget-object v5, v0, La/a/b/b/a;->e:[B

    const/4 v6, 0x6

    aget-byte v5, v5, v6

    and-int/lit16 v5, v5, 0xff

    shl-int/lit8 v5, v5, 0x10

    or-int/2addr v4, v5

    move-object/from16 v0, p0

    iget-object v5, v0, La/a/b/b/a;->e:[B

    const/4 v6, 0x5

    aget-byte v5, v5, v6

    and-int/lit16 v5, v5, 0xff

    shl-int/lit8 v5, v5, 0x8

    or-int/2addr v4, v5

    move-object/from16 v0, p0

    iget-object v5, v0, La/a/b/b/a;->e:[B

    const/4 v6, 0x4

    aget-byte v5, v5, v6

    and-int/lit16 v5, v5, 0xff

    or-int v29, v4, v5

    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->e:[B

    const/16 v5, 0xb

    aget-byte v4, v4, v5

    and-int/lit16 v4, v4, 0xff

    shl-int/lit8 v4, v4, 0x18

    move-object/from16 v0, p0

    iget-object v5, v0, La/a/b/b/a;->e:[B

    const/16 v6, 0xa

    aget-byte v5, v5, v6

    and-int/lit16 v5, v5, 0xff

    shl-int/lit8 v5, v5, 0x10

    or-int/2addr v4, v5

    move-object/from16 v0, p0

    iget-object v5, v0, La/a/b/b/a;->e:[B

    const/16 v6, 0x9

    aget-byte v5, v5, v6

    and-int/lit16 v5, v5, 0xff

    shl-int/lit8 v5, v5, 0x8

    or-int/2addr v4, v5

    move-object/from16 v0, p0

    iget-object v5, v0, La/a/b/b/a;->e:[B

    const/16 v6, 0x8

    aget-byte v5, v5, v6

    and-int/lit16 v5, v5, 0xff

    or-int v30, v4, v5

    move/from16 v0, v29

    new-array v4, v0, [Z

    move-object/from16 v0, p0

    iput-object v4, v0, La/a/b/b/a;->s:[Z

    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->s:[Z

    const/4 v5, 0x1

    invoke-static {v4, v5}, Ljava/util/Arrays;->fill([ZZ)V

    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->f:La/d/f;

    invoke-virtual {v4}, La/d/f;->readInt()I

    move-result v28

    const/16 v4, 0x1c

    const/16 v5, 0x1c

    move/from16 v0, v28

    if-ge v0, v5, :cond_160

    new-instance v4, La/a/a;

    const-string v5, "Config size < 28"

    invoke-direct {v4, v5}, La/a/a;-><init>(Ljava/lang/String;)V

    throw v4

    :cond_159
    const/4 v4, 0x0

    move-object/from16 v0, p0

    iput-boolean v4, v0, La/a/b/b/a;->c:Z

    goto/16 :goto_d1

    :cond_160
    const/16 v27, 0x0

    const/16 v5, 0x18

    new-array v0, v5, [B

    move-object/from16 v17, v0

    move-object/from16 v0, p0

    iget-object v5, v0, La/a/b/b/a;->f:La/d/f;

    move-object/from16 v0, v17

    invoke-virtual {v5, v0}, La/d/f;->readFully([B)V

    const/4 v5, 0x1

    aget-byte v5, v17, v5

    and-int/lit16 v5, v5, 0xff

    shl-int/lit8 v5, v5, 0x8

    const/4 v6, 0x0

    aget-byte v6, v17, v6

    and-int/lit16 v6, v6, 0xff

    or-int/2addr v5, v6

    int-to-short v5, v5

    const/4 v6, 0x3

    aget-byte v6, v17, v6

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x8

    const/4 v7, 0x2

    aget-byte v7, v17, v7

    and-int/lit16 v7, v7, 0xff

    or-int/2addr v6, v7

    int-to-short v6, v6

    const/4 v7, 0x4

    aget-byte v7, v17, v7

    const/4 v8, 0x5

    aget-byte v8, v17, v8

    const/16 v9, 0x61

    invoke-static {v7, v8, v9}, La/a/b/b/a;->a(BBC)[C

    move-result-object v7

    const/4 v8, 0x6

    aget-byte v8, v17, v8

    const/4 v9, 0x7

    aget-byte v9, v17, v9

    const/16 v10, 0x30

    invoke-static {v8, v9, v10}, La/a/b/b/a;->a(BBC)[C

    move-result-object v8

    const/16 v9, 0x8

    aget-byte v9, v17, v9

    const/16 v10, 0x9

    aget-byte v10, v17, v10

    const/16 v11, 0xb

    aget-byte v11, v17, v11

    and-int/lit16 v11, v11, 0xff

    shl-int/lit8 v11, v11, 0x8

    const/16 v12, 0xa

    aget-byte v12, v17, v12

    and-int/lit16 v12, v12, 0xff

    or-int/2addr v11, v12

    const/16 v12, 0xc

    aget-byte v12, v17, v12

    const/16 v13, 0xd

    aget-byte v13, v17, v13

    const/16 v14, 0xe

    aget-byte v14, v17, v14

    const/16 v15, 0x11

    aget-byte v15, v17, v15

    and-int/lit16 v15, v15, 0xff

    shl-int/lit8 v15, v15, 0x8

    const/16 v16, 0x10

    aget-byte v16, v17, v16

    move/from16 v0, v16

    and-int/lit16 v0, v0, 0xff

    move/from16 v16, v0

    or-int v15, v15, v16

    int-to-short v15, v15

    const/16 v16, 0x13

    aget-byte v16, v17, v16

    move/from16 v0, v16

    and-int/lit16 v0, v0, 0xff

    move/from16 v16, v0

    shl-int/lit8 v16, v16, 0x8

    const/16 v18, 0x12

    aget-byte v18, v17, v18

    move/from16 v0, v18

    and-int/lit16 v0, v0, 0xff

    move/from16 v18, v0

    or-int v16, v16, v18

    move/from16 v0, v16

    int-to-short v0, v0

    move/from16 v16, v0

    const/16 v18, 0x15

    aget-byte v18, v17, v18

    move/from16 v0, v18

    and-int/lit16 v0, v0, 0xff

    move/from16 v18, v0

    shl-int/lit8 v18, v18, 0x8

    const/16 v19, 0x14

    aget-byte v17, v17, v19

    move/from16 v0, v17

    and-int/lit16 v0, v0, 0xff

    move/from16 v17, v0

    or-int v17, v17, v18

    move/from16 v0, v17

    int-to-short v0, v0

    move/from16 v17, v0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x20

    move/from16 v0, v28

    move/from16 v1, v21

    if-lt v0, v1, :cond_254

    const/4 v4, 0x4

    new-array v4, v4, [B

    move-object/from16 v0, p0

    iget-object v0, v0, La/a/b/b/a;->f:La/d/f;

    move-object/from16 v18, v0

    move-object/from16 v0, v18

    invoke-virtual {v0, v4}, La/d/f;->readFully([B)V

    const/16 v18, 0x0

    aget-byte v18, v4, v18

    const/16 v19, 0x1

    aget-byte v19, v4, v19

    const/16 v20, 0x3

    aget-byte v20, v4, v20

    move/from16 v0, v20

    and-int/lit16 v0, v0, 0xff

    move/from16 v20, v0

    shl-int/lit8 v20, v20, 0x8

    const/16 v21, 0x2

    aget-byte v4, v4, v21

    and-int/lit16 v4, v4, 0xff

    or-int v4, v4, v20

    int-to-short v0, v4

    move/from16 v20, v0

    const/16 v4, 0x20

    :cond_254
    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x24

    move/from16 v0, v28

    move/from16 v1, v23

    if-lt v0, v1, :cond_2a4

    const/4 v4, 0x4

    new-array v4, v4, [B

    move-object/from16 v0, p0

    iget-object v0, v0, La/a/b/b/a;->f:La/d/f;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    invoke-virtual {v0, v4}, La/d/f;->readFully([B)V

    const/16 v21, 0x1

    aget-byte v21, v4, v21

    move/from16 v0, v21

    and-int/lit16 v0, v0, 0xff

    move/from16 v21, v0

    shl-int/lit8 v21, v21, 0x8

    const/16 v22, 0x0

    aget-byte v22, v4, v22

    move/from16 v0, v22

    and-int/lit16 v0, v0, 0xff

    move/from16 v22, v0

    or-int v21, v21, v22

    move/from16 v0, v21

    int-to-short v0, v0

    move/from16 v21, v0

    const/16 v22, 0x3

    aget-byte v22, v4, v22

    move/from16 v0, v22

    and-int/lit16 v0, v0, 0xff

    move/from16 v22, v0

    shl-int/lit8 v22, v22, 0x8

    const/16 v23, 0x2

    aget-byte v4, v4, v23

    and-int/lit16 v4, v4, 0xff

    or-int v4, v4, v22

    int-to-short v0, v4

    move/from16 v22, v0

    const/16 v4, 0x24

    :cond_2a4
    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x30

    move/from16 v0, v28

    move/from16 v1, v25

    if-lt v0, v1, :cond_2c9

    const/4 v4, 0x4

    move-object/from16 v0, p0

    invoke-direct {v0, v4}, La/a/b/b/a;->a(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->toCharArray()[C

    move-result-object v23

    const/16 v4, 0x8

    move-object/from16 v0, p0

    invoke-direct {v0, v4}, La/a/b/b/a;->a(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->toCharArray()[C

    move-result-object v24

    const/16 v4, 0x30

    :cond_2c9
    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v31, 0x34

    move/from16 v0, v28

    move/from16 v1, v31

    if-lt v0, v1, :cond_2f2

    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->f:La/d/f;

    invoke-virtual {v4}, La/d/f;->readByte()B

    move-result v25

    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->f:La/d/f;

    invoke-virtual {v4}, La/d/f;->readByte()B

    move-result v26

    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->f:La/d/f;

    const/16 v31, 0x2

    move/from16 v0, v31

    invoke-virtual {v4, v0}, La/d/f;->skipBytes(I)I

    const/16 v4, 0x34

    :cond_2f2
    const/16 v31, 0x38

    move/from16 v0, v28

    move/from16 v1, v31

    if-lt v0, v1, :cond_307

    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->f:La/d/f;

    const/16 v31, 0x4

    move/from16 v0, v31

    invoke-virtual {v4, v0}, La/d/f;->skipBytes(I)I

    const/16 v4, 0x38

    :cond_307
    add-int/lit8 v31, v28, -0x38

    if-lez v31, :cond_333

    move/from16 v0, v31

    new-array v0, v0, [B

    move-object/from16 v32, v0

    add-int v4, v4, v31

    move-object/from16 v0, p0

    iget-object v0, v0, La/a/b/b/a;->f:La/d/f;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v32}, La/d/f;->readFully([B)V

    new-instance v31, Ljava/math/BigInteger;

    const/16 v33, 0x1

    move-object/from16 v0, v31

    move/from16 v1, v33

    move-object/from16 v2, v32

    invoke-direct {v0, v1, v2}, Ljava/math/BigInteger;-><init>(I[B)V

    sget-object v32, Ljava/math/BigInteger;->ZERO:Ljava/math/BigInteger;

    invoke-virtual/range {v31 .. v32}, Ljava/math/BigInteger;->equals(Ljava/lang/Object;)Z

    move-result v31

    if-nez v31, :cond_333

    const/16 v27, 0x1

    :cond_333
    sub-int v4, v28, v4

    if-lez v4, :cond_342

    move-object/from16 v0, p0

    iget-object v0, v0, La/a/b/b/a;->f:La/d/f;

    move-object/from16 v31, v0

    move-object/from16 v0, v31

    invoke-virtual {v0, v4}, La/d/f;->skipBytes(I)I

    :cond_342
    new-instance v4, La/a/b/a/c;

    invoke-direct/range {v4 .. v28}, La/a/b/a/c;-><init>(SS[C[CBBIBBBSSSBBSSS[C[CBBZI)V

    move-object/from16 v0, p0

    iget-object v5, v0, La/a/b/b/a;->k:La/a/b/b/d;

    iget v5, v5, La/a/b/b/d;->b:I

    add-int v5, v5, v30

    shl-int/lit8 v6, v29, 0x2

    sub-int/2addr v5, v6

    move-object/from16 v0, p0

    iget-object v6, v0, La/a/b/b/a;->h:La/a/b/a/a;

    invoke-virtual {v6}, La/a/b/a/a;->a()I

    move-result v6

    if-eq v5, v6, :cond_36c

    move-object/from16 v0, p0

    iget-object v6, v0, La/a/b/b/a;->f:La/d/f;

    move-object/from16 v0, p0

    iget-object v7, v0, La/a/b/b/a;->h:La/a/b/a/a;

    invoke-virtual {v7}, La/a/b/a/a;->a()I

    move-result v7

    sub-int/2addr v5, v7

    invoke-virtual {v6, v5}, La/d/f;->skipBytes(I)I

    :cond_36c
    move-object/from16 v0, p0

    iget-object v5, v0, La/a/b/b/a;->f:La/d/f;

    move/from16 v0, v29

    invoke-virtual {v5, v0}, La/d/f;->a(I)[I

    move-result-object v5

    iget-boolean v6, v4, La/a/b/a/c;->a:Z

    if-eqz v6, :cond_3b1

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v0, p0

    iget-object v7, v0, La/a/b/b/a;->p:La/a/b/a/i;

    invoke-virtual {v7}, La/a/b/a/i;->a()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v4}, La/a/b/a/c;->a()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    move-object/from16 v0, p0

    iget-boolean v7, v0, La/a/b/b/a;->j:Z

    if-eqz v7, :cond_3e2

    sget-object v7, La/a/b/b/a;->u:Ljava/util/logging/Logger;

    new-instance v8, Ljava/lang/StringBuilder;

    const-string v9, "Invalid config flags detected: "

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6}, Ljava/util/logging/Logger;->warning(Ljava/lang/String;)V

    :cond_3b1
    :goto_3b1
    iget-boolean v6, v4, La/a/b/a/c;->a:Z

    if-eqz v6, :cond_3f7

    move-object/from16 v0, p0

    iget-boolean v6, v0, La/a/b/b/a;->j:Z

    if-nez v6, :cond_3f7

    const/4 v4, 0x0

    :goto_3bc
    move-object/from16 v0, p0

    iput-object v4, v0, La/a/b/b/a;->q:La/a/b/a/h;

    const/4 v4, 0x0

    :goto_3c1
    array-length v6, v5

    if-ge v4, v6, :cond_2b

    aget v6, v5, v4

    const/4 v7, -0x1

    if-eq v6, v7, :cond_3df

    move-object/from16 v0, p0

    iget-object v6, v0, La/a/b/b/a;->s:[Z

    const/4 v7, 0x0

    aput-boolean v7, v6, v4

    move-object/from16 v0, p0

    iget v6, v0, La/a/b/b/a;->r:I

    const/high16 v7, -0x10000

    and-int/2addr v6, v7

    or-int/2addr v6, v4

    move-object/from16 v0, p0

    iput v6, v0, La/a/b/b/a;->r:I

    invoke-direct/range {p0 .. p0}, La/a/b/b/a;->d()V

    :cond_3df
    add-int/lit8 v4, v4, 0x1

    goto :goto_3c1

    :cond_3e2
    sget-object v7, La/a/b/b/a;->u:Ljava/util/logging/Logger;

    new-instance v8, Ljava/lang/StringBuilder;

    const-string v9, "Invalid config flags detected. Dropping resources: "

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6}, Ljava/util/logging/Logger;->warning(Ljava/lang/String;)V

    goto :goto_3b1

    :cond_3f7
    move-object/from16 v0, p0

    iget-object v6, v0, La/a/b/b/a;->o:La/a/b/a/e;

    invoke-virtual {v6, v4}, La/a/b/a/e;->a(La/a/b/a/c;)La/a/b/a/h;

    move-result-object v4

    goto :goto_3bc

    :cond_400
    move-object/from16 v0, p0

    iget-object v4, v0, La/a/b/b/a;->p:La/a/b/a/i;

    return-object v4
.end method

.method private b(I)V
    .registers 7

    iget-object v0, p0, La/a/b/b/a;->k:La/a/b/b/d;

    iget-short v0, v0, La/a/b/b/d;->a:S

    if-eq v0, p1, :cond_27

    new-instance v0, La/a/a;

    const-string v1, "Invalid chunk type: expected=0x%08x, got=0x%08x"

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x1

    iget-object v4, p0, La/a/b/b/a;->k:La/a/b/b/d;

    iget-short v4, v4, La/a/b/b/d;->a:S

    invoke-static {v4}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, La/a/a;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_27
    return-void
.end method

.method private c()La/a/b/a/i;
    .registers 7

    const/16 v0, 0x202

    invoke-direct {p0, v0}, La/a/b/b/a;->b(I)V

    iget-object v0, p0, La/a/b/b/a;->f:La/d/f;

    invoke-virtual {v0}, La/d/f;->readUnsignedByte()I

    move-result v4

    iget-object v0, p0, La/a/b/b/a;->f:La/d/f;

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, La/d/f;->skipBytes(I)I

    iget-object v0, p0, La/a/b/b/a;->f:La/d/f;

    invoke-virtual {v0}, La/d/f;->readInt()I

    move-result v5

    iget-object v0, p0, La/a/b/b/a;->i:Ljava/util/List;

    if-eqz v0, :cond_2b

    iget-object v0, p0, La/a/b/b/a;->i:Ljava/util/List;

    new-instance v1, La/a/b/b/c;

    iget-object v2, p0, La/a/b/b/a;->h:La/a/b/a/a;

    invoke-virtual {v2}, La/a/b/a/a;->a()I

    move-result v2

    invoke-direct {v1, v2, v5}, La/a/b/b/c;-><init>(II)V

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_2b
    iget-object v0, p0, La/a/b/b/a;->f:La/d/f;

    shl-int/lit8 v1, v5, 0x2

    invoke-virtual {v0, v1}, La/d/f;->skipBytes(I)I

    new-instance v0, La/a/b/a/i;

    iget-object v1, p0, La/a/b/b/a;->m:La/a/b/b/n;

    add-int/lit8 v2, v4, -0x1

    invoke-virtual {v1, v2}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, La/a/b/b/a;->g:Lcom/gmail/heagoo/a/c/a;

    iget-object v3, p0, La/a/b/b/a;->o:La/a/b/a/e;

    invoke-direct/range {v0 .. v5}, La/a/b/a/i;-><init>(Ljava/lang/String;Lcom/gmail/heagoo/a/c/a;La/a/b/a/e;II)V

    iput-object v0, p0, La/a/b/b/a;->p:La/a/b/a/i;

    iget-object v0, p0, La/a/b/b/a;->o:La/a/b/a/e;

    iget-object v1, p0, La/a/b/b/a;->p:La/a/b/a/i;

    invoke-virtual {v0, v1}, La/a/b/a/e;->a(La/a/b/a/i;)V

    iget-object v0, p0, La/a/b/b/a;->p:La/a/b/a/i;

    return-object v0
.end method

.method private d()V
    .registers 16

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/16 v14, 0x8

    const/4 v7, 0x0

    const/4 v13, 0x1

    new-array v0, v14, [B

    iget-object v1, p0, La/a/b/b/a;->f:La/d/f;

    invoke-virtual {v1, v0}, La/d/f;->readFully([B)V

    aget-byte v1, v0, v5

    and-int/lit16 v1, v1, 0xff

    shl-int/lit8 v1, v1, 0x8

    aget-byte v2, v0, v4

    and-int/lit16 v2, v2, 0xff

    or-int/2addr v1, v2

    int-to-short v1, v1

    const/4 v2, 0x7

    aget-byte v2, v0, v2

    shl-int/lit8 v2, v2, 0x18

    const/4 v3, 0x6

    aget-byte v3, v0, v3

    and-int/lit16 v3, v3, 0xff

    shl-int/lit8 v3, v3, 0x10

    or-int/2addr v2, v3

    const/4 v3, 0x5

    aget-byte v3, v0, v3

    and-int/lit16 v3, v3, 0xff

    shl-int/lit8 v3, v3, 0x8

    or-int/2addr v2, v3

    const/4 v3, 0x4

    aget-byte v0, v0, v3

    and-int/lit16 v0, v0, 0xff

    or-int v3, v2, v0

    iget-object v0, p0, La/a/b/b/a;->h:La/a/b/a/a;

    invoke-virtual {v0}, La/a/b/a/a;->a()I

    move-result v0

    iget-object v2, p0, La/a/b/b/a;->k:La/a/b/b/d;

    iget v2, v2, La/a/b/b/d;->c:I

    if-ne v0, v2, :cond_42

    :cond_41
    :goto_41
    return-void

    :cond_42
    and-int/lit8 v0, v1, 0x1

    if-nez v0, :cond_10f

    new-array v0, v14, [B

    iget-object v1, p0, La/a/b/b/a;->f:La/d/f;

    invoke-virtual {v1, v0}, La/d/f;->readFully([B)V

    aget-byte v1, v0, v5

    const/4 v2, 0x7

    aget-byte v2, v0, v2

    and-int/lit16 v2, v2, 0xff

    shl-int/lit8 v2, v2, 0x18

    const/4 v4, 0x6

    aget-byte v4, v0, v4

    and-int/lit16 v4, v4, 0xff

    shl-int/lit8 v4, v4, 0x10

    or-int/2addr v2, v4

    const/4 v4, 0x5

    aget-byte v4, v0, v4

    and-int/lit16 v4, v4, 0xff

    shl-int/lit8 v4, v4, 0x8

    or-int/2addr v2, v4

    const/4 v4, 0x4

    aget-byte v0, v0, v4

    and-int/lit16 v0, v0, 0xff

    or-int/2addr v0, v2

    invoke-direct {p0, v1, v0}, La/a/b/b/a;->a(BI)La/a/b/a/a/p;

    move-result-object v0

    :goto_70
    iget-object v1, p0, La/a/b/b/a;->p:La/a/b/a/i;

    invoke-virtual {v1}, La/a/b/a/i;->c()Z

    move-result v1

    if-eqz v1, :cond_1e6

    instance-of v1, v0, La/a/b/a/a/i;

    if-eqz v1, :cond_1e6

    new-instance v1, La/a/b/a/a/u;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    check-cast v0, La/a/b/a/a/i;

    invoke-virtual {v0}, La/a/b/a/a/i;->c()I

    move-result v0

    invoke-direct {v1, v2, v0}, La/a/b/a/a/u;-><init>(Ljava/lang/String;I)V

    move-object v6, v1

    :goto_8c
    iget-object v0, p0, La/a/b/b/a;->q:La/a/b/a/h;

    if-eqz v0, :cond_41

    new-instance v1, La/a/b/a/d;

    iget v0, p0, La/a/b/b/a;->r:I

    invoke-direct {v1, v0}, La/a/b/a/d;-><init>(I)V

    iget-object v0, p0, La/a/b/b/a;->o:La/a/b/a/e;

    invoke-virtual {v0, v1}, La/a/b/a/e;->a(La/a/b/a/d;)Z

    move-result v0

    if-eqz v0, :cond_1c8

    iget-object v0, p0, La/a/b/b/a;->o:La/a/b/a/e;

    invoke-virtual {v0, v1}, La/a/b/a/e;->b(La/a/b/a/d;)La/a/b/a/f;

    move-result-object v0

    invoke-virtual {v0}, La/a/b/a/f;->i()Z

    move-result v2

    if-eqz v2, :cond_dc

    iget-object v2, p0, La/a/b/b/a;->o:La/a/b/a/e;

    invoke-virtual {v0}, La/a/b/a/f;->e()La/a/b/a/d;

    move-result-object v4

    invoke-virtual {v2, v4}, La/a/b/a/e;->a(La/a/b/a/d;)Z

    move-result v2

    if-eqz v2, :cond_c1

    iget-object v2, p0, La/a/b/b/a;->o:La/a/b/a/e;

    invoke-virtual {v2, v0}, La/a/b/a/e;->a(La/a/b/a/f;)V

    iget-object v2, p0, La/a/b/b/a;->p:La/a/b/a/i;

    invoke-virtual {v2, v0}, La/a/b/a/i;->a(La/a/b/a/f;)V

    :cond_c1
    new-instance v0, La/a/b/a/f;

    iget v2, v1, La/a/b/a/d;->b:I

    invoke-direct {p0, v2, v3}, La/a/b/b/a;->a(II)Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, La/a/b/b/a;->o:La/a/b/a/e;

    iget-object v4, p0, La/a/b/b/a;->p:La/a/b/a/i;

    iget-boolean v5, p0, La/a/b/b/a;->d:Z

    invoke-direct/range {v0 .. v5}, La/a/b/a/f;-><init>(La/a/b/a/d;Ljava/lang/String;La/a/b/a/e;La/a/b/a/i;Z)V

    iget-object v1, p0, La/a/b/b/a;->o:La/a/b/a/e;

    invoke-virtual {v1, v0}, La/a/b/a/e;->b(La/a/b/a/f;)V

    iget-object v1, p0, La/a/b/b/a;->p:La/a/b/a/i;

    invoke-virtual {v1, v0}, La/a/b/a/i;->b(La/a/b/a/f;)V

    :cond_dc
    :goto_dc
    new-instance v2, La/a/b/a/g;

    iget-object v1, p0, La/a/b/b/a;->q:La/a/b/a/h;

    invoke-direct {v2, v1, v0, v6}, La/a/b/a/g;-><init>(La/a/b/a/h;La/a/b/a/f;La/a/b/a/a/w;)V

    :try_start_e3
    iget-object v1, p0, La/a/b/b/a;->q:La/a/b/a/h;

    invoke-virtual {v1, v2}, La/a/b/a/h;->a(La/a/b/a/g;)V

    invoke-virtual {v0, v2}, La/a/b/a/f;->a(La/a/b/a/g;)V
    :try_end_eb
    .catch La/a/a; {:try_start_e3 .. :try_end_eb} :catch_ed

    goto/16 :goto_41

    :catch_ed
    move-exception v1

    iget-boolean v3, p0, La/a/b/b/a;->j:Z

    if-eqz v3, :cond_1e5

    iget-object v1, p0, La/a/b/b/a;->q:La/a/b/a/h;

    invoke-virtual {v1, v2, v13}, La/a/b/a/h;->a(La/a/b/a/g;Z)V

    invoke-virtual {v0, v2, v13}, La/a/b/a/f;->a(La/a/b/a/g;Z)V

    sget-object v0, La/a/b/b/a;->u:Ljava/util/logging/Logger;

    const-string v1, "Duplicate res igonred: %s"

    new-array v3, v13, [Ljava/lang/Object;

    invoke-virtual {v2}, La/a/b/a/g;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v3, v7

    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/logging/Logger;->warning(Ljava/lang/String;)V

    goto/16 :goto_41

    :cond_10f
    iget-object v0, p0, La/a/b/b/a;->f:La/d/f;

    invoke-virtual {v0, v4}, La/d/f;->a(I)[I

    move-result-object v0

    aget v4, v0, v7

    aget v5, v0, v13

    iget-object v0, p0, La/a/b/b/a;->o:La/a/b/a/e;

    invoke-virtual {v0}, La/a/b/a/e;->g()La/a/b/a/a/x;

    move-result-object v6

    new-array v8, v5, [La/d/e;

    mul-int/lit8 v0, v5, 0xc

    new-array v9, v0, [B

    iget-object v0, p0, La/a/b/b/a;->f:La/d/f;

    invoke-virtual {v0, v9}, La/d/f;->readFully([B)V

    move v2, v7

    :goto_12b
    if-ge v2, v5, :cond_1c0

    mul-int/lit8 v0, v2, 0xc

    add-int/lit8 v1, v0, 0x3

    aget-byte v1, v9, v1

    and-int/lit16 v1, v1, 0xff

    shl-int/lit8 v1, v1, 0x18

    add-int/lit8 v10, v0, 0x2

    aget-byte v10, v9, v10

    and-int/lit16 v10, v10, 0xff

    shl-int/lit8 v10, v10, 0x10

    or-int/2addr v1, v10

    add-int/lit8 v10, v0, 0x1

    aget-byte v10, v9, v10

    and-int/lit16 v10, v10, 0xff

    shl-int/lit8 v10, v10, 0x8

    or-int/2addr v1, v10

    aget-byte v10, v9, v0

    and-int/lit16 v10, v10, 0xff

    or-int/2addr v10, v1

    add-int/lit8 v1, v0, 0x7

    aget-byte v1, v9, v1

    add-int/lit8 v11, v0, 0xb

    aget-byte v11, v9, v11

    and-int/lit16 v11, v11, 0xff

    shl-int/lit8 v11, v11, 0x18

    add-int/lit8 v12, v0, 0xa

    aget-byte v12, v9, v12

    and-int/lit16 v12, v12, 0xff

    shl-int/lit8 v12, v12, 0x10

    or-int/2addr v11, v12

    add-int/lit8 v12, v0, 0x9

    aget-byte v12, v9, v12

    and-int/lit16 v12, v12, 0xff

    shl-int/lit8 v12, v12, 0x8

    or-int/2addr v11, v12

    add-int/lit8 v12, v0, 0x8

    aget-byte v12, v9, v12

    and-int/lit16 v12, v12, 0xff

    or-int/2addr v11, v12

    add-int/lit8 v12, v0, 0x5

    aget-byte v12, v9, v12

    and-int/lit16 v12, v12, 0xff

    shl-int/lit8 v12, v12, 0x8

    add-int/lit8 v0, v0, 0x4

    aget-byte v0, v9, v0

    and-int/lit16 v0, v0, 0xff

    or-int/2addr v0, v12

    if-eq v0, v14, :cond_18b

    const-string v0, "DEBUG"

    const-string v12, "error"

    invoke-static {v0, v12}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_18b
    invoke-direct {p0, v1, v11}, La/a/b/b/a;->a(BI)La/a/b/a/a/p;

    move-result-object v0

    instance-of v1, v0, La/a/b/a/a/t;

    if-eqz v1, :cond_1a4

    new-instance v1, La/d/e;

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    check-cast v0, La/a/b/a/a/t;

    invoke-direct {v1, v10, v0}, La/d/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    aput-object v1, v8, v2

    :goto_1a0
    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_12b

    :cond_1a4
    new-instance v1, La/a/b/a/a/u;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v0}, La/a/b/a/a/p;->c()I

    move-result v0

    invoke-direct {v1, v11, v0}, La/a/b/a/a/u;-><init>(Ljava/lang/String;I)V

    new-instance v11, La/d/e;

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    move-object v0, v1

    check-cast v0, La/a/b/a/a/t;

    invoke-direct {v11, v10, v0}, La/d/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    aput-object v11, v8, v2

    goto :goto_1a0

    :cond_1c0
    iget-object v10, p0, La/a/b/b/a;->p:La/a/b/a/i;

    invoke-virtual {v6, v4, v8, v10}, La/a/b/a/a/x;->a(I[La/d/e;La/a/b/a/i;)La/a/b/a/a/c;

    move-result-object v0

    goto/16 :goto_70

    :cond_1c8
    new-instance v0, La/a/b/a/f;

    iget v2, v1, La/a/b/a/d;->b:I

    invoke-direct {p0, v2, v3}, La/a/b/b/a;->a(II)Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, La/a/b/b/a;->o:La/a/b/a/e;

    iget-object v4, p0, La/a/b/b/a;->p:La/a/b/a/i;

    iget-boolean v5, p0, La/a/b/b/a;->d:Z

    invoke-direct/range {v0 .. v5}, La/a/b/a/f;-><init>(La/a/b/a/d;Ljava/lang/String;La/a/b/a/e;La/a/b/a/i;Z)V

    iget-object v1, p0, La/a/b/b/a;->o:La/a/b/a/e;

    invoke-virtual {v1, v0}, La/a/b/a/e;->b(La/a/b/a/f;)V

    iget-object v1, p0, La/a/b/b/a;->p:La/a/b/a/i;

    invoke-virtual {v1, v0}, La/a/b/a/i;->b(La/a/b/a/f;)V

    goto/16 :goto_dc

    :cond_1e5
    throw v1

    :cond_1e6
    move-object v6, v0

    goto/16 :goto_8c
.end method

.method private e()V
    .registers 9

    const/4 v5, 0x0

    iget v0, p0, La/a/b/b/a;->r:I

    const/high16 v1, -0x10000

    and-int v7, v0, v1

    move v6, v5

    :goto_8
    iget-object v0, p0, La/a/b/b/a;->s:[Z

    array-length v0, v0

    if-ge v6, v0, :cond_79

    iget-object v0, p0, La/a/b/b/a;->s:[Z

    aget-boolean v0, v0, v6

    if-eqz v0, :cond_75

    new-instance v0, La/a/b/a/f;

    new-instance v1, La/a/b/a/d;

    or-int v2, v7, v6

    invoke-direct {v1, v2}, La/a/b/a/d;-><init>(I)V

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "carlos_ae_"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v6}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, La/a/b/b/a;->o:La/a/b/a/e;

    iget-object v4, p0, La/a/b/b/a;->p:La/a/b/a/i;

    invoke-direct/range {v0 .. v5}, La/a/b/a/f;-><init>(La/a/b/a/d;Ljava/lang/String;La/a/b/a/e;La/a/b/a/i;Z)V

    iget-object v1, p0, La/a/b/b/a;->o:La/a/b/a/e;

    new-instance v2, La/a/b/a/d;

    or-int v3, v7, v6

    invoke-direct {v2, v3}, La/a/b/a/d;-><init>(I)V

    invoke-virtual {v1, v2}, La/a/b/a/e;->a(La/a/b/a/d;)Z

    move-result v1

    if-nez v1, :cond_75

    iget-object v1, p0, La/a/b/b/a;->o:La/a/b/a/e;

    invoke-virtual {v1, v0}, La/a/b/a/e;->b(La/a/b/a/f;)V

    iget-object v1, p0, La/a/b/b/a;->p:La/a/b/a/i;

    invoke-virtual {v1, v0}, La/a/b/a/i;->b(La/a/b/a/f;)V

    iget-object v1, p0, La/a/b/b/a;->q:La/a/b/a/h;

    if-nez v1, :cond_60

    iget-object v1, p0, La/a/b/b/a;->o:La/a/b/a/e;

    new-instance v2, La/a/b/a/c;

    invoke-direct {v2}, La/a/b/a/c;-><init>()V

    invoke-virtual {v1, v2}, La/a/b/a/e;->a(La/a/b/a/c;)La/a/b/a/h;

    move-result-object v1

    iput-object v1, p0, La/a/b/b/a;->q:La/a/b/a/h;

    :cond_60
    new-instance v1, La/a/b/a/a/d;

    const/4 v2, 0x0

    invoke-direct {v1, v5, v5, v2}, La/a/b/a/a/d;-><init>(ZILjava/lang/String;)V

    new-instance v2, La/a/b/a/g;

    iget-object v3, p0, La/a/b/b/a;->q:La/a/b/a/h;

    invoke-direct {v2, v3, v0, v1}, La/a/b/a/g;-><init>(La/a/b/a/h;La/a/b/a/f;La/a/b/a/a/w;)V

    iget-object v1, p0, La/a/b/b/a;->q:La/a/b/a/h;

    invoke-virtual {v1, v2}, La/a/b/a/h;->a(La/a/b/a/g;)V

    invoke-virtual {v0, v2}, La/a/b/a/f;->a(La/a/b/a/g;)V

    :cond_75
    add-int/lit8 v0, v6, 0x1

    move v6, v0

    goto :goto_8

    :cond_79
    return-void
.end method

.method private f()La/a/b/b/d;
    .registers 3

    iget-object v0, p0, La/a/b/b/a;->f:La/d/f;

    iget-object v1, p0, La/a/b/b/a;->h:La/a/b/a/a;

    invoke-static {v0, v1}, La/a/b/b/d;->a(La/d/f;La/a/b/a/a;)La/a/b/b/d;

    move-result-object v0

    iput-object v0, p0, La/a/b/b/a;->k:La/a/b/b/d;

    return-object v0
.end method
