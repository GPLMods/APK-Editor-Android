.class public final La/a/b/b/n;
.super Ljava/lang/Object;


# instance fields
.field private a:Landroid/util/SparseArray;

.field private b:Z

.field private c:[I

.field private d:[B

.field private e:[I

.field private f:[I

.field private g:Z

.field private h:[I

.field private final i:Ljava/nio/charset/CharsetDecoder;

.field private final j:Ljava/nio/charset/CharsetDecoder;

.field private final k:Ljava/nio/charset/CharsetDecoder;


# direct methods
.method private constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, La/a/b/b/n;->a:Landroid/util/SparseArray;

    const/4 v0, 0x0

    iput-boolean v0, p0, La/a/b/b/n;->b:Z

    const-string v0, "UTF-16LE"

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    invoke-virtual {v0}, Ljava/nio/charset/Charset;->newDecoder()Ljava/nio/charset/CharsetDecoder;

    move-result-object v0

    iput-object v0, p0, La/a/b/b/n;->i:Ljava/nio/charset/CharsetDecoder;

    const-string v0, "UTF-8"

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    invoke-virtual {v0}, Ljava/nio/charset/Charset;->newDecoder()Ljava/nio/charset/CharsetDecoder;

    move-result-object v0

    iput-object v0, p0, La/a/b/b/n;->j:Ljava/nio/charset/CharsetDecoder;

    const-string v0, "CESU8"

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    invoke-virtual {v0}, Ljava/nio/charset/Charset;->newDecoder()Ljava/nio/charset/CharsetDecoder;

    move-result-object v0

    iput-object v0, p0, La/a/b/b/n;->k:Ljava/nio/charset/CharsetDecoder;

    return-void
.end method

.method public static a(La/d/f;)La/a/b/b/n;
    .registers 10

    const/4 v1, 0x0

    const v0, 0x1c0001

    invoke-virtual {p0, v0, v1}, La/d/f;->a(II)V

    invoke-virtual {p0}, La/d/f;->readInt()I

    move-result v2

    invoke-virtual {p0}, La/d/f;->readInt()I

    move-result v4

    invoke-virtual {p0}, La/d/f;->readInt()I

    move-result v5

    invoke-virtual {p0}, La/d/f;->readInt()I

    move-result v0

    invoke-virtual {p0}, La/d/f;->readInt()I

    move-result v6

    invoke-virtual {p0}, La/d/f;->readInt()I

    move-result v3

    new-instance v7, La/a/b/b/n;

    invoke-direct {v7}, La/a/b/b/n;-><init>()V

    and-int/lit16 v0, v0, 0x100

    if-eqz v0, :cond_3f

    const/4 v0, 0x1

    :goto_29
    iput-boolean v0, v7, La/a/b/b/n;->g:Z

    invoke-virtual {p0, v4}, La/d/f;->a(I)[I

    move-result-object v0

    iput-object v0, v7, La/a/b/b/n;->c:[I

    new-array v0, v4, [I

    iput-object v0, v7, La/a/b/b/n;->h:[I

    :goto_35
    if-ge v1, v4, :cond_41

    iget-object v0, v7, La/a/b/b/n;->h:[I

    const/4 v8, -0x1

    aput v8, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_35

    :cond_3f
    move v0, v1

    goto :goto_29

    :cond_41
    if-eqz v5, :cond_49

    invoke-virtual {p0, v5}, La/d/f;->a(I)[I

    move-result-object v0

    iput-object v0, v7, La/a/b/b/n;->e:[I

    :cond_49
    if-nez v3, :cond_6f

    move v0, v2

    :goto_4c
    sub-int/2addr v0, v6

    new-array v0, v0, [B

    iput-object v0, v7, La/a/b/b/n;->d:[B

    iget-object v0, v7, La/a/b/b/n;->d:[B

    invoke-virtual {p0, v0}, La/d/f;->readFully([B)V

    if-eqz v3, :cond_71

    sub-int v0, v2, v3

    div-int/lit8 v1, v0, 0x4

    invoke-virtual {p0, v1}, La/d/f;->a(I)[I

    move-result-object v1

    iput-object v1, v7, La/a/b/b/n;->f:[I

    rem-int/lit8 v0, v0, 0x4

    if-lez v0, :cond_71

    :goto_66
    add-int/lit8 v1, v0, -0x1

    if-lez v0, :cond_71

    invoke-virtual {p0}, La/d/f;->readByte()B

    move v0, v1

    goto :goto_66

    :cond_6f
    move v0, v3

    goto :goto_4c

    :cond_71
    return-object v7
.end method

.method private a(II)Ljava/lang/String;
    .registers 16

    iget-object v10, p0, La/a/b/b/n;->d:[B

    invoke-static {v10, p1, p2}, Ljava/nio/ByteBuffer;->wrap([BII)Ljava/nio/ByteBuffer;

    move-result-object v9

    :try_start_6
    iget-boolean v10, p0, La/a/b/b/n;->g:Z

    if-eqz v10, :cond_15

    iget-object v10, p0, La/a/b/b/n;->j:Ljava/nio/charset/CharsetDecoder;

    :goto_c
    invoke-virtual {v10, v9}, Ljava/nio/charset/CharsetDecoder;->decode(Ljava/nio/ByteBuffer;)Ljava/nio/CharBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/nio/CharBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    :goto_14
    return-object v10

    :cond_15
    iget-object v10, p0, La/a/b/b/n;->i:Ljava/nio/charset/CharsetDecoder;
    :try_end_17
    .catch Ljava/nio/charset/CharacterCodingException; {:try_start_6 .. :try_end_17} :catch_18

    goto :goto_c

    :catch_18
    move-exception v3

    iget-boolean v10, p0, La/a/b/b/n;->g:Z

    if-nez v10, :cond_20

    const-string v10, "DCD"

    goto :goto_14

    :cond_20
    :try_start_20
    iget-object v10, p0, La/a/b/b/n;->d:[B

    add-int v11, p1, p2

    invoke-static {v10, p1, v11}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v0

    new-array v1, p2, [B

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x0

    move v6, v5

    :goto_32
    if-ge v4, p2, :cond_a7

    aget-byte v10, v0, v4

    const/16 v11, -0x13

    if-ne v10, v11, :cond_9b

    add-int/lit8 v10, v4, 0x3

    aget-byte v10, v0, v10

    const/16 v11, -0x13

    if-ne v10, v11, :cond_9b

    add-int/lit8 v10, v4, 0x1

    aget-byte v10, v0, v10

    const/16 v11, -0x60

    if-lt v10, v11, :cond_9b

    add-int/lit8 v10, v4, 0x1

    aget-byte v10, v0, v10

    const/16 v11, -0x51

    if-gt v10, v11, :cond_9b

    add-int/lit8 v10, v4, 0x4

    aget-byte v10, v0, v10

    const/16 v11, -0x50

    if-lt v10, v11, :cond_9b

    add-int/lit8 v10, v4, 0x4

    aget-byte v10, v0, v10

    const/16 v11, -0x41

    if-gt v10, v11, :cond_9b

    const/4 v10, 0x0

    aget-byte v10, v1, v10

    if-eqz v10, :cond_7e

    invoke-static {v1}, La/a/b/b/n;->trim([B)[B

    move-result-object v8

    iget-object v10, p0, La/a/b/b/n;->j:Ljava/nio/charset/CharsetDecoder;

    const/4 v11, 0x0

    array-length v12, v8

    invoke-static {v8, v11, v12}, Ljava/nio/ByteBuffer;->wrap([BII)Ljava/nio/ByteBuffer;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/nio/charset/CharsetDecoder;->decode(Ljava/nio/ByteBuffer;)Ljava/nio/CharBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/nio/CharBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_7e
    iget-object v10, p0, La/a/b/b/n;->k:Ljava/nio/charset/CharsetDecoder;

    const/4 v11, 0x6

    invoke-static {v0, v4, v11}, Ljava/nio/ByteBuffer;->wrap([BII)Ljava/nio/ByteBuffer;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/nio/charset/CharsetDecoder;->decode(Ljava/nio/ByteBuffer;)Ljava/nio/CharBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/nio/CharBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v4, v4, 0x5

    const/4 v10, 0x0

    invoke-static {v1, v10}, Ljava/util/Arrays;->fill([BB)V

    const/4 v5, 0x0

    :goto_97
    add-int/lit8 v4, v4, 0x1

    move v6, v5

    goto :goto_32

    :cond_9b
    add-int/lit8 v5, v6, 0x1

    aget-byte v10, v0, v4

    aput-byte v10, v1, v6
    :try_end_a1
    .catch Ljava/nio/charset/CharacterCodingException; {:try_start_20 .. :try_end_a1} :catch_a2

    goto :goto_97

    :catch_a2
    move-exception v2

    const-string v10, "CSU"

    goto/16 :goto_14

    :cond_a7
    const/4 v10, 0x0

    :try_start_a8
    aget-byte v10, v1, v10

    if-eqz v10, :cond_c3

    invoke-static {v1}, La/a/b/b/n;->trim([B)[B

    move-result-object v8

    iget-object v10, p0, La/a/b/b/n;->j:Ljava/nio/charset/CharsetDecoder;

    const/4 v11, 0x0

    array-length v12, v8

    invoke-static {v8, v11, v12}, Ljava/nio/ByteBuffer;->wrap([BII)Ljava/nio/ByteBuffer;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/nio/charset/CharsetDecoder;->decode(Ljava/nio/ByteBuffer;)Ljava/nio/CharBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/nio/CharBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_c3
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    :try_end_c6
    .catch Ljava/nio/charset/CharacterCodingException; {:try_start_a8 .. :try_end_c6} :catch_a2

    move-result-object v10

    goto/16 :goto_14
.end method

.method private static a(Ljava/lang/String;II)Ljava/lang/String;
    .registers 4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    if-ge p1, v0, :cond_16

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    if-gt p2, v0, :cond_11

    invoke-virtual {p0, p1, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    :goto_10
    return-object v0

    :cond_11
    invoke-virtual {p0, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_10

    :cond_16
    const-string v0, ""

    goto :goto_10
.end method

.method private static a(Ljava/lang/String;Ljava/lang/StringBuilder;Z)V
    .registers 10

    const/16 v6, 0x3b

    const/4 v2, 0x0

    const/4 v5, -0x1

    const/16 v0, 0x3c

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    if-eqz p2, :cond_10

    const/16 v0, 0x2f

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_10
    invoke-virtual {p0, v6}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    if-ne v0, v5, :cond_1f

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_19
    const/16 v0, 0x3e

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    return-void

    :cond_1f
    invoke-virtual {p0, v2, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-nez p2, :cond_19

    const/4 v1, 0x1

    :goto_29
    if-eqz v1, :cond_19

    const/16 v3, 0x3d

    add-int/lit8 v4, v0, 0x1

    invoke-virtual {p0, v3, v4}, Ljava/lang/String;->indexOf(II)I

    move-result v4

    if-eq v4, v5, :cond_6f

    const/16 v3, 0x20

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v3

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, "=\""

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v0, v4, 0x1

    invoke-virtual {p0, v6, v0}, Ljava/lang/String;->indexOf(II)I

    move-result v3

    if-eq v3, v5, :cond_67

    add-int/lit8 v0, v4, 0x1

    invoke-virtual {p0, v0, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    :goto_58
    invoke-static {v0}, Lcom/gmail/heagoo/a/c/a;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const/16 v4, 0x22

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move v0, v3

    goto :goto_29

    :cond_67
    add-int/lit8 v0, v4, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    move v1, v2

    goto :goto_58

    :cond_6f
    move v1, v2

    goto :goto_29
.end method

.method public static final a([BI)[I
    .registers 6

    aget-byte v0, p0, p1

    and-int/lit16 v0, v0, 0x80

    if-eqz v0, :cond_25

    add-int/lit8 v0, p1, 0x2

    :goto_8
    aget-byte v1, p0, v0

    add-int/lit8 v0, v0, 0x1

    and-int/lit16 v2, v1, 0x80

    if-eqz v2, :cond_1b

    aget-byte v2, p0, v0

    and-int/lit16 v2, v2, 0xff

    and-int/lit8 v1, v1, 0x7f

    shl-int/lit8 v1, v1, 0x8

    add-int/2addr v1, v2

    add-int/lit8 v0, v0, 0x1

    :cond_1b
    const/4 v2, 0x2

    new-array v2, v2, [I

    const/4 v3, 0x0

    aput v0, v2, v3

    const/4 v0, 0x1

    aput v1, v2, v0

    return-object v2

    :cond_25
    add-int/lit8 v0, p1, 0x1

    goto :goto_8
.end method

.method public static final b([BI)[I
    .registers 8

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x2

    add-int/lit8 v0, p1, 0x1

    aget-byte v0, p0, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x8

    aget-byte v1, p0, p1

    and-int/lit16 v1, v1, 0xff

    or-int/2addr v1, v0

    const v0, 0x8000

    and-int/2addr v0, v1

    if-eqz v0, :cond_34

    add-int/lit8 v0, p1, 0x3

    aget-byte v0, p0, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x8

    add-int/lit8 v2, p1, 0x2

    aget-byte v2, p0, v2

    and-int/lit16 v2, v2, 0xff

    and-int/lit16 v1, v1, 0x7fff

    shl-int/lit8 v1, v1, 0x10

    add-int/2addr v0, v2

    add-int/2addr v1, v0

    new-array v0, v3, [I

    const/4 v2, 0x4

    aput v2, v0, v4

    shl-int/lit8 v1, v1, 0x1

    aput v1, v0, v5

    :goto_33
    return-object v0

    :cond_34
    new-array v0, v3, [I

    aput v3, v0, v4

    shl-int/lit8 v1, v1, 0x1

    aput v1, v0, v5

    goto :goto_33
.end method

.method private static final c([BI)I
    .registers 4

    add-int/lit8 v0, p1, 0x1

    aget-byte v0, p0, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x8

    aget-byte v1, p0, p1

    and-int/lit16 v1, v1, 0xff

    or-int/2addr v0, v1

    return v0
.end method

.method private static trim([B)[B
    .registers 3

    array-length v1, p0

    add-int/lit8 v0, v1, -0x1

    :goto_3
    if-ltz v0, :cond_c

    aget-byte v1, p0, v0

    if-nez v1, :cond_c

    add-int/lit8 v0, v0, -0x1

    goto :goto_3

    :cond_c
    add-int/lit8 v1, v0, 0x1

    invoke-static {p0, v1}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v1

    return-object v1
.end method


# virtual methods
.method public final a()I
    .registers 2

    iget-object v0, p0, La/a/b/b/n;->c:[I

    if-eqz v0, :cond_8

    iget-object v0, p0, La/a/b/b/n;->c:[I

    array-length v0, v0

    :goto_7
    return v0

    :cond_8
    const/4 v0, 0x0

    goto :goto_7
.end method

.method public final a(Ljava/lang/String;)I
    .registers 10

    const/4 v1, 0x0

    const/4 v2, -0x1

    if-nez p1, :cond_6

    move v0, v2

    :cond_5
    :goto_5
    return v0

    :cond_6
    move v0, v1

    :goto_7
    iget-object v3, p0, La/a/b/b/n;->c:[I

    array-length v3, v3

    if-eq v0, v3, :cond_36

    iget-object v3, p0, La/a/b/b/n;->c:[I

    aget v3, v3, v0

    iget-object v4, p0, La/a/b/b/n;->d:[B

    invoke-static {v4, v3}, La/a/b/b/n;->c([BI)I

    move-result v5

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v4

    if-ne v5, v4, :cond_33

    move v4, v3

    move v3, v1

    :goto_1e
    if-eq v3, v5, :cond_31

    add-int/lit8 v4, v4, 0x2

    invoke-virtual {p1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v6

    iget-object v7, p0, La/a/b/b/n;->d:[B

    invoke-static {v7, v4}, La/a/b/b/n;->c([BI)I

    move-result v7

    if-ne v6, v7, :cond_31

    add-int/lit8 v3, v3, 0x1

    goto :goto_1e

    :cond_31
    if-eq v3, v5, :cond_5

    :cond_33
    add-int/lit8 v0, v0, 0x1

    goto :goto_7

    :cond_36
    move v0, v2

    goto :goto_5
.end method

.method public final a(I)Ljava/lang/String;
    .registers 7

    const/4 v4, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, La/a/b/b/n;->a:Landroid/util/SparseArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-eqz v0, :cond_d

    :goto_c
    return-object v0

    :cond_d
    if-ltz p1, :cond_18

    iget-object v0, p0, La/a/b/b/n;->c:[I

    if-eqz v0, :cond_18

    iget-object v0, p0, La/a/b/b/n;->c:[I

    array-length v0, v0

    if-lt p1, v0, :cond_1a

    :cond_18
    const/4 v0, 0x0

    goto :goto_c

    :cond_1a
    iget-object v0, p0, La/a/b/b/n;->c:[I

    aget v0, v0, p1

    iget-boolean v1, p0, La/a/b/b/n;->g:Z

    if-eqz v1, :cond_31

    iget-object v1, p0, La/a/b/b/n;->d:[B

    invoke-static {v1, v0}, La/a/b/b/n;->a([BI)[I

    move-result-object v0

    aget v1, v0, v3

    aget v0, v0, v4

    :goto_2c
    invoke-direct {p0, v1, v0}, La/a/b/b/n;->a(II)Ljava/lang/String;

    move-result-object v0

    goto :goto_c

    :cond_31
    iget-object v1, p0, La/a/b/b/n;->d:[B

    invoke-static {v1, v0}, La/a/b/b/n;->b([BI)[I

    move-result-object v2

    aget v1, v2, v3

    add-int/2addr v1, v0

    aget v0, v2, v4

    goto :goto_2c
.end method

.method public final a(ILjava/lang/String;)V
    .registers 4

    iget-object v0, p0, La/a/b/b/n;->a:Landroid/util/SparseArray;

    invoke-virtual {v0, p1, p2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    return-void
.end method

.method public final b(ILjava/lang/String;)Ljava/lang/String;
    .registers 15

    if-nez p2, :cond_3

    :goto_2
    return-object p2

    :cond_3
    iget-object v0, p0, La/a/b/b/n;->e:[I

    if-eqz v0, :cond_10

    iget-object v0, p0, La/a/b/b/n;->f:[I

    if-eqz v0, :cond_10

    iget-object v0, p0, La/a/b/b/n;->e:[I

    array-length v0, v0

    if-lt p1, v0, :cond_1c

    :cond_10
    const/4 v0, 0x0

    move-object v4, v0

    :cond_12
    :goto_12
    if-nez v4, :cond_5c

    const/4 v0, 0x0

    iput-boolean v0, p0, La/a/b/b/n;->b:Z

    invoke-static {p2}, Lcom/gmail/heagoo/a/c/a;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    goto :goto_2

    :cond_1c
    iget-object v0, p0, La/a/b/b/n;->e:[I

    aget v0, v0, p1

    div-int/lit8 v1, v0, 0x4

    const/4 v0, 0x0

    move v2, v0

    move v0, v1

    :goto_25
    iget-object v3, p0, La/a/b/b/n;->f:[I

    array-length v3, v3

    if-ge v0, v3, :cond_36

    iget-object v3, p0, La/a/b/b/n;->f:[I

    aget v3, v3, v0

    const/4 v4, -0x1

    if-eq v3, v4, :cond_36

    add-int/lit8 v2, v2, 0x1

    add-int/lit8 v0, v0, 0x1

    goto :goto_25

    :cond_36
    if-eqz v2, :cond_3c

    rem-int/lit8 v0, v2, 0x3

    if-eqz v0, :cond_3f

    :cond_3c
    const/4 v0, 0x0

    move-object v4, v0

    goto :goto_12

    :cond_3f
    new-array v4, v2, [I

    const/4 v0, 0x0

    move v2, v1

    :goto_43
    iget-object v1, p0, La/a/b/b/n;->f:[I

    array-length v1, v1

    if-ge v2, v1, :cond_12

    iget-object v1, p0, La/a/b/b/n;->f:[I

    aget v1, v1, v2

    const/4 v3, -0x1

    if-eq v1, v3, :cond_12

    add-int/lit8 v1, v0, 0x1

    iget-object v5, p0, La/a/b/b/n;->f:[I

    add-int/lit8 v3, v2, 0x1

    aget v2, v5, v2

    aput v2, v4, v0

    move v0, v1

    move v2, v3

    goto :goto_43

    :cond_5c
    const/4 v0, 0x1

    iput-boolean v0, p0, La/a/b/b/n;->b:Z

    const/4 v0, 0x1

    aget v0, v4, v0

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v1

    if-le v0, v1, :cond_6d

    invoke-static {p2}, Lcom/gmail/heagoo/a/c/a;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    goto :goto_2

    :cond_6d
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    add-int/lit8 v0, v0, 0x20

    invoke-direct {v5, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    array-length v0, v4

    div-int/lit8 v0, v0, 0x3

    new-array v6, v0, [I

    array-length v0, v4

    div-int/lit8 v0, v0, 0x3

    new-array v7, v0, [Z

    const/4 v1, 0x0

    const/4 v0, 0x0

    :goto_84
    const/4 v3, -0x1

    const/4 v2, 0x0

    :goto_86
    array-length v8, v4

    if-eq v2, v8, :cond_a1

    add-int/lit8 v8, v2, 0x1

    aget v8, v4, v8

    const/4 v9, -0x1

    if-eq v8, v9, :cond_9e

    const/4 v8, -0x1

    if-eq v3, v8, :cond_9d

    add-int/lit8 v8, v3, 0x1

    aget v8, v4, v8

    add-int/lit8 v9, v2, 0x1

    aget v9, v4, v9

    if-le v8, v9, :cond_9e

    :cond_9d
    move v3, v2

    :cond_9e
    add-int/lit8 v2, v2, 0x3

    goto :goto_86

    :cond_a1
    const/4 v2, -0x1

    if-eq v3, v2, :cond_110

    add-int/lit8 v2, v3, 0x1

    aget v2, v4, v2

    :goto_a8
    add-int/lit8 v0, v0, -0x1

    move v11, v0

    move v0, v1

    move v1, v11

    :goto_ad
    if-ltz v1, :cond_c4

    aget v8, v6, v1

    add-int/lit8 v9, v8, 0x2

    aget v9, v4, v9

    if-lt v9, v2, :cond_115

    add-int/lit8 v8, v8, 0x1

    aget v8, v4, v8

    const/4 v10, -0x1

    if-ne v8, v10, :cond_c4

    const/4 v8, -0x1

    if-eq v9, v8, :cond_c4

    const/4 v8, 0x1

    aput-boolean v8, v7, v1

    :cond_c4
    add-int/lit8 v8, v1, 0x1

    if-ge v0, v2, :cond_13a

    invoke-static {p2, v0, v2}, La/a/b/b/n;->a(Ljava/lang/String;II)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/gmail/heagoo/a/c/a;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-ltz v1, :cond_f7

    array-length v0, v7

    if-lt v0, v1, :cond_f7

    aget-boolean v0, v7, v1

    if-eqz v0, :cond_f7

    array-length v0, v7

    add-int/lit8 v9, v1, 0x1

    if-le v0, v9, :cond_e7

    add-int/lit8 v0, v1, 0x1

    aget-boolean v0, v7, v0

    if-nez v0, :cond_eb

    :cond_e7
    array-length v0, v7

    const/4 v9, 0x1

    if-ne v0, v9, :cond_f7

    :cond_eb
    aget v0, v6, v1

    aget v0, v4, v0

    invoke-virtual {p0, v0}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v0, v5, v1}, La/a/b/b/n;->a(Ljava/lang/String;Ljava/lang/StringBuilder;Z)V

    :cond_f7
    move v1, v2

    :goto_f8
    const/4 v0, -0x1

    if-eq v3, v0, :cond_134

    aget v0, v4, v3

    invoke-virtual {p0, v0}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    invoke-static {v0, v5, v2}, La/a/b/b/n;->a(Ljava/lang/String;Ljava/lang/StringBuilder;Z)V

    add-int/lit8 v0, v3, 0x1

    const/4 v2, -0x1

    aput v2, v4, v0

    add-int/lit8 v0, v8, 0x1

    aput v3, v6, v8

    goto/16 :goto_84

    :cond_110
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v2

    goto :goto_a8

    :cond_115
    if-gt v0, v9, :cond_126

    add-int/lit8 v10, v9, 0x1

    invoke-static {p2, v0, v10}, La/a/b/b/n;->a(Ljava/lang/String;II)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/gmail/heagoo/a/c/a;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v0, v9, 0x1

    :cond_126
    aget v8, v4, v8

    invoke-virtual {p0, v8}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x1

    invoke-static {v8, v5, v9}, La/a/b/b/n;->a(Ljava/lang/String;Ljava/lang/StringBuilder;Z)V

    add-int/lit8 v1, v1, -0x1

    goto/16 :goto_ad

    :cond_134
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    goto/16 :goto_2

    :cond_13a
    move v1, v0

    goto :goto_f8
.end method

.method public final b()Z
    .registers 2

    iget-boolean v0, p0, La/a/b/b/n;->b:Z

    return v0
.end method
