.class public La/a/b/b/b;
.super Ljava/lang/Object;


# instance fields
.field private final a:[La/a/b/a/e;


# direct methods
.method public constructor <init>([La/a/b/a/e;[La/a/b/b/c;Lcom/gmail/heagoo/a/c/a;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/a/b/b/b;->a:[La/a/b/a/e;

    return-void
.end method


# virtual methods
.method public final a()[La/a/b/a/e;
    .registers 2

    iget-object v0, p0, La/a/b/b/b;->a:[La/a/b/a/e;

    return-object v0
.end method
