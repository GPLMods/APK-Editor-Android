.class public final La/a/b/b/j;
.super Ljava/lang/Object;

# interfaces
.implements La/a/b/b/k;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    .registers 6

    const/16 v0, 0x1000

    :try_start_2
    new-array v0, v0, [B

    :goto_4
    invoke-virtual {p1, v0}, Ljava/io/InputStream;->read([B)I

    move-result v1

    const/4 v2, -0x1

    if-eq v1, v2, :cond_19

    const/4 v2, 0x0

    invoke-virtual {p2, v0, v2, v1}, Ljava/io/OutputStream;->write([BII)V
    :try_end_f
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_f} :catch_10

    goto :goto_4

    :catch_10
    move-exception v0

    new-instance v1, La/a/a;

    const-string v2, "Cannot decode raw stream"

    invoke-direct {v1, v2, v0}, La/a/a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1

    :cond_19
    return-void
.end method
