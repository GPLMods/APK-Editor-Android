.class public final La/a/b/b/c;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>(II)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
