.class final La/a/b/b/f;
.super Ljava/lang/Object;


# instance fields
.field private a:[I

.field private b:I

.field private c:I

.field private d:I


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x20

    new-array v0, v0, [I

    iput-object v0, p0, La/a/b/b/f;->a:[I

    return-void
.end method

.method private final a(IZ)I
    .registers 7

    const/4 v0, -0x1

    iget v1, p0, La/a/b/b/f;->b:I

    if-eqz v1, :cond_7

    if-gez p1, :cond_8

    :cond_7
    :goto_7
    return v0

    :cond_8
    const/4 v2, 0x0

    iget v1, p0, La/a/b/b/f;->d:I

    :goto_b
    if-eqz v1, :cond_7

    iget-object v3, p0, La/a/b/b/f;->a:[I

    aget v3, v3, v2

    if-lt p1, v3, :cond_1c

    sub-int/2addr p1, v3

    shl-int/lit8 v3, v3, 0x1

    add-int/lit8 v3, v3, 0x2

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, -0x1

    goto :goto_b

    :cond_1c
    shl-int/lit8 v0, p1, 0x1

    add-int/lit8 v0, v0, 0x1

    add-int/2addr v0, v2

    if-nez p2, :cond_25

    add-int/lit8 v0, v0, 0x1

    :cond_25
    iget-object v1, p0, La/a/b/b/f;->a:[I

    aget v0, v1, v0

    goto :goto_7
.end method

.method private e(I)V
    .registers 6

    const/4 v3, 0x0

    iget-object v0, p0, La/a/b/b/f;->a:[I

    array-length v0, v0

    iget v1, p0, La/a/b/b/f;->b:I

    sub-int/2addr v0, v1

    const/4 v1, 0x2

    if-le v0, v1, :cond_b

    :goto_a
    return-void

    :cond_b
    iget-object v1, p0, La/a/b/b/f;->a:[I

    array-length v1, v1

    add-int/2addr v0, v1

    shl-int/lit8 v0, v0, 0x1

    new-array v0, v0, [I

    iget-object v1, p0, La/a/b/b/f;->a:[I

    iget v2, p0, La/a/b/b/f;->b:I

    invoke-static {v1, v3, v0, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v0, p0, La/a/b/b/f;->a:[I

    goto :goto_a
.end method


# virtual methods
.method public final a(I)I
    .registers 6

    const/4 v0, 0x0

    iget v1, p0, La/a/b/b/f;->b:I

    if-eqz v1, :cond_7

    if-gez p1, :cond_8

    :cond_7
    return v0

    :cond_8
    iget v1, p0, La/a/b/b/f;->d:I

    if-le p1, v1, :cond_e

    iget p1, p0, La/a/b/b/f;->d:I

    :cond_e
    move v1, v0

    :goto_f
    if-eqz p1, :cond_7

    iget-object v2, p0, La/a/b/b/f;->a:[I

    aget v3, v2, v1

    add-int v2, v0, v3

    shl-int/lit8 v0, v3, 0x1

    add-int/lit8 v0, v0, 0x2

    add-int/2addr v0, v1

    add-int/lit8 p1, p1, -0x1

    move v1, v0

    move v0, v2

    goto :goto_f
.end method

.method public final a()V
    .registers 2

    const/4 v0, 0x0

    iput v0, p0, La/a/b/b/f;->b:I

    iput v0, p0, La/a/b/b/f;->c:I

    iput v0, p0, La/a/b/b/f;->d:I

    return-void
.end method

.method public final a(II)V
    .registers 8

    iget v0, p0, La/a/b/b/f;->d:I

    if-nez v0, :cond_7

    invoke-virtual {p0}, La/a/b/b/f;->e()V

    :cond_7
    const/4 v0, 0x2

    invoke-direct {p0, v0}, La/a/b/b/f;->e(I)V

    iget v0, p0, La/a/b/b/f;->b:I

    add-int/lit8 v0, v0, -0x1

    iget-object v1, p0, La/a/b/b/f;->a:[I

    aget v1, v1, v0

    iget-object v2, p0, La/a/b/b/f;->a:[I

    add-int/lit8 v3, v0, -0x1

    shl-int/lit8 v4, v1, 0x1

    sub-int/2addr v3, v4

    add-int/lit8 v4, v1, 0x1

    aput v4, v2, v3

    iget-object v2, p0, La/a/b/b/f;->a:[I

    aput p1, v2, v0

    iget-object v2, p0, La/a/b/b/f;->a:[I

    add-int/lit8 v3, v0, 0x1

    aput p2, v2, v3

    iget-object v2, p0, La/a/b/b/f;->a:[I

    add-int/lit8 v0, v0, 0x2

    add-int/lit8 v1, v1, 0x1

    aput v1, v2, v0

    iget v0, p0, La/a/b/b/f;->b:I

    add-int/lit8 v0, v0, 0x2

    iput v0, p0, La/a/b/b/f;->b:I

    iget v0, p0, La/a/b/b/f;->c:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/a/b/b/f;->c:I

    return-void
.end method

.method public final b()I
    .registers 3

    iget v0, p0, La/a/b/b/f;->b:I

    if-nez v0, :cond_6

    const/4 v0, 0x0

    :goto_5
    return v0

    :cond_6
    iget v0, p0, La/a/b/b/f;->b:I

    add-int/lit8 v0, v0, -0x1

    iget-object v1, p0, La/a/b/b/f;->a:[I

    aget v0, v1, v0

    goto :goto_5
.end method

.method public final b(I)I
    .registers 3

    const/4 v0, 0x1

    invoke-direct {p0, p1, v0}, La/a/b/b/f;->a(IZ)I

    move-result v0

    return v0
.end method

.method public final c(I)I
    .registers 3

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, La/a/b/b/f;->a(IZ)I

    move-result v0

    return v0
.end method

.method public final c()Z
    .registers 4

    const/4 v0, 0x0

    iget v1, p0, La/a/b/b/f;->b:I

    if-nez v1, :cond_6

    :cond_5
    :goto_5
    return v0

    :cond_6
    iget v1, p0, La/a/b/b/f;->b:I

    add-int/lit8 v1, v1, -0x1

    iget-object v2, p0, La/a/b/b/f;->a:[I

    aget v2, v2, v1

    if-eqz v2, :cond_5

    add-int/lit8 v0, v2, -0x1

    add-int/lit8 v1, v1, -0x2

    iget-object v2, p0, La/a/b/b/f;->a:[I

    aput v0, v2, v1

    shl-int/lit8 v2, v0, 0x1

    add-int/lit8 v2, v2, 0x1

    sub-int/2addr v1, v2

    iget-object v2, p0, La/a/b/b/f;->a:[I

    aput v0, v2, v1

    iget v0, p0, La/a/b/b/f;->b:I

    add-int/lit8 v0, v0, -0x2

    iput v0, p0, La/a/b/b/f;->b:I

    iget v0, p0, La/a/b/b/f;->c:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, La/a/b/b/f;->c:I

    const/4 v0, 0x1

    goto :goto_5
.end method

.method public final d()I
    .registers 2

    iget v0, p0, La/a/b/b/f;->d:I

    return v0
.end method

.method public final d(I)I
    .registers 7

    iget v0, p0, La/a/b/b/f;->b:I

    if-eqz v0, :cond_2b

    iget v0, p0, La/a/b/b/f;->b:I

    add-int/lit8 v1, v0, -0x1

    iget v0, p0, La/a/b/b/f;->d:I

    move v2, v0

    :goto_b
    if-eqz v2, :cond_2b

    iget-object v0, p0, La/a/b/b/f;->a:[I

    aget v0, v0, v1

    add-int/lit8 v1, v1, -0x2

    :goto_13
    if-eqz v0, :cond_27

    iget-object v3, p0, La/a/b/b/f;->a:[I

    add-int/lit8 v4, v1, 0x1

    aget v3, v3, v4

    if-ne v3, p1, :cond_22

    iget-object v0, p0, La/a/b/b/f;->a:[I

    aget v0, v0, v1

    :goto_21
    return v0

    :cond_22
    add-int/lit8 v1, v1, -0x2

    add-int/lit8 v0, v0, -0x1

    goto :goto_13

    :cond_27
    add-int/lit8 v0, v2, -0x1

    move v2, v0

    goto :goto_b

    :cond_2b
    const/4 v0, -0x1

    goto :goto_21
.end method

.method public final e()V
    .registers 4

    const/4 v2, 0x0

    const/4 v0, 0x2

    invoke-direct {p0, v0}, La/a/b/b/f;->e(I)V

    iget v0, p0, La/a/b/b/f;->b:I

    iget-object v1, p0, La/a/b/b/f;->a:[I

    aput v2, v1, v0

    iget-object v1, p0, La/a/b/b/f;->a:[I

    add-int/lit8 v0, v0, 0x1

    aput v2, v1, v0

    iget v0, p0, La/a/b/b/f;->b:I

    add-int/lit8 v0, v0, 0x2

    iput v0, p0, La/a/b/b/f;->b:I

    iget v0, p0, La/a/b/b/f;->d:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/a/b/b/f;->d:I

    return-void
.end method

.method public final f()V
    .registers 4

    iget v0, p0, La/a/b/b/f;->b:I

    if-nez v0, :cond_5

    :cond_4
    :goto_4
    return-void

    :cond_5
    iget v0, p0, La/a/b/b/f;->b:I

    add-int/lit8 v0, v0, -0x1

    iget-object v1, p0, La/a/b/b/f;->a:[I

    aget v1, v1, v0

    add-int/lit8 v0, v0, -0x1

    shl-int/lit8 v2, v1, 0x1

    sub-int/2addr v0, v2

    if-eqz v0, :cond_4

    iget v0, p0, La/a/b/b/f;->b:I

    shl-int/lit8 v2, v1, 0x1

    add-int/lit8 v2, v2, 0x2

    sub-int/2addr v0, v2

    iput v0, p0, La/a/b/b/f;->b:I

    iget v0, p0, La/a/b/b/f;->c:I

    sub-int/2addr v0, v1

    iput v0, p0, La/a/b/b/f;->c:I

    iget v0, p0, La/a/b/b/f;->d:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, La/a/b/b/f;->d:I

    goto :goto_4
.end method
