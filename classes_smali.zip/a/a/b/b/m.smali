.class public interface abstract La/a/b/b/m;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(I)Ljava/lang/String;
.end method
