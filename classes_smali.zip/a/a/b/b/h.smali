.class final La/a/b/b/h;
.super Ljava/lang/Object;


# instance fields
.field public final a:I

.field public final b:I

.field public final c:I

.field public final d:I

.field public final e:[I

.field public final f:[I


# direct methods
.method public constructor <init>(IIII[I[I)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, La/a/b/b/h;->a:I

    iput p2, p0, La/a/b/b/h;->b:I

    iput p3, p0, La/a/b/b/h;->c:I

    iput p4, p0, La/a/b/b/h;->d:I

    iput-object p5, p0, La/a/b/b/h;->e:[I

    iput-object p6, p0, La/a/b/b/h;->f:[I

    return-void
.end method
