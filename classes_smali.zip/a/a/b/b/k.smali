.class public interface abstract La/a/b/b/k;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Ljava/io/InputStream;Ljava/io/OutputStream;)V
.end method
