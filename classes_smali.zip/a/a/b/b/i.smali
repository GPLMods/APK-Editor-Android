.class public final La/a/b/b/i;
.super Ljava/lang/Object;


# instance fields
.field private a:La/a/b/a/e;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private a()La/a/b/a/e;
    .registers 3

    iget-object v0, p0, La/a/b/b/i;->a:La/a/b/a/e;

    if-nez v0, :cond_c

    new-instance v0, La/a/a;

    const-string v1, "Current package is null"

    invoke-direct {v0, v1}, La/a/a;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_c
    iget-object v0, p0, La/a/b/b/i;->a:La/a/b/a/e;

    return-object v0
.end method


# virtual methods
.method public final a(I)Ljava/lang/String;
    .registers 3

    if-eqz p1, :cond_15

    invoke-direct {p0}, La/a/b/b/i;->a()La/a/b/a/e;

    move-result-object v0

    invoke-virtual {v0}, La/a/b/a/e;->d()Lcom/gmail/heagoo/a/c/a;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/gmail/heagoo/a/c/a;->a(I)La/a/b/a/f;

    move-result-object v0

    if-eqz v0, :cond_15

    invoke-virtual {v0}, La/a/b/a/f;->f()Ljava/lang/String;

    move-result-object v0

    :goto_14
    return-object v0

    :cond_15
    const/4 v0, 0x0

    goto :goto_14
.end method

.method public final a(IILjava/lang/String;I)Ljava/lang/String;
    .registers 8

    iget-object v0, p0, La/a/b/b/i;->a:La/a/b/a/e;

    invoke-virtual {v0}, La/a/b/a/e;->g()La/a/b/a/a/x;

    move-result-object v0

    invoke-virtual {v0, p1, p2, p3}, La/a/b/a/a/x;->a(IILjava/lang/String;)La/a/b/a/a/t;

    move-result-object v2

    const/4 v1, 0x0

    if-lez p4, :cond_2b

    :try_start_d
    invoke-direct {p0}, La/a/b/b/i;->a()La/a/b/a/e;

    move-result-object v0

    invoke-virtual {v0}, La/a/b/a/e;->d()Lcom/gmail/heagoo/a/c/a;

    move-result-object v0

    invoke-virtual {v0, p4}, Lcom/gmail/heagoo/a/c/a;->a(I)La/a/b/a/f;

    move-result-object v0

    invoke-virtual {v0}, La/a/b/a/f;->c()La/a/b/a/g;

    move-result-object v0

    invoke-virtual {v0}, La/a/b/a/g;->d()La/a/b/a/a/w;

    move-result-object v0

    check-cast v0, La/a/b/a/a/b;

    invoke-virtual {v0, v2}, La/a/b/a/a/b;->a(La/a/b/a/a/t;)Ljava/lang/String;
    :try_end_26
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_26} :catch_2a

    move-result-object v0

    :goto_27
    if-eqz v0, :cond_2d

    :goto_29
    return-object v0

    :catch_2a
    move-exception v0

    :cond_2b
    move-object v0, v1

    goto :goto_27

    :cond_2d
    invoke-virtual {v2}, La/a/b/a/a/t;->f()Ljava/lang/String;

    move-result-object v0

    goto :goto_29
.end method

.method public final a(La/a/b/a/e;)V
    .registers 2

    iput-object p1, p0, La/a/b/b/i;->a:La/a/b/a/e;

    return-void
.end method
