.class public final La/a/b/b/l;
.super Ljava/lang/Object;


# instance fields
.field private final a:Ljava/util/Map;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, La/a/b/b/l;->a:Ljava/util/Map;

    return-void
.end method


# virtual methods
.method public final a(Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/lang/String;)V
    .registers 7

    iget-object v0, p0, La/a/b/b/l;->a:Ljava/util/Map;

    invoke-interface {v0, p3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a/b/b/k;

    if-nez v0, :cond_1f

    new-instance v0, La/a/a;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Unkown DER: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, La/a/a;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1f
    invoke-interface {v0, p1, p2}, La/a/b/b/k;->a(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    return-void
.end method

.method public final a(Ljava/lang/String;La/a/b/b/k;)V
    .registers 4

    iget-object v0, p0, La/a/b/b/l;->a:Ljava/util/Map;

    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method
