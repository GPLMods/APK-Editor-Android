.class public La/a/b/b/e;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/res/XmlResourceParser;


# static fields
.field private static final t:Ljava/util/logging/Logger;


# instance fields
.field private a:Z

.field private b:Ljava/lang/String;

.field private c:La/d/f;

.field private d:La/a/b/b/i;

.field private e:La/a/a;

.field private f:Z

.field private g:La/a/b/b/n;

.field private h:[I

.field private i:La/a/b/b/f;

.field private j:Ljava/lang/String;

.field private k:Z

.field private l:I

.field private m:I

.field private n:I

.field private o:I

.field private p:[I

.field private q:I

.field private r:I

.field private s:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, La/a/b/b/e;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v0

    sput-object v0, La/a/b/b/e;->t:Ljava/util/logging/Logger;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean v0, p0, La/a/b/b/e;->a:Z

    iput-boolean v0, p0, La/a/b/b/e;->f:Z

    new-instance v0, La/a/b/b/f;

    invoke-direct {v0}, La/a/b/b/f;-><init>()V

    iput-object v0, p0, La/a/b/b/e;->i:La/a/b/b/f;

    const-string v0, "http://schemas.android.com/apk/res/android"

    iput-object v0, p0, La/a/b/b/e;->j:Ljava/lang/String;

    invoke-direct {p0}, La/a/b/b/e;->a()V

    return-void
.end method

.method private final a(I)I
    .registers 5

    iget v0, p0, La/a/b/b/e;->l:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_d

    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    const-string v1, "Current event is not START_TAG."

    invoke-direct {v0, v1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_d
    mul-int/lit8 v0, p1, 0x5

    iget-object v1, p0, La/a/b/b/e;->p:[I

    array-length v1, v1

    if-lt v0, v1, :cond_2f

    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Invalid attribute index ("

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ")."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2f
    return v0
.end method

.method private final a(Ljava/lang/String;Ljava/lang/String;)I
    .registers 9

    const/4 v1, -0x1

    iget-object v0, p0, La/a/b/b/e;->g:La/a/b/b/n;

    if-eqz v0, :cond_7

    if-nez p2, :cond_8

    :cond_7
    :goto_7
    return v1

    :cond_8
    iget-object v0, p0, La/a/b/b/e;->g:La/a/b/b/n;

    invoke-virtual {v0, p2}, La/a/b/b/n;->a(Ljava/lang/String;)I

    move-result v3

    if-eq v3, v1, :cond_7

    if-eqz p1, :cond_31

    iget-object v0, p0, La/a/b/b/e;->g:La/a/b/b/n;

    invoke-virtual {v0, p1}, La/a/b/b/n;->a(Ljava/lang/String;)I

    move-result v0

    :goto_18
    const/4 v2, 0x0

    :goto_19
    iget-object v4, p0, La/a/b/b/e;->p:[I

    array-length v4, v4

    if-eq v2, v4, :cond_7

    iget-object v4, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v5, v2, 0x1

    aget v4, v4, v5

    if-ne v3, v4, :cond_33

    if-eq v0, v1, :cond_2e

    iget-object v4, p0, La/a/b/b/e;->p:[I

    aget v4, v4, v2

    if-ne v0, v4, :cond_33

    :cond_2e
    div-int/lit8 v1, v2, 0x5

    goto :goto_7

    :cond_31
    move v0, v1

    goto :goto_18

    :cond_33
    add-int/lit8 v2, v2, 0x5

    goto :goto_19
.end method

.method private final a()V
    .registers 3

    const/4 v1, -0x1

    iput v1, p0, La/a/b/b/e;->l:I

    iput v1, p0, La/a/b/b/e;->m:I

    iput v1, p0, La/a/b/b/e;->n:I

    iput v1, p0, La/a/b/b/e;->o:I

    const/4 v0, 0x0

    iput-object v0, p0, La/a/b/b/e;->p:[I

    iput v1, p0, La/a/b/b/e;->q:I

    iput v1, p0, La/a/b/b/e;->r:I

    iput v1, p0, La/a/b/b/e;->s:I

    return-void
.end method

.method private final b()V
    .registers 10

    const v8, 0x100100

    const/4 v0, 0x3

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x4

    iget-object v1, p0, La/a/b/b/e;->g:La/a/b/b/n;

    if-nez v1, :cond_48

    iget-object v1, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v1}, La/d/f;->readInt()I

    move-result v1

    const v2, 0x80003

    if-eq v1, v2, :cond_34

    new-instance v0, Ljava/io/IOException;

    const-string v2, "Expected: 0x%08x, got: 0x%08x"

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const v4, 0x80003

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v3, v6

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_34
    iget-object v1, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v1, v5}, La/d/f;->skipBytes(I)I

    iget-object v1, p0, La/a/b/b/e;->c:La/d/f;

    invoke-static {v1}, La/a/b/b/n;->a(La/d/f;)La/a/b/b/n;

    move-result-object v1

    iput-object v1, p0, La/a/b/b/e;->g:La/a/b/b/n;

    iget-object v1, p0, La/a/b/b/e;->i:La/a/b/b/f;

    invoke-virtual {v1}, La/a/b/b/f;->e()V

    iput-boolean v6, p0, La/a/b/b/e;->f:Z

    :cond_48
    iget v1, p0, La/a/b/b/e;->l:I

    if-ne v1, v6, :cond_4d

    :goto_4c
    return-void

    :cond_4d
    iget v2, p0, La/a/b/b/e;->l:I

    invoke-direct {p0}, La/a/b/b/e;->a()V

    :cond_52
    :goto_52
    iget-boolean v1, p0, La/a/b/b/e;->k:Z

    if-eqz v1, :cond_5d

    iput-boolean v7, p0, La/a/b/b/e;->k:Z

    iget-object v1, p0, La/a/b/b/e;->i:La/a/b/b/f;

    invoke-virtual {v1}, La/a/b/b/f;->f()V

    :cond_5d
    if-ne v2, v0, :cond_72

    iget-object v1, p0, La/a/b/b/e;->i:La/a/b/b/f;

    invoke-virtual {v1}, La/a/b/b/f;->d()I

    move-result v1

    if-ne v1, v6, :cond_72

    iget-object v1, p0, La/a/b/b/e;->i:La/a/b/b/f;

    invoke-virtual {v1}, La/a/b/b/f;->b()I

    move-result v1

    if-nez v1, :cond_72

    iput v6, p0, La/a/b/b/e;->l:I

    goto :goto_4c

    :cond_72
    if-nez v2, :cond_a5

    const v1, 0x100102

    :goto_77
    const v3, 0x80180

    if-ne v1, v3, :cond_b9

    iget-object v1, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v1}, La/d/f;->readInt()I

    move-result v1

    const/16 v3, 0x8

    if-lt v1, v3, :cond_8a

    rem-int/lit8 v3, v1, 0x4

    if-eqz v3, :cond_ac

    :cond_8a
    new-instance v0, Ljava/io/IOException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Invalid resource ids size ("

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ")."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_a5
    iget-object v1, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v1}, La/d/f;->readInt()I

    move-result v1

    goto :goto_77

    :cond_ac
    iget-object v3, p0, La/a/b/b/e;->c:La/d/f;

    div-int/lit8 v1, v1, 0x4

    add-int/lit8 v1, v1, -0x2

    invoke-virtual {v3, v1}, La/d/f;->a(I)[I

    move-result-object v1

    iput-object v1, p0, La/a/b/b/e;->h:[I

    goto :goto_52

    :cond_b9
    if-lt v1, v8, :cond_c0

    const v3, 0x100104

    if-le v1, v3, :cond_db

    :cond_c0
    new-instance v0, Ljava/io/IOException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Invalid chunk type ("

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ")."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_db
    const v3, 0x100102

    if-ne v1, v3, :cond_e7

    const/4 v3, -0x1

    if-ne v2, v3, :cond_e7

    iput v7, p0, La/a/b/b/e;->l:I

    goto/16 :goto_4c

    :cond_e7
    iget-object v3, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v3, v5}, La/d/f;->skipBytes(I)I

    iget-object v3, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v3}, La/d/f;->readInt()I

    move-result v3

    iget-object v4, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v4, v5}, La/d/f;->skipBytes(I)I

    if-eq v1, v8, :cond_fe

    const v4, 0x100101

    if-ne v1, v4, :cond_124

    :cond_fe
    if-ne v1, v8, :cond_113

    iget-object v1, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v1}, La/d/f;->readInt()I

    move-result v1

    iget-object v3, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v3}, La/d/f;->readInt()I

    move-result v3

    iget-object v4, p0, La/a/b/b/e;->i:La/a/b/b/f;

    invoke-virtual {v4, v1, v3}, La/a/b/b/f;->a(II)V

    goto/16 :goto_52

    :cond_113
    iget-object v1, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v1, v5}, La/d/f;->skipBytes(I)I

    iget-object v1, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v1, v5}, La/d/f;->skipBytes(I)I

    iget-object v1, p0, La/a/b/b/e;->i:La/a/b/b/f;

    invoke-virtual {v1}, La/a/b/b/f;->c()Z

    goto/16 :goto_52

    :cond_124
    iput v3, p0, La/a/b/b/e;->m:I

    const v3, 0x100102

    if-ne v1, v3, :cond_190

    iget-object v1, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v1}, La/d/f;->readInt()I

    move-result v1

    iput v1, p0, La/a/b/b/e;->o:I

    iget-object v1, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v1}, La/d/f;->readInt()I

    move-result v1

    iput v1, p0, La/a/b/b/e;->n:I

    iget-object v1, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v1, v5}, La/d/f;->skipBytes(I)I

    iget-object v1, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v1}, La/d/f;->readInt()I

    move-result v1

    ushr-int/lit8 v2, v1, 0x10

    add-int/lit8 v2, v2, -0x1

    iput v2, p0, La/a/b/b/e;->q:I

    const v2, 0xffff

    and-int/2addr v1, v2

    iget-object v2, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v2}, La/d/f;->readInt()I

    move-result v2

    iput v2, p0, La/a/b/b/e;->r:I

    iget v2, p0, La/a/b/b/e;->r:I

    ushr-int/lit8 v2, v2, 0x10

    add-int/lit8 v2, v2, -0x1

    iput v2, p0, La/a/b/b/e;->s:I

    iget v2, p0, La/a/b/b/e;->r:I

    const v3, 0xffff

    and-int/2addr v2, v3

    add-int/lit8 v2, v2, -0x1

    iput v2, p0, La/a/b/b/e;->r:I

    iget-object v2, p0, La/a/b/b/e;->c:La/d/f;

    mul-int/lit8 v1, v1, 0x5

    invoke-virtual {v2, v1}, La/d/f;->a(I)[I

    move-result-object v1

    iput-object v1, p0, La/a/b/b/e;->p:[I

    :goto_174
    iget-object v1, p0, La/a/b/b/e;->p:[I

    array-length v1, v1

    if-ge v0, v1, :cond_186

    iget-object v1, p0, La/a/b/b/e;->p:[I

    iget-object v2, p0, La/a/b/b/e;->p:[I

    aget v2, v2, v0

    ushr-int/lit8 v2, v2, 0x18

    aput v2, v1, v0

    add-int/lit8 v0, v0, 0x5

    goto :goto_174

    :cond_186
    iget-object v0, p0, La/a/b/b/e;->i:La/a/b/b/f;

    invoke-virtual {v0}, La/a/b/b/f;->e()V

    const/4 v0, 0x2

    iput v0, p0, La/a/b/b/e;->l:I

    goto/16 :goto_4c

    :cond_190
    const v3, 0x100103

    if-ne v1, v3, :cond_1ab

    iget-object v1, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v1}, La/d/f;->readInt()I

    move-result v1

    iput v1, p0, La/a/b/b/e;->o:I

    iget-object v1, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v1}, La/d/f;->readInt()I

    move-result v1

    iput v1, p0, La/a/b/b/e;->n:I

    iput v0, p0, La/a/b/b/e;->l:I

    iput-boolean v6, p0, La/a/b/b/e;->k:Z

    goto/16 :goto_4c

    :cond_1ab
    const v3, 0x100104

    if-ne v1, v3, :cond_52

    iget-object v0, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v0}, La/d/f;->readInt()I

    move-result v0

    iput v0, p0, La/a/b/b/e;->n:I

    iget-object v0, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v0, v5}, La/d/f;->skipBytes(I)I

    iget-object v0, p0, La/a/b/b/e;->c:La/d/f;

    invoke-virtual {v0, v5}, La/d/f;->skipBytes(I)I

    iput v5, p0, La/a/b/b/e;->l:I

    goto/16 :goto_4c
.end method


# virtual methods
.method public final a(La/a/b/b/i;)V
    .registers 2

    iput-object p1, p0, La/a/b/b/e;->d:La/a/b/b/i;

    return-void
.end method

.method public final a(Z)V
    .registers 2

    iput-boolean p1, p0, La/a/b/b/e;->a:Z

    return-void
.end method

.method public close()V
    .registers 3

    const/4 v1, 0x0

    iget-boolean v0, p0, La/a/b/b/e;->f:Z

    if-nez v0, :cond_6

    :goto_5
    return-void

    :cond_6
    const/4 v0, 0x0

    iput-boolean v0, p0, La/a/b/b/e;->f:Z

    iput-object v1, p0, La/a/b/b/e;->c:La/d/f;

    iput-object v1, p0, La/a/b/b/e;->g:La/a/b/b/n;

    iput-object v1, p0, La/a/b/b/e;->h:[I

    iget-object v0, p0, La/a/b/b/e;->i:La/a/b/b/f;

    invoke-virtual {v0}, La/a/b/b/f;->a()V

    invoke-direct {p0}, La/a/b/b/e;->a()V

    goto :goto_5
.end method

.method public defineEntityReplacementText(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v1, "Method is not supported."

    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public getAttributeBooleanValue(IZ)Z
    .registers 6

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz p2, :cond_c

    move v0, v1

    :goto_5
    invoke-virtual {p0, p1, v0}, La/a/b/b/e;->getAttributeIntValue(II)I

    move-result v0

    if-eqz v0, :cond_e

    :goto_b
    return v1

    :cond_c
    move v0, v2

    goto :goto_5

    :cond_e
    move v1, v2

    goto :goto_b
.end method

.method public getAttributeBooleanValue(Ljava/lang/String;Ljava/lang/String;Z)Z
    .registers 6

    invoke-direct {p0, p1, p2}, La/a/b/b/e;->a(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_8

    :goto_7
    return p3

    :cond_8
    invoke-virtual {p0, v0, p3}, La/a/b/b/e;->getAttributeBooleanValue(IZ)Z

    move-result p3

    goto :goto_7
.end method

.method public getAttributeCount()I
    .registers 3

    iget v0, p0, La/a/b/b/e;->l:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_7

    const/4 v0, -0x1

    :goto_6
    return v0

    :cond_7
    iget-object v0, p0, La/a/b/b/e;->p:[I

    array-length v0, v0

    div-int/lit8 v0, v0, 0x5

    goto :goto_6
.end method

.method public getAttributeFloatValue(IF)F
    .registers 6

    invoke-direct {p0, p1}, La/a/b/b/e;->a(I)I

    move-result v0

    iget-object v1, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v2, v0, 0x3

    aget v1, v1, v2

    const/4 v2, 0x4

    if-ne v1, v2, :cond_17

    iget-object v1, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v0, v0, 0x4

    aget v0, v1, v0

    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p2

    :cond_17
    return p2
.end method

.method public getAttributeFloatValue(Ljava/lang/String;Ljava/lang/String;F)F
    .registers 6

    invoke-direct {p0, p1, p2}, La/a/b/b/e;->a(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_8

    :goto_7
    return p3

    :cond_8
    invoke-virtual {p0, v0, p3}, La/a/b/b/e;->getAttributeFloatValue(IF)F

    move-result p3

    goto :goto_7
.end method

.method public getAttributeIntValue(II)I
    .registers 6

    invoke-direct {p0, p1}, La/a/b/b/e;->a(I)I

    move-result v0

    iget-object v1, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v2, v0, 0x3

    aget v1, v1, v2

    const/16 v2, 0x10

    if-lt v1, v2, :cond_18

    const/16 v2, 0x1f

    if-gt v1, v2, :cond_18

    iget-object v1, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v0, v0, 0x4

    aget p2, v1, v0

    :cond_18
    return p2
.end method

.method public getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I
    .registers 6

    invoke-direct {p0, p1, p2}, La/a/b/b/e;->a(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_8

    :goto_7
    return p3

    :cond_8
    invoke-virtual {p0, v0, p3}, La/a/b/b/e;->getAttributeIntValue(II)I

    move-result p3

    goto :goto_7
.end method

.method public getAttributeListValue(I[Ljava/lang/String;I)I
    .registers 5

    const/4 v0, 0x0

    return v0
.end method

.method public getAttributeListValue(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;I)I
    .registers 6

    const/4 v0, 0x0

    return v0
.end method

.method public getAttributeName(I)Ljava/lang/String;
    .registers 5

    invoke-direct {p0, p1}, La/a/b/b/e;->a(I)I

    move-result v0

    iget-object v1, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v0, v0, 0x1

    aget v0, v1, v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_10

    const-string v0, ""

    :goto_f
    return-object v0

    :cond_10
    :try_start_10
    invoke-virtual {p0, p1}, La/a/b/b/e;->getAttributeNameResource(I)I

    move-result v1

    if-eqz v1, :cond_1e

    iget-object v2, p0, La/a/b/b/e;->d:La/a/b/b/i;

    invoke-virtual {v2, v1}, La/a/b/b/i;->a(I)Ljava/lang/String;
    :try_end_1b
    .catch La/a/a; {:try_start_10 .. :try_end_1b} :catch_25
    .catch Ljava/lang/NullPointerException; {:try_start_10 .. :try_end_1b} :catch_1d

    move-result-object v0

    goto :goto_f

    :catch_1d
    move-exception v1

    :cond_1e
    :goto_1e
    iget-object v1, p0, La/a/b/b/e;->g:La/a/b/b/n;

    invoke-virtual {v1, v0}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_f

    :catch_25
    move-exception v1

    goto :goto_1e
.end method

.method public getAttributeNameResource(I)I
    .registers 4

    invoke-direct {p0, p1}, La/a/b/b/e;->a(I)I

    move-result v0

    iget-object v1, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v0, v0, 0x1

    aget v0, v1, v0

    iget-object v1, p0, La/a/b/b/e;->h:[I

    if-eqz v1, :cond_15

    if-ltz v0, :cond_15

    iget-object v1, p0, La/a/b/b/e;->h:[I

    array-length v1, v1

    if-lt v0, v1, :cond_17

    :cond_15
    const/4 v0, 0x0

    :goto_16
    return v0

    :cond_17
    iget-object v1, p0, La/a/b/b/e;->h:[I

    aget v0, v1, v0

    goto :goto_16
.end method

.method public getAttributeNamespace(I)Ljava/lang/String;
    .registers 6

    const/high16 v3, 0x7f000000

    invoke-direct {p0, p1}, La/a/b/b/e;->a(I)I

    move-result v0

    iget-object v1, p0, La/a/b/b/e;->p:[I

    aget v1, v1, v0

    const/4 v2, -0x1

    if-ne v1, v2, :cond_10

    const-string v1, ""

    :cond_f
    :goto_f
    return-object v1

    :cond_10
    iget-object v2, p0, La/a/b/b/e;->g:La/a/b/b/n;

    invoke-virtual {v2, v1}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_1e

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-nez v2, :cond_f

    :cond_1e
    iget-object v2, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v0, v0, 0x1

    aget v0, v2, v0

    iget-object v2, p0, La/a/b/b/e;->h:[I

    if-eqz v2, :cond_66

    if-ltz v0, :cond_66

    iget-object v2, p0, La/a/b/b/e;->h:[I

    array-length v2, v2

    if-ge v0, v2, :cond_66

    iget-object v2, p0, La/a/b/b/e;->h:[I

    aget v2, v2, v0

    and-int/2addr v2, v3

    if-ne v2, v3, :cond_66

    iget-object v0, p0, La/a/b/b/e;->b:Ljava/lang/String;

    if-nez v0, :cond_5d

    const/4 v0, 0x0

    :goto_3b
    iget-object v2, p0, La/a/b/b/e;->g:La/a/b/b/n;

    invoke-virtual {v2}, La/a/b/b/n;->a()I

    move-result v2

    if-ge v0, v2, :cond_5d

    iget-object v2, p0, La/a/b/b/e;->g:La/a/b/b/n;

    invoke-virtual {v2, v0}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_63

    const-string v3, "http://"

    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_63

    iget-object v3, p0, La/a/b/b/e;->j:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_63

    iput-object v2, p0, La/a/b/b/e;->b:Ljava/lang/String;

    :cond_5d
    iget-object v0, p0, La/a/b/b/e;->b:Ljava/lang/String;

    if-eqz v0, :cond_75

    :goto_61
    move-object v1, v0

    goto :goto_f

    :cond_63
    add-int/lit8 v0, v0, 0x1

    goto :goto_3b

    :cond_66
    iget-object v2, p0, La/a/b/b/e;->g:La/a/b/b/n;

    invoke-virtual {v2, v0}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_f

    iget-object v1, p0, La/a/b/b/e;->j:Ljava/lang/String;

    goto :goto_f

    :cond_75
    move-object v0, v1

    goto :goto_61
.end method

.method public getAttributePrefix(I)Ljava/lang/String;
    .registers 4

    invoke-direct {p0, p1}, La/a/b/b/e;->a(I)I

    move-result v0

    iget-object v1, p0, La/a/b/b/e;->p:[I

    aget v0, v1, v0

    iget-object v1, p0, La/a/b/b/e;->i:La/a/b/b/f;

    invoke-virtual {v1, v0}, La/a/b/b/f;->d(I)I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_14

    const-string v0, ""

    :goto_13
    return-object v0

    :cond_14
    iget-object v1, p0, La/a/b/b/e;->g:La/a/b/b/n;

    invoke-virtual {v1, v0}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_13
.end method

.method public getAttributeResourceValue(II)I
    .registers 6

    invoke-direct {p0, p1}, La/a/b/b/e;->a(I)I

    move-result v0

    iget-object v1, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v2, v0, 0x3

    aget v1, v1, v2

    const/4 v2, 0x1

    if-ne v1, v2, :cond_13

    iget-object v1, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v0, v0, 0x4

    aget p2, v1, v0

    :cond_13
    return p2
.end method

.method public getAttributeResourceValue(Ljava/lang/String;Ljava/lang/String;I)I
    .registers 6

    invoke-direct {p0, p1, p2}, La/a/b/b/e;->a(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_8

    :goto_7
    return p3

    :cond_8
    invoke-virtual {p0, v0, p3}, La/a/b/b/e;->getAttributeResourceValue(II)I

    move-result p3

    goto :goto_7
.end method

.method public getAttributeType(I)Ljava/lang/String;
    .registers 3

    const-string v0, "CDATA"

    return-object v0
.end method

.method public getAttributeUnsignedIntValue(II)I
    .registers 4

    invoke-virtual {p0, p1, p2}, La/a/b/b/e;->getAttributeIntValue(II)I

    move-result v0

    return v0
.end method

.method public getAttributeUnsignedIntValue(Ljava/lang/String;Ljava/lang/String;I)I
    .registers 6

    invoke-direct {p0, p1, p2}, La/a/b/b/e;->a(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_8

    :goto_7
    return p3

    :cond_8
    invoke-virtual {p0, v0, p3}, La/a/b/b/e;->getAttributeUnsignedIntValue(II)I

    move-result p3

    goto :goto_7
.end method

.method public getAttributeValue(I)Ljava/lang/String;
    .registers 11

    const/4 v0, 0x0

    const/high16 v5, 0x7f000000

    invoke-direct {p0, p1}, La/a/b/b/e;->a(I)I

    move-result v1

    iget-object v2, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v3, v1, 0x3

    aget v2, v2, v3

    iget-object v3, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v4, v1, 0x4

    aget v3, v3, v4

    iget-object v4, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v1, v1, 0x2

    aget v1, v4, v1

    iget-object v4, p0, La/a/b/b/e;->d:La/a/b/b/i;

    if-eqz v4, :cond_6b

    const/4 v4, -0x1

    if-ne v1, v4, :cond_34

    move-object v1, v0

    :goto_21
    :try_start_21
    iget-boolean v4, p0, La/a/b/b/e;->a:Z

    if-eqz v4, :cond_70

    and-int v4, v3, v5

    if-ne v4, v5, :cond_70

    :goto_29
    iget-object v1, p0, La/a/b/b/e;->d:La/a/b/b/i;

    invoke-virtual {p0, p1}, La/a/b/b/e;->getAttributeNameResource(I)I

    move-result v4

    invoke-virtual {v1, v2, v3, v0, v4}, La/a/b/b/i;->a(IILjava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    :goto_33
    return-object v0

    :cond_34
    iget-object v4, p0, La/a/b/b/e;->g:La/a/b/b/n;

    invoke-virtual {v4, v1}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/gmail/heagoo/a/c/a;->a(Ljava/lang/String;)Ljava/lang/String;
    :try_end_3d
    .catch La/a/a; {:try_start_21 .. :try_end_3d} :catch_3f

    move-result-object v1

    goto :goto_21

    :catch_3f
    move-exception v0

    iget-object v1, p0, La/a/b/b/e;->e:La/a/a;

    if-nez v1, :cond_46

    iput-object v0, p0, La/a/b/b/e;->e:La/a/a;

    :cond_46
    sget-object v1, La/a/b/b/e;->t:Ljava/util/logging/Logger;

    sget-object v4, Ljava/util/logging/Level;->WARNING:Ljava/util/logging/Level;

    const-string v5, "Could not decode attr value, using raw value instead: ns=%s, name=%s, value=0x%08x"

    const/4 v6, 0x3

    new-array v6, v6, [Ljava/lang/Object;

    const/4 v7, 0x0

    invoke-virtual {p0, p1}, La/a/b/b/e;->getAttributePrefix(I)Ljava/lang/String;

    move-result-object v8

    aput-object v8, v6, v7

    const/4 v7, 0x1

    invoke-virtual {p0, p1}, La/a/b/b/e;->getAttributeName(I)Ljava/lang/String;

    move-result-object v8

    aput-object v8, v6, v7

    const/4 v7, 0x2

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v6, v7

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v4, v5, v0}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_6b
    invoke-static {v2, v3}, Landroid/util/TypedValue;->coerceToString(II)Ljava/lang/String;

    move-result-object v0

    goto :goto_33

    :cond_70
    move-object v0, v1

    goto :goto_29
.end method

.method public getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    invoke-direct {p0, p1, p2}, La/a/b/b/e;->a(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_a

    const-string v0, ""

    :goto_9
    return-object v0

    :cond_a
    invoke-virtual {p0, v0}, La/a/b/b/e;->getAttributeValue(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_9
.end method

.method public getClassAttribute()Ljava/lang/String;
    .registers 3

    iget v0, p0, La/a/b/b/e;->r:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_7

    const/4 v0, 0x0

    :goto_6
    return-object v0

    :cond_7
    iget v0, p0, La/a/b/b/e;->r:I

    invoke-direct {p0, v0}, La/a/b/b/e;->a(I)I

    move-result v0

    iget-object v1, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v0, v0, 0x2

    aget v0, v1, v0

    iget-object v1, p0, La/a/b/b/e;->g:La/a/b/b/n;

    invoke-virtual {v1, v0}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_6
.end method

.method public getColumnNumber()I
    .registers 2

    const/4 v0, -0x1

    return v0
.end method

.method public getDepth()I
    .registers 2

    iget-object v0, p0, La/a/b/b/e;->i:La/a/b/b/f;

    invoke-virtual {v0}, La/a/b/b/f;->d()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    return v0
.end method

.method public getEventType()I
    .registers 2

    iget v0, p0, La/a/b/b/e;->l:I

    return v0
.end method

.method public getFeature(Ljava/lang/String;)Z
    .registers 3

    const/4 v0, 0x0

    return v0
.end method

.method public getIdAttribute()Ljava/lang/String;
    .registers 3

    iget v0, p0, La/a/b/b/e;->q:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_7

    const/4 v0, 0x0

    :goto_6
    return-object v0

    :cond_7
    iget v0, p0, La/a/b/b/e;->q:I

    invoke-direct {p0, v0}, La/a/b/b/e;->a(I)I

    move-result v0

    iget-object v1, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v0, v0, 0x2

    aget v0, v1, v0

    iget-object v1, p0, La/a/b/b/e;->g:La/a/b/b/n;

    invoke-virtual {v1, v0}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_6
.end method

.method public getIdAttributeResourceValue(I)I
    .registers 5

    iget v0, p0, La/a/b/b/e;->q:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_6

    :cond_5
    :goto_5
    return p1

    :cond_6
    iget v0, p0, La/a/b/b/e;->q:I

    invoke-direct {p0, v0}, La/a/b/b/e;->a(I)I

    move-result v0

    iget-object v1, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v2, v0, 0x3

    aget v1, v1, v2

    const/4 v2, 0x1

    if-ne v1, v2, :cond_5

    iget-object v1, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v0, v0, 0x4

    aget p1, v1, v0

    goto :goto_5
.end method

.method public getInputEncoding()Ljava/lang/String;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public getLineNumber()I
    .registers 2

    iget v0, p0, La/a/b/b/e;->m:I

    return v0
.end method

.method public getName()Ljava/lang/String;
    .registers 3

    iget v0, p0, La/a/b/b/e;->n:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_f

    iget v0, p0, La/a/b/b/e;->l:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_11

    iget v0, p0, La/a/b/b/e;->l:I

    const/4 v1, 0x3

    if-eq v0, v1, :cond_11

    :cond_f
    const/4 v0, 0x0

    :goto_10
    return-object v0

    :cond_11
    iget-object v0, p0, La/a/b/b/e;->g:La/a/b/b/n;

    iget v1, p0, La/a/b/b/e;->n:I

    invoke-virtual {v0, v1}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_10
.end method

.method public getNamespace()Ljava/lang/String;
    .registers 3

    iget-object v0, p0, La/a/b/b/e;->g:La/a/b/b/n;

    iget v1, p0, La/a/b/b/e;->o:I

    invoke-virtual {v0, v1}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getNamespace(Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Method is not supported."

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public getNamespaceCount(I)I
    .registers 3

    iget-object v0, p0, La/a/b/b/e;->i:La/a/b/b/f;

    invoke-virtual {v0, p1}, La/a/b/b/f;->a(I)I

    move-result v0

    return v0
.end method

.method public getNamespacePrefix(I)Ljava/lang/String;
    .registers 4

    iget-object v0, p0, La/a/b/b/e;->i:La/a/b/b/f;

    invoke-virtual {v0, p1}, La/a/b/b/f;->b(I)I

    move-result v0

    iget-object v1, p0, La/a/b/b/e;->g:La/a/b/b/n;

    invoke-virtual {v1, v0}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getNamespaceUri(I)Ljava/lang/String;
    .registers 4

    iget-object v0, p0, La/a/b/b/e;->i:La/a/b/b/f;

    invoke-virtual {v0, p1}, La/a/b/b/f;->c(I)I

    move-result v0

    iget-object v1, p0, La/a/b/b/e;->g:La/a/b/b/n;

    invoke-virtual {v1, v0}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getPositionDescription()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "XML line #"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, La/a/b/b/e;->getLineNumber()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getPrefix()Ljava/lang/String;
    .registers 3

    iget-object v0, p0, La/a/b/b/e;->i:La/a/b/b/f;

    iget v1, p0, La/a/b/b/e;->o:I

    invoke-virtual {v0, v1}, La/a/b/b/f;->d(I)I

    move-result v0

    iget-object v1, p0, La/a/b/b/e;->g:La/a/b/b/n;

    invoke-virtual {v1, v0}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getProperty(Ljava/lang/String;)Ljava/lang/Object;
    .registers 3

    const/4 v0, 0x0

    return-object v0
.end method

.method public getStyleAttribute()I
    .registers 3

    iget v0, p0, La/a/b/b/e;->s:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_7

    const/4 v0, 0x0

    :goto_6
    return v0

    :cond_7
    iget v0, p0, La/a/b/b/e;->s:I

    invoke-direct {p0, v0}, La/a/b/b/e;->a(I)I

    move-result v0

    iget-object v1, p0, La/a/b/b/e;->p:[I

    add-int/lit8 v0, v0, 0x4

    aget v0, v1, v0

    goto :goto_6
.end method

.method public getText()Ljava/lang/String;
    .registers 3

    iget v0, p0, La/a/b/b/e;->n:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_a

    iget v0, p0, La/a/b/b/e;->l:I

    const/4 v1, 0x4

    if-eq v0, v1, :cond_c

    :cond_a
    const/4 v0, 0x0

    :goto_b
    return-object v0

    :cond_c
    iget-object v0, p0, La/a/b/b/e;->g:La/a/b/b/n;

    iget v1, p0, La/a/b/b/e;->n:I

    invoke-virtual {v0, v1}, La/a/b/b/n;->a(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_b
.end method

.method public getTextCharacters([I)[C
    .registers 6

    const/4 v3, 0x0

    invoke-virtual {p0}, La/a/b/b/e;->getText()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_9

    const/4 v0, 0x0

    :goto_8
    return-object v0

    :cond_9
    aput v3, p1, v3

    const/4 v0, 0x1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    aput v2, p1, v0

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v0

    new-array v0, v0, [C

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    invoke-virtual {v1, v3, v2, v0, v3}, Ljava/lang/String;->getChars(II[CI)V

    goto :goto_8
.end method

.method public isAttributeDefault(I)Z
    .registers 3

    const/4 v0, 0x0

    return v0
.end method

.method public isEmptyElementTag()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public isWhitespace()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public next()I
    .registers 4

    iget-object v0, p0, La/a/b/b/e;->c:La/d/f;

    if-nez v0, :cond_d

    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v1, "Parser is null."

    const/4 v2, 0x0

    invoke-direct {v0, v1, p0, v2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/Throwable;)V

    throw v0

    :cond_d
    :try_start_d
    invoke-direct {p0}, La/a/b/b/e;->b()V

    iget v0, p0, La/a/b/b/e;->l:I
    :try_end_12
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_12} :catch_13

    return v0

    :catch_13
    move-exception v0

    invoke-virtual {p0}, La/a/b/b/e;->close()V

    throw v0
.end method

.method public nextTag()I
    .registers 4

    invoke-virtual {p0}, La/a/b/b/e;->next()I

    move-result v0

    const/4 v1, 0x4

    if-ne v0, v1, :cond_11

    invoke-virtual {p0}, La/a/b/b/e;->isWhitespace()Z

    move-result v1

    if-eqz v1, :cond_11

    invoke-virtual {p0}, La/a/b/b/e;->next()I

    move-result v0

    :cond_11
    const/4 v1, 0x2

    if-eq v0, v1, :cond_20

    const/4 v1, 0x3

    if-eq v0, v1, :cond_20

    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v1, "Expected start or end tag."

    const/4 v2, 0x0

    invoke-direct {v0, v1, p0, v2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/Throwable;)V

    throw v0

    :cond_20
    return v0
.end method

.method public nextText()Ljava/lang/String;
    .registers 5

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, La/a/b/b/e;->getEventType()I

    move-result v0

    const/4 v1, 0x2

    if-eq v0, v1, :cond_11

    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v1, "Parser must be on START_TAG to read next text."

    invoke-direct {v0, v1, p0, v2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/Throwable;)V

    throw v0

    :cond_11
    invoke-virtual {p0}, La/a/b/b/e;->next()I

    move-result v0

    const/4 v1, 0x4

    if-ne v0, v1, :cond_2a

    invoke-virtual {p0}, La/a/b/b/e;->getText()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, La/a/b/b/e;->next()I

    move-result v1

    if-eq v1, v3, :cond_2e

    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v1, "Event TEXT must be immediately followed by END_TAG."

    invoke-direct {v0, v1, p0, v2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/Throwable;)V

    throw v0

    :cond_2a
    if-ne v0, v3, :cond_2f

    const-string v0, ""

    :cond_2e
    return-object v0

    :cond_2f
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v1, "Parser must be on START_TAG or TEXT to read text."

    invoke-direct {v0, v1, p0, v2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public nextToken()I
    .registers 2

    invoke-virtual {p0}, La/a/b/b/e;->next()I

    move-result v0

    return v0
.end method

.method public require(ILjava/lang/String;Ljava/lang/String;)V
    .registers 7

    invoke-virtual {p0}, La/a/b/b/e;->getEventType()I

    move-result v0

    if-ne p1, v0, :cond_1e

    if-eqz p2, :cond_12

    invoke-virtual {p0}, La/a/b/b/e;->getNamespace()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1e

    :cond_12
    if-eqz p3, :cond_3c

    invoke-virtual {p0}, La/a/b/b/e;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3c

    :cond_1e
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v2, La/a/b/b/e;->TYPES:[Ljava/lang/String;

    aget-object v2, v2, p1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " is expected."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-direct {v0, v1, p0, v2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/Throwable;)V

    throw v0

    :cond_3c
    return-void
.end method

.method public setFeature(Ljava/lang/String;Z)V
    .registers 5

    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v1, "Method is not supported."

    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public setInput(Ljava/io/InputStream;Ljava/lang/String;)V
    .registers 5

    invoke-virtual {p0}, La/a/b/b/e;->close()V

    if-eqz p1, :cond_11

    new-instance v0, La/d/f;

    new-instance v1, La/a/b/a/b;

    invoke-direct {v1, p1}, La/a/b/a/b;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v0, v1}, La/d/f;-><init>(La/a/b/a/b;)V

    iput-object v0, p0, La/a/b/b/e;->c:La/d/f;

    :cond_11
    return-void
.end method

.method public setInput(Ljava/io/Reader;)V
    .registers 4

    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v1, "Method is not supported."

    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public setProperty(Ljava/lang/String;Ljava/lang/Object;)V
    .registers 5

    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v1, "Method is not supported."

    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
