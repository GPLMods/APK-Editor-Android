.class public interface abstract La/a/b/d/a;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Lorg/xmlpull/v1/XmlSerializer;La/a/b/a/g;)V
.end method
