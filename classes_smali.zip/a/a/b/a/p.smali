.class public interface abstract La/a/b/a/p;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a()V
.end method
