.class public final La/a/b/a/j;
.super Ljava/lang/Object;


# instance fields
.field private final a:La/a/b/a/e;

.field private final b:La/a/b/a/i;

.field private final c:La/a/b/a/h;

.field private final d:Ljava/util/Set;


# direct methods
.method public constructor <init>(La/a/b/a/e;La/a/b/a/i;La/a/b/a/h;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object v0, p0, La/a/b/a/j;->d:Ljava/util/Set;

    iput-object p1, p0, La/a/b/a/j;->a:La/a/b/a/e;

    iput-object p2, p0, La/a/b/a/j;->b:La/a/b/a/i;

    iput-object p3, p0, La/a/b/a/j;->c:La/a/b/a/h;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "values"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, La/a/b/a/j;->c:La/a/b/a/h;

    invoke-virtual {v1}, La/a/b/a/h;->a()La/a/b/a/c;

    move-result-object v1

    invoke-virtual {v1}, La/a/b/a/c;->a()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, La/a/b/a/j;->b:La/a/b/a/i;

    invoke-virtual {v1}, La/a/b/a/i;->a()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v0, p0, La/a/b/a/j;->b:La/a/b/a/i;

    invoke-virtual {v0}, La/a/b/a/i;->a()Ljava/lang/String;

    move-result-object v0

    const-string v2, "s"

    invoke-virtual {v0, v2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_44

    const-string v0, ""

    :goto_35
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ".xml"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_44
    const-string v0, "s"

    goto :goto_35
.end method

.method public final a(La/a/b/a/g;)Z
    .registers 4

    iget-object v0, p0, La/a/b/a/j;->a:La/a/b/a/e;

    invoke-virtual {p1}, La/a/b/a/g;->c()La/a/b/a/f;

    move-result-object v1

    invoke-virtual {v1}, La/a/b/a/f;->e()La/a/b/a/d;

    move-result-object v1

    invoke-virtual {v0, v1}, La/a/b/a/e;->c(La/a/b/a/d;)Z

    move-result v0

    return v0
.end method

.method public final b()Ljava/util/Set;
    .registers 2

    iget-object v0, p0, La/a/b/a/j;->d:Ljava/util/Set;

    return-object v0
.end method

.method public final b(La/a/b/a/g;)V
    .registers 3

    iget-object v0, p0, La/a/b/a/j;->d:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    const/4 v0, 0x0

    if-nez p1, :cond_4

    :cond_3
    :goto_3
    return v0

    :cond_4
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    if-ne v1, v2, :cond_3

    check-cast p1, La/a/b/a/j;

    iget-object v1, p0, La/a/b/a/j;->b:La/a/b/a/i;

    iget-object v2, p1, La/a/b/a/j;->b:La/a/b/a/i;

    if-eq v1, v2, :cond_24

    iget-object v1, p0, La/a/b/a/j;->b:La/a/b/a/i;

    if-eqz v1, :cond_3

    iget-object v1, p0, La/a/b/a/j;->b:La/a/b/a/i;

    iget-object v2, p1, La/a/b/a/j;->b:La/a/b/a/i;

    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    :cond_24
    iget-object v1, p0, La/a/b/a/j;->c:La/a/b/a/h;

    iget-object v2, p1, La/a/b/a/j;->c:La/a/b/a/h;

    if-eq v1, v2, :cond_38

    iget-object v1, p0, La/a/b/a/j;->c:La/a/b/a/h;

    if-eqz v1, :cond_3

    iget-object v1, p0, La/a/b/a/j;->c:La/a/b/a/h;

    iget-object v2, p1, La/a/b/a/j;->c:La/a/b/a/h;

    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    :cond_38
    const/4 v0, 0x1

    goto :goto_3
.end method

.method public final hashCode()I
    .registers 4

    const/4 v1, 0x0

    iget-object v0, p0, La/a/b/a/j;->b:La/a/b/a/i;

    if-eqz v0, :cond_1b

    iget-object v0, p0, La/a/b/a/j;->b:La/a/b/a/i;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    :goto_b
    add-int/lit16 v0, v0, 0x20f

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, La/a/b/a/j;->c:La/a/b/a/h;

    if-eqz v2, :cond_19

    iget-object v1, p0, La/a/b/a/j;->c:La/a/b/a/h;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :cond_19
    add-int/2addr v0, v1

    return v0

    :cond_1b
    move v0, v1

    goto :goto_b
.end method
