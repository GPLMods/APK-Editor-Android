.class public final La/a/b/a/f;
.super Ljava/lang/Object;


# instance fields
.field private final a:La/a/b/a/d;

.field private final b:Ljava/lang/String;

.field private final c:La/a/b/a/e;

.field private final d:La/a/b/a/i;

.field private final e:Ljava/util/Map;


# direct methods
.method public constructor <init>(La/a/b/a/d;Ljava/lang/String;La/a/b/a/e;La/a/b/a/i;Z)V
    .registers 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, La/a/b/a/f;->e:Ljava/util/Map;

    iput-object p1, p0, La/a/b/a/f;->a:La/a/b/a/d;

    invoke-virtual {p4, p2}, La/a/b/a/i;->unsafe(Ljava/lang/String;)La/a/b/a/f;

    move-result-object p5

    if-eqz p5, :cond_30

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "dup_"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p1}, La/a/b/a/d;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    :cond_29
    :goto_29
    iput-object p2, p0, La/a/b/a/f;->b:Ljava/lang/String;

    iput-object p3, p0, La/a/b/a/f;->c:La/a/b/a/e;

    iput-object p4, p0, La/a/b/a/f;->d:La/a/b/a/i;

    return-void

    :cond_30
    if-eqz p2, :cond_38

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_29

    :cond_38
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "noname_"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, La/a/b/a/d;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    goto :goto_29
.end method


# virtual methods
.method public final a(La/a/b/a/c;)La/a/b/a/g;
    .registers 6

    iget-object v0, p0, La/a/b/a/f;->e:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a/b/a/g;

    if-nez v0, :cond_1f

    new-instance v0, La/a/a/b;

    const-string v1, "resource: spec=%s, config=%s"

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, La/a/a/b;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1f
    return-object v0
.end method

.method public final a(La/a/b/a/e;Z)Ljava/lang/String;
    .registers 6

    iget-object v0, p0, La/a/b/a/f;->c:La/a/b/a/e;

    invoke-virtual {v0, p1}, La/a/b/a/e;->equals(Ljava/lang/Object;)Z

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    if-eqz v0, :cond_28

    const-string v0, ""

    :goto_f
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    if-eqz p2, :cond_42

    const-string v0, ""

    :goto_17
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0}, La/a/b/a/f;->f()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_28
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, La/a/b/a/f;->c:La/a/b/a/e;

    invoke-virtual {v2}, La/a/b/a/e;->f()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ":"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_f

    :cond_42
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, La/a/b/a/f;->d:La/a/b/a/i;

    invoke-virtual {v2}, La/a/b/a/i;->a()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "/"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_17
.end method

.method public final a()Ljava/util/Set;
    .registers 3

    new-instance v0, Ljava/util/LinkedHashSet;

    iget-object v1, p0, La/a/b/a/f;->e:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    return-object v0
.end method

.method public final a(La/a/b/a/g;)V
    .registers 3

    const/4 v0, 0x1

    invoke-virtual {p0, p1, v0}, La/a/b/a/f;->a(La/a/b/a/g;Z)V

    return-void
.end method

.method public final a(La/a/b/a/g;Z)V
    .registers 5

    invoke-virtual {p1}, La/a/b/a/g;->b()La/a/b/a/h;

    move-result-object v0

    invoke-virtual {v0}, La/a/b/a/h;->a()La/a/b/a/c;

    move-result-object v0

    iget-object v1, p0, La/a/b/a/f;->e:Ljava/util/Map;

    invoke-interface {v1, v0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final b()Ljava/util/Map;
    .registers 2

    iget-object v0, p0, La/a/b/a/f;->e:Ljava/util/Map;

    return-object v0
.end method

.method public final c()La/a/b/a/g;
    .registers 2

    new-instance v0, La/a/b/a/c;

    invoke-direct {v0}, La/a/b/a/c;-><init>()V

    invoke-virtual {p0, v0}, La/a/b/a/f;->a(La/a/b/a/c;)La/a/b/a/g;

    move-result-object v0

    return-object v0
.end method

.method public final d()Z
    .registers 3

    iget-object v0, p0, La/a/b/a/f;->e:Ljava/util/Map;

    new-instance v1, La/a/b/a/c;

    invoke-direct {v1}, La/a/b/a/c;-><init>()V

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public final e()La/a/b/a/d;
    .registers 2

    iget-object v0, p0, La/a/b/a/f;->a:La/a/b/a/d;

    return-object v0
.end method

.method public final f()Ljava/lang/String;
    .registers 4

    iget-object v0, p0, La/a/b/a/f;->b:Ljava/lang/String;

    const-string v1, "\""

    const-string v2, "q"

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final g()La/a/b/a/e;
    .registers 2

    iget-object v0, p0, La/a/b/a/f;->c:La/a/b/a/e;

    return-object v0
.end method

.method public final h()La/a/b/a/i;
    .registers 2

    iget-object v0, p0, La/a/b/a/f;->d:La/a/b/a/i;

    return-object v0
.end method

.method public final i()Z
    .registers 3

    iget-object v0, p0, La/a/b/a/f;->b:Ljava/lang/String;

    const-string v1, "carlos_ae_"

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, La/a/b/a/f;->a:La/a/b/a/d;

    invoke-virtual {v1}, La/a/b/a/d;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, La/a/b/a/f;->d:La/a/b/a/i;

    invoke-virtual {v1}, La/a/b/a/i;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, La/a/b/a/f;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
