.class La/a/b/a/l;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic a:La/a/b/a/k;

.field final synthetic b:I

.field final synthetic c:Landroid/content/Context;

.field final synthetic d:La/a/b/a/m;


# direct methods
.method constructor <init>(La/a/b/a/k;ILandroid/content/Context;La/a/b/a/m;)V
    .registers 5

    iput-object p1, p0, La/a/b/a/l;->a:La/a/b/a/k;

    iput p2, p0, La/a/b/a/l;->b:I

    iput-object p3, p0, La/a/b/a/l;->c:Landroid/content/Context;

    iput-object p4, p0, La/a/b/a/l;->d:La/a/b/a/m;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 4

    iget v0, p0, La/a/b/a/l;->b:I

    if-eq v0, p2, :cond_e

    iget-object v0, p0, La/a/b/a/l;->c:Landroid/content/Context;

    invoke-static {v0, p2}, La/a/b/a/k;->e(Landroid/content/Context;I)V

    iget-object p2, p0, La/a/b/a/l;->d:La/a/b/a/m;

    invoke-interface {p2}, La/a/b/a/m;->a()V

    :cond_e
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    return-void
.end method
