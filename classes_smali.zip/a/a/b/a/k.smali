.class public La/a/b/a/k;
.super Ljava/lang/Object;


# static fields
.field private static final A:Ljava/lang/String; = "aabak"

.field static final MD:[I

.field static final MD_ACCENT:[I

.field static final MD_GOOGLE_BTN_TEXT:[I

.field static final MD_MAIN:[I

.field static final MD_NAMES:[I

.field static final MD_NAV_ACTIVATED:[I

.field static final MD_NAV_NORMAL:[I

.field static final MD_NOACTIONBAR:[I

.field static final MD_PATCHED:[I

.field static final MD_PROGRESS:[I

.field static final MD_RIPPLE:[I

.field static final MD_SYNTAX_1:[I

.field static final MD_SYNTAX_2:[I

.field static final MD_SYNTAX_3:[I

.field static final MD_SYNTAX_4:[I

.field static final MD_SYNTAX_5:[I

.field static final MD_SYNTAX_9:[I

.field static final MD_TEXT_MEDIUM:[I

.field static final MD_TEXT_SMALL:[I

.field public static md:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const/4 v1, 0x4

    new-array v0, v1, [I

    fill-array-data v0, :array_8a

    sput-object v0, La/a/b/a/k;->MD:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_96

    sput-object v0, La/a/b/a/k;->MD_GOOGLE_BTN_TEXT:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_a2

    sput-object v0, La/a/b/a/k;->MD_MAIN:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_ae

    sput-object v0, La/a/b/a/k;->MD_NAMES:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_ba

    sput-object v0, La/a/b/a/k;->MD_NAV_ACTIVATED:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_c6

    sput-object v0, La/a/b/a/k;->MD_NAV_NORMAL:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_d2

    sput-object v0, La/a/b/a/k;->MD_NOACTIONBAR:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_de

    sput-object v0, La/a/b/a/k;->MD_PATCHED:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_ea

    sput-object v0, La/a/b/a/k;->MD_PROGRESS:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_f6

    sput-object v0, La/a/b/a/k;->MD_TEXT_MEDIUM:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_102

    sput-object v0, La/a/b/a/k;->MD_TEXT_SMALL:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_10e

    sput-object v0, La/a/b/a/k;->MD_SYNTAX_1:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_11a

    sput-object v0, La/a/b/a/k;->MD_SYNTAX_2:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_126

    sput-object v0, La/a/b/a/k;->MD_SYNTAX_3:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_132

    sput-object v0, La/a/b/a/k;->MD_SYNTAX_4:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_13e

    sput-object v0, La/a/b/a/k;->MD_SYNTAX_5:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_14a

    sput-object v0, La/a/b/a/k;->MD_SYNTAX_9:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_156

    sput-object v0, La/a/b/a/k;->MD_RIPPLE:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_162

    sput-object v0, La/a/b/a/k;->MD_ACCENT:[I

    const/4 v0, 0x0

    sput-boolean v0, La/a/b/a/k;->md:Z

    return-void

    :array_8a
    .array-data 4
        0x7f0a0176
        0x7f0a0177
        0x7f0a0178
        0x7f0a0179
    .end array-data

    :array_96
    .array-data 4
        0x7f0c010b
        0x7f0c0100
        0x7f0c0101
        0x7f0c0102
    .end array-data

    :array_a2
    .array-data 4
        0x7f0a017a
        0x7f0a017b
        0x7f0a017c
        0x7f0a017d
    .end array-data

    :array_ae
    .array-data 4
        0x7f070275
        0x7f070276
        0x7f070277
        0x7f070278
    .end array-data

    :array_ba
    .array-data 4
        0x7f0c00f3
        0x7f0c00d0
        0x7f0c00d1
        0x7f0c00d2
    .end array-data

    :array_c6
    .array-data 4
        0x7f0c00f2
        0x7f0c00cd
        0x7f0c00ce
        0x7f0c00cf
    .end array-data

    :array_d2
    .array-data 4
        0x7f0a0172
        0x7f0a0173
        0x7f0a0174
        0x7f0a0175
    .end array-data

    :array_de
    .array-data 4
        0x7f0c0110
        0x7f0c0111
        0x7f0c0112
        0x7f0c0113
    .end array-data

    :array_ea
    .array-data 4
        0x7f0c010f
        0x7f0c0108
        0x7f0c0109
        0x7f0c010a
    .end array-data

    :array_f6
    .array-data 4
        0x7f0c010d
        0x7f0c0097
        0x7f0c0098
        0x7f0c0099
    .end array-data

    :array_102
    .array-data 4
        0x7f0c010e
        0x7f0c009a
        0x7f0c009b
        0x7f0c009c
    .end array-data

    :array_10e
    .array-data 4
        0x7f0c0120
        0x7f0c0121
        0x7f0c0122
        0x7f0c0122
    .end array-data

    :array_11a
    .array-data 4
        0x7f0c0123
        0x7f0c0124
        0x7f0c0125
        0x7f0c0125
    .end array-data

    :array_126
    .array-data 4
        0x7f0c0126
        0x7f0c0127
        0x7f0c0128
        0x7f0c0128
    .end array-data

    :array_132
    .array-data 4
        0x7f0c0129
        0x7f0c012a
        0x7f0c012b
        0x7f0c012b
    .end array-data

    :array_13e
    .array-data 4
        0x7f0c012c
        0x7f0c012d
        0x7f0c012e
        0x7f0c012e
    .end array-data

    :array_14a
    .array-data 4
        0x7f0c012f
        0x7f0c0130
        0x7f0c0131
        0x7f0c0131
    .end array-data

    :array_156
    .array-data 4
        0x7f0c0138
        0x7f0c0091
        0x7f0c0092
        0x7f0c0093
    .end array-data

    :array_162
    .array-data 4
        0x7f0c0139
        0x7f0c0070
        0x7f0c0071
        0x7f0c0072
    .end array-data
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(Landroid/content/Context;)I
    .registers 3

    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const v1, 0x7f0e0005

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getInteger(I)I

    move-result p0

    const-string v1, "aabak"

    invoke-interface {v0, v1, p0}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    return p0
.end method

.method public static e(Landroid/content/Context;I)V
    .registers 3

    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "aabak"

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    return-void
.end method

.method public static md(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD:[I

    aget p0, v0, p0

    return p0
.end method

.method public static mdAccent(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_ACCENT:[I

    aget p0, v0, p0

    return p0
.end method

.method public static mdGoogleBtnText(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_GOOGLE_BTN_TEXT:[I

    aget p0, v0, p0

    return p0
.end method

.method public static mdMain(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_MAIN:[I

    aget p0, v0, p0

    return p0
.end method

.method public static mdNames(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_NAMES:[I

    aget p0, v0, p0

    return p0
.end method

.method public static mdNavActivated(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_NAV_ACTIVATED:[I

    aget p0, v0, p0

    return p0
.end method

.method public static mdNavNormal(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_NAV_NORMAL:[I

    aget p0, v0, p0

    return p0
.end method

.method public static mdNoActionBar(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_NOACTIONBAR:[I

    aget p0, v0, p0

    return p0
.end method

.method public static mdPatched(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_PATCHED:[I

    aget p0, v0, p0

    return p0
.end method

.method public static mdProgress(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_PROGRESS:[I

    aget p0, v0, p0

    return p0
.end method

.method public static mdRipple(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_RIPPLE:[I

    aget p0, v0, p0

    return p0
.end method

.method public static mdSyntax1(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_SYNTAX_1:[I

    aget v0, v0, p0

    return v0
.end method

.method public static mdSyntax2(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_SYNTAX_2:[I

    aget v0, v0, p0

    return v0
.end method

.method public static mdSyntax3(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_SYNTAX_3:[I

    aget v0, v0, p0

    return v0
.end method

.method public static mdSyntax4(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_SYNTAX_4:[I

    aget v0, v0, p0

    return v0
.end method

.method public static mdSyntax5(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_SYNTAX_5:[I

    aget v0, v0, p0

    return v0
.end method

.method public static mdSyntax9(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_SYNTAX_9:[I

    aget v0, v0, p0

    return v0
.end method

.method public static mdTextMedium(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_TEXT_MEDIUM:[I

    aget p0, v0, p0

    return p0
.end method

.method public static mdTextSmall(I)I
    .registers 2

    sget-object v0, La/a/b/a/k;->MD_TEXT_SMALL:[I

    aget p0, v0, p0

    return p0
.end method


# virtual methods
.method public f(Landroid/content/Context;ILa/a/b/a/m;)V
    .registers 8

    sget-object v0, La/a/b/a/k;->MD_NAMES:[I

    array-length v0, v0

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    :goto_6
    sget-object v2, La/a/b/a/k;->MD_NAMES:[I

    array-length v3, v2

    if-ge v1, v3, :cond_16

    aget v2, v2, v1

    invoke-virtual {p1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_6

    :cond_16
    invoke-static {p1}, La/a/b/a/k;->a(Landroid/content/Context;)I

    move-result v1

    new-instance v2, Landroid/app/AlertDialog$Builder;

    invoke-direct {v2, p1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2, p2}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    const p2, 0x1040000

    const/4 v3, 0x0

    invoke-virtual {v2, p2, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    new-instance p2, La/a/b/a/l;

    invoke-direct {p2, p0, v1, p1, p3}, La/a/b/a/l;-><init>(La/a/b/a/k;ILandroid/content/Context;La/a/b/a/m;)V

    invoke-virtual {v2, v0, v1, p2}, Landroid/app/AlertDialog$Builder;->setSingleChoiceItems([Ljava/lang/CharSequence;ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    invoke-virtual {v2}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method
