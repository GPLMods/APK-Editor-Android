.class public final La/a/b/a/e;
.super Ljava/lang/Object;


# instance fields
.field private final a:Lcom/gmail/heagoo/a/c/a;

.field private final b:I

.field private final c:Ljava/lang/String;

.field private final d:Ljava/util/Map;

.field private final e:Ljava/util/Map;

.field private final f:Ljava/util/Map;

.field private final g:Ljava/util/Set;

.field private h:La/a/b/a/a/x;


# direct methods
.method public constructor <init>(Lcom/gmail/heagoo/a/c/a;ILjava/lang/String;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, La/a/b/a/e;->d:Ljava/util/Map;

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, La/a/b/a/e;->e:Ljava/util/Map;

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, La/a/b/a/e;->f:Ljava/util/Map;

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, La/a/b/a/e;->g:Ljava/util/Set;

    iput-object p1, p0, La/a/b/a/e;->a:Lcom/gmail/heagoo/a/c/a;

    iput p2, p0, La/a/b/a/e;->b:I

    iput-object p3, p0, La/a/b/a/e;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final a(La/a/b/a/c;)La/a/b/a/h;
    .registers 4

    iget-object v0, p0, La/a/b/a/e;->e:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a/b/a/h;

    if-nez v0, :cond_14

    new-instance v0, La/a/b/a/h;

    invoke-direct {v0, p1}, La/a/b/a/h;-><init>(La/a/b/a/c;)V

    iget-object v1, p0, La/a/b/a/e;->e:Ljava/util/Map;

    invoke-interface {v1, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_14
    return-object v0
.end method

.method public final a()Ljava/util/List;
    .registers 3

    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, La/a/b/a/e;->d:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    return-object v0
.end method

.method public final a(I)V
    .registers 4

    iget-object v0, p0, La/a/b/a/e;->g:Ljava/util/Set;

    new-instance v1, La/a/b/a/d;

    invoke-direct {v1, p1}, La/a/b/a/d;-><init>(I)V

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final a(La/a/b/a/f;)V
    .registers 4

    iget-object v0, p0, La/a/b/a/e;->d:Ljava/util/Map;

    invoke-virtual {p1}, La/a/b/a/f;->e()La/a/b/a/d;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final a(La/a/b/a/i;)V
    .registers 4

    iget-object v0, p0, La/a/b/a/e;->f:Ljava/util/Map;

    invoke-virtual {p1}, La/a/b/a/i;->a()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_15

    iget-object v0, p0, La/a/b/a/e;->f:Ljava/util/Map;

    invoke-virtual {p1}, La/a/b/a/i;->a()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_15
    return-void
.end method

.method public final a(La/a/b/a/d;)Z
    .registers 3

    iget-object v0, p0, La/a/b/a/e;->d:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public final b(La/a/b/a/d;)La/a/b/a/f;
    .registers 5

    iget-object v0, p0, La/a/b/a/e;->d:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a/b/a/f;

    if-nez v0, :cond_23

    new-instance v0, La/a/a/b;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "resource spec: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, La/a/b/a/d;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, La/a/a/b;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_23
    return-object v0
.end method

.method public final b()Ljava/util/Set;
    .registers 6

    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    iget-object v0, p0, La/a/b/a/e;->d:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_3b

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a/b/a/f;

    invoke-virtual {v0}, La/a/b/a/f;->a()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_23
    :goto_23
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a/b/a/g;

    invoke-virtual {v0}, La/a/b/a/g;->d()La/a/b/a/a/w;

    move-result-object v4

    instance-of v4, v4, La/a/b/a/a/i;

    if-eqz v4, :cond_23

    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_23

    :cond_3b
    return-object v1
.end method

.method public final b(La/a/b/a/f;)V
    .registers 5

    iget-object v0, p0, La/a/b/a/e;->d:Ljava/util/Map;

    invoke-virtual {p1}, La/a/b/a/f;->e()La/a/b/a/d;

    move-result-object v1

    invoke-interface {v0, v1, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_21

    new-instance v0, La/a/a;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Multiple resource specs: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, La/a/a;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_21
    return-void
.end method

.method public final c()Ljava/util/Collection;
    .registers 9

    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    iget-object v0, p0, La/a/b/a/e;->d:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_f
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_5c

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a/b/a/f;

    invoke-virtual {v0}, La/a/b/a/f;->a()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_23
    :goto_23
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a/b/a/g;

    invoke-virtual {v0}, La/a/b/a/g;->d()La/a/b/a/a/w;

    move-result-object v1

    instance-of v1, v1, La/a/b/d/a;

    if-eqz v1, :cond_23

    invoke-virtual {v0}, La/a/b/a/g;->c()La/a/b/a/f;

    move-result-object v1

    invoke-virtual {v1}, La/a/b/a/f;->h()La/a/b/a/i;

    move-result-object v5

    invoke-virtual {v0}, La/a/b/a/g;->b()La/a/b/a/h;

    move-result-object v6

    new-instance v7, La/d/e;

    invoke-direct {v7, v5, v6}, La/d/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v2, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/a/b/a/j;

    if-nez v1, :cond_58

    new-instance v1, La/a/b/a/j;

    invoke-direct {v1, p0, v5, v6}, La/a/b/a/j;-><init>(La/a/b/a/e;La/a/b/a/i;La/a/b/a/h;)V

    invoke-interface {v2, v7, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_58
    invoke-virtual {v1, v0}, La/a/b/a/j;->b(La/a/b/a/g;)V

    goto :goto_23

    :cond_5c
    invoke-interface {v2}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    return-object v0
.end method

.method final c(La/a/b/a/d;)Z
    .registers 3

    iget-object v0, p0, La/a/b/a/e;->g:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public final d()Lcom/gmail/heagoo/a/c/a;
    .registers 2

    iget-object v0, p0, La/a/b/a/e;->a:Lcom/gmail/heagoo/a/c/a;

    return-object v0
.end method

.method public final e()I
    .registers 2

    iget v0, p0, La/a/b/a/e;->b:I

    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    const/4 v0, 0x0

    if-nez p1, :cond_4

    :cond_3
    :goto_3
    return v0

    :cond_4
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    if-ne v1, v2, :cond_3

    check-cast p1, La/a/b/a/e;

    iget-object v1, p0, La/a/b/a/e;->a:Lcom/gmail/heagoo/a/c/a;

    iget-object v2, p1, La/a/b/a/e;->a:Lcom/gmail/heagoo/a/c/a;

    if-eq v1, v2, :cond_24

    iget-object v1, p0, La/a/b/a/e;->a:Lcom/gmail/heagoo/a/c/a;

    if-eqz v1, :cond_3

    iget-object v1, p0, La/a/b/a/e;->a:Lcom/gmail/heagoo/a/c/a;

    iget-object v2, p1, La/a/b/a/e;->a:Lcom/gmail/heagoo/a/c/a;

    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    :cond_24
    iget v1, p0, La/a/b/a/e;->b:I

    iget v2, p1, La/a/b/a/e;->b:I

    if-ne v1, v2, :cond_3

    const/4 v0, 0x1

    goto :goto_3
.end method

.method public final f()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La/a/b/a/e;->c:Ljava/lang/String;

    return-object v0
.end method

.method public final g()La/a/b/a/a/x;
    .registers 2

    iget-object v0, p0, La/a/b/a/e;->h:La/a/b/a/a/x;

    if-nez v0, :cond_b

    new-instance v0, La/a/b/a/a/x;

    invoke-direct {v0, p0}, La/a/b/a/a/x;-><init>(La/a/b/a/e;)V

    iput-object v0, p0, La/a/b/a/e;->h:La/a/b/a/a/x;

    :cond_b
    iget-object v0, p0, La/a/b/a/e;->h:La/a/b/a/a/x;

    return-object v0
.end method

.method public final getSize()I
    .registers 2

    iget-object v0, p0, La/a/b/a/e;->d:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v0

    return v0
.end method

.method public final hashCode()I
    .registers 3

    iget-object v0, p0, La/a/b/a/e;->a:Lcom/gmail/heagoo/a/c/a;

    if-eqz v0, :cond_12

    iget-object v0, p0, La/a/b/a/e;->a:Lcom/gmail/heagoo/a/c/a;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    :goto_a
    add-int/lit16 v0, v0, 0x20f

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, La/a/b/a/e;->b:I

    add-int/2addr v0, v1

    return v0

    :cond_12
    const/4 v0, 0x0

    goto :goto_a
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "package: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, La/a/b/a/e;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
