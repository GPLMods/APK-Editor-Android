.class public La/a/b/a/n;
.super Ljava/lang/Object;


# static fields
.field private static final A:Ljava/lang/String; = "aaban"

.field static final B:[I

.field static final C:[I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const/16 v1, 0x2

    new-array v0, v1, [I

    fill-array-data v0, :array_12

    sput-object v0, La/a/b/a/n;->B:[I

    new-array v0, v1, [I

    fill-array-data v0, :array_1a

    sput-object v0, La/a/b/a/n;->C:[I

    return-void

    nop

    :array_12
    .array-data 4
        0x7f03003c
        0x7f030114
    .end array-data

    :array_1a
    .array-data 4
        0x7f07027d
        0x7f07027e
    .end array-data
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static b(I)I
    .registers 2

    sget-object v0, La/a/b/a/n;->B:[I

    aget p0, v0, p0

    return p0
.end method

.method public static c(I)I
    .registers 2

    sget-object v0, La/a/b/a/n;->C:[I

    aget p0, v0, p0

    return p0
.end method

.method public static d(Landroid/content/Context;)I
    .registers 3

    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const v1, 0x7f0e0006

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getInteger(I)I

    move-result p0

    const-string v1, "aaban"

    invoke-interface {v0, v1, p0}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    return p0
.end method

.method public static e(Landroid/content/Context;I)V
    .registers 3

    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "aaban"

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    return-void
.end method


# virtual methods
.method public f(Landroid/content/Context;ILa/a/b/a/p;)V
    .registers 8

    sget-object v0, La/a/b/a/n;->C:[I

    array-length v0, v0

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    :goto_6
    sget-object v2, La/a/b/a/n;->C:[I

    array-length v3, v2

    if-ge v1, v3, :cond_16

    aget v2, v2, v1

    invoke-virtual {p1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_6

    :cond_16
    invoke-static {p1}, La/a/b/a/n;->d(Landroid/content/Context;)I

    move-result v1

    new-instance v2, Landroid/app/AlertDialog$Builder;

    invoke-direct {v2, p1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2, p2}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    const p2, 0x1040000

    const/4 v3, 0x0

    invoke-virtual {v2, p2, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    new-instance p2, La/a/b/a/o;

    invoke-direct {p2, p0, v1, p1, p3}, La/a/b/a/o;-><init>(La/a/b/a/n;ILandroid/content/Context;La/a/b/a/p;)V

    invoke-virtual {v2, v0, v1, p2}, Landroid/app/AlertDialog$Builder;->setSingleChoiceItems([Ljava/lang/CharSequence;ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    invoke-virtual {v2}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method
