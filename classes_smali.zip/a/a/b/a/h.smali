.class public final La/a/b/a/h;
.super Ljava/lang/Object;


# instance fields
.field private final a:La/a/b/a/c;

.field private final b:Ljava/util/Map;


# direct methods
.method public constructor <init>(La/a/b/a/c;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, La/a/b/a/h;->b:Ljava/util/Map;

    iput-object p1, p0, La/a/b/a/h;->a:La/a/b/a/c;

    return-void
.end method


# virtual methods
.method public final a()La/a/b/a/c;
    .registers 2

    iget-object v0, p0, La/a/b/a/h;->a:La/a/b/a/c;

    return-object v0
.end method

.method public final a(La/a/b/a/g;)V
    .registers 3

    const/4 v0, 0x1

    invoke-virtual {p0, p1, v0}, La/a/b/a/h;->a(La/a/b/a/g;Z)V

    return-void
.end method

.method public final a(La/a/b/a/g;Z)V
    .registers 5

    invoke-virtual {p1}, La/a/b/a/g;->c()La/a/b/a/f;

    move-result-object v0

    iget-object v1, p0, La/a/b/a/h;->b:Ljava/util/Map;

    invoke-interface {v1, v0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La/a/b/a/h;->a:La/a/b/a/c;

    invoke-virtual {v0}, La/a/b/a/c;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
