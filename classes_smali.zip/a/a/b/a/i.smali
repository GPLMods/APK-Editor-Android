.class public final La/a/b/a/i;
.super Ljava/lang/Object;


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/util/Map;

.field private final c:I


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/gmail/heagoo/a/c/a;La/a/b/a/e;II)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, La/a/b/a/i;->b:Ljava/util/Map;

    iput-object p1, p0, La/a/b/a/i;->a:Ljava/lang/String;

    iput p4, p0, La/a/b/a/i;->c:I

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)La/a/b/a/f;
    .registers 7

    iget-object v0, p0, La/a/b/a/i;->b:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a/b/a/f;

    if-nez v0, :cond_21

    new-instance v0, La/a/a/b;

    const-string v1, "resource spec: %s/%s"

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget-object v4, p0, La/a/b/a/i;->a:Ljava/lang/String;

    aput-object v4, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, La/a/a/b;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_21
    return-object v0
.end method

.method public final a()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La/a/b/a/i;->a:Ljava/lang/String;

    return-object v0
.end method

.method public final a(La/a/b/a/f;)V
    .registers 4

    iget-object v0, p0, La/a/b/a/i;->b:Ljava/util/Map;

    invoke-virtual {p1}, La/a/b/a/f;->f()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final b()I
    .registers 2

    iget v0, p0, La/a/b/a/i;->c:I

    return v0
.end method

.method public final b(La/a/b/a/f;)V
    .registers 7

    iget-object v0, p0, La/a/b/a/i;->b:Ljava/util/Map;

    invoke-virtual {p1}, La/a/b/a/f;->f()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_27

    new-instance v0, La/a/a;

    const-string v1, "Multiple res specs: %s/%s"

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget-object v4, p0, La/a/b/a/i;->a:Ljava/lang/String;

    aput-object v4, v2, v3

    const/4 v3, 0x1

    invoke-virtual {p1}, La/a/b/a/f;->f()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, La/a/a;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_27
    return-void
.end method

.method public final c()Z
    .registers 3

    iget-object v0, p0, La/a/b/a/i;->a:Ljava/lang/String;

    const-string v1, "string"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La/a/b/a/i;->a:Ljava/lang/String;

    return-object v0
.end method

.method public final unsafe(Ljava/lang/String;)La/a/b/a/f;
    .registers 7

    iget-object v0, p0, La/a/b/a/i;->b:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/a/b/a/f;

    return-object v0
.end method
