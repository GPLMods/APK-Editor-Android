.class public interface abstract La/a/b/a/m;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a()V
.end method
