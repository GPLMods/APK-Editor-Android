.class La/a/b/a/o;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic a:La/a/b/a/n;

.field final synthetic b:I

.field final synthetic c:Landroid/content/Context;

.field final synthetic d:La/a/b/a/p;


# direct methods
.method constructor <init>(La/a/b/a/n;ILandroid/content/Context;La/a/b/a/p;)V
    .registers 5

    iput-object p1, p0, La/a/b/a/o;->a:La/a/b/a/n;

    iput p2, p0, La/a/b/a/o;->b:I

    iput-object p3, p0, La/a/b/a/o;->c:Landroid/content/Context;

    iput-object p4, p0, La/a/b/a/o;->d:La/a/b/a/p;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 4

    iget v0, p0, La/a/b/a/o;->b:I

    if-eq v0, p2, :cond_e

    iget-object v0, p0, La/a/b/a/o;->c:Landroid/content/Context;

    invoke-static {v0, p2}, La/a/b/a/n;->e(Landroid/content/Context;I)V

    iget-object p2, p0, La/a/b/a/o;->d:La/a/b/a/p;

    invoke-interface {p2}, La/a/b/a/p;->a()V

    :cond_e
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    return-void
.end method
