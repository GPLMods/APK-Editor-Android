.class public final La/a/b/a/g;
.super Ljava/lang/Object;


# instance fields
.field private final a:La/a/b/a/h;

.field private final b:La/a/b/a/f;

.field private final c:La/a/b/a/a/w;


# direct methods
.method public constructor <init>(La/a/b/a/h;La/a/b/a/f;La/a/b/a/a/w;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/a/b/a/g;->a:La/a/b/a/h;

    iput-object p2, p0, La/a/b/a/g;->b:La/a/b/a/f;

    iput-object p3, p0, La/a/b/a/g;->c:La/a/b/a/a/w;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, La/a/b/a/g;->b:La/a/b/a/f;

    invoke-virtual {v1}, La/a/b/a/f;->h()La/a/b/a/i;

    move-result-object v1

    invoke-virtual {v1}, La/a/b/a/i;->a()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, La/a/b/a/g;->a:La/a/b/a/h;

    invoke-virtual {v1}, La/a/b/a/h;->a()La/a/b/a/c;

    move-result-object v1

    invoke-virtual {v1}, La/a/b/a/c;->a()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, La/a/b/a/g;->b:La/a/b/a/f;

    invoke-virtual {v1}, La/a/b/a/f;->f()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final a(La/a/b/a/a/w;)V
    .registers 6

    const/4 v3, 0x1

    new-instance v0, La/a/b/a/g;

    iget-object v1, p0, La/a/b/a/g;->a:La/a/b/a/h;

    iget-object v2, p0, La/a/b/a/g;->b:La/a/b/a/f;

    invoke-direct {v0, v1, v2, p1}, La/a/b/a/g;-><init>(La/a/b/a/h;La/a/b/a/f;La/a/b/a/a/w;)V

    iget-object v1, p0, La/a/b/a/g;->a:La/a/b/a/h;

    invoke-virtual {v1, v0, v3}, La/a/b/a/h;->a(La/a/b/a/g;Z)V

    iget-object v1, p0, La/a/b/a/g;->b:La/a/b/a/f;

    invoke-virtual {v1, v0, v3}, La/a/b/a/f;->a(La/a/b/a/g;Z)V

    return-void
.end method

.method public final b()La/a/b/a/h;
    .registers 2

    iget-object v0, p0, La/a/b/a/g;->a:La/a/b/a/h;

    return-object v0
.end method

.method public final c()La/a/b/a/f;
    .registers 2

    iget-object v0, p0, La/a/b/a/g;->b:La/a/b/a/f;

    return-object v0
.end method

.method public final d()La/a/b/a/a/w;
    .registers 2

    iget-object v0, p0, La/a/b/a/g;->c:La/a/b/a/a/w;

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    invoke-virtual {p0}, La/a/b/a/g;->a()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
