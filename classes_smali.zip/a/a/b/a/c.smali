.class public final La/a/b/a/c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static z:I


# instance fields
.field public final a:Z

.field private b:S

.field private c:S

.field private d:[C

.field private e:[C

.field private f:B

.field private g:B

.field private h:I

.field private i:B

.field private j:B

.field private k:B

.field private l:S

.field private m:S

.field private n:S

.field private o:B

.field private p:B

.field private q:S

.field private r:S

.field private s:S

.field private final t:[C

.field private final u:[C

.field private final v:B

.field private final w:B

.field private x:Ljava/lang/String;

.field private final y:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x0

    sput v0, La/a/b/a/c;->z:I

    return-void
.end method

.method public constructor <init>()V
    .registers 5

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-short v1, p0, La/a/b/a/c;->b:S

    iput-short v1, p0, La/a/b/a/c;->c:S

    new-array v0, v2, [C

    fill-array-data v0, :array_46

    iput-object v0, p0, La/a/b/a/c;->d:[C

    new-array v0, v2, [C

    fill-array-data v0, :array_4c

    iput-object v0, p0, La/a/b/a/c;->e:[C

    iput-byte v1, p0, La/a/b/a/c;->f:B

    iput-byte v1, p0, La/a/b/a/c;->g:B

    iput v1, p0, La/a/b/a/c;->h:I

    iput-byte v1, p0, La/a/b/a/c;->i:B

    iput-byte v1, p0, La/a/b/a/c;->j:B

    iput-byte v1, p0, La/a/b/a/c;->k:B

    iput-short v1, p0, La/a/b/a/c;->l:S

    iput-short v1, p0, La/a/b/a/c;->m:S

    iput-short v1, p0, La/a/b/a/c;->n:S

    iput-byte v1, p0, La/a/b/a/c;->o:B

    iput-byte v1, p0, La/a/b/a/c;->p:B

    iput-short v1, p0, La/a/b/a/c;->q:S

    iput-short v1, p0, La/a/b/a/c;->r:S

    iput-short v1, p0, La/a/b/a/c;->s:S

    iput-object v3, p0, La/a/b/a/c;->t:[C

    iput-object v3, p0, La/a/b/a/c;->u:[C

    iput-byte v1, p0, La/a/b/a/c;->v:B

    iput-byte v1, p0, La/a/b/a/c;->w:B

    iput-boolean v1, p0, La/a/b/a/c;->a:Z

    const-string v0, ""

    iput-object v0, p0, La/a/b/a/c;->x:Ljava/lang/String;

    iput v1, p0, La/a/b/a/c;->y:I

    return-void

    nop

    :array_46
    .array-data 2
        0x0s
        0x0s
    .end array-data

    :array_4c
    .array-data 2
        0x0s
        0x0s
    .end array-data
.end method

.method public constructor <init>(SS[C[CBBIBBBSSSBBSSS[C[CBBZI)V
    .registers 32

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-ltz p5, :cond_8

    const/4 v1, 0x3

    if-le p5, v1, :cond_4fa

    :cond_8
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Invalid orientation value: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 p5, 0x0

    const/4 v1, 0x1

    :goto_14
    if-ltz p6, :cond_19

    const/4 v2, 0x3

    if-le p6, v2, :cond_25

    :cond_19
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Invalid touchscreen value: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 p6, 0x0

    const/4 v1, 0x1

    :cond_25
    const/4 v2, -0x1

    if-ge p7, v2, :cond_34

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Invalid density value: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 p7, 0x0

    const/4 v1, 0x1

    :cond_34
    if-ltz p8, :cond_39

    const/4 v2, 0x3

    if-le p8, v2, :cond_45

    :cond_39
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Invalid keyboard value: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 p8, 0x0

    const/4 v1, 0x1

    :cond_45
    if-ltz p9, :cond_4c

    const/4 v2, 0x4

    move/from16 v0, p9

    if-le v0, v2, :cond_5b

    :cond_4c
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Invalid navigation value: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move/from16 v0, p9

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 p9, 0x0

    const/4 v1, 0x1

    :cond_5b
    if-eqz p19, :cond_67

    move-object/from16 v0, p19

    array-length v2, v0

    if-eqz v2, :cond_67

    const/4 v2, 0x0

    aget-char v2, p19, v2

    if-nez v2, :cond_69

    :cond_67
    const/16 p19, 0x0

    :cond_69
    if-eqz p20, :cond_75

    move-object/from16 v0, p20

    array-length v2, v0

    if-eqz v2, :cond_75

    const/4 v2, 0x0

    aget-char v2, p20, v2

    if-nez v2, :cond_77

    :cond_75
    const/16 p20, 0x0

    :cond_77
    iput-short p1, p0, La/a/b/a/c;->b:S

    iput-short p2, p0, La/a/b/a/c;->c:S

    iput-object p3, p0, La/a/b/a/c;->d:[C

    iput-object p4, p0, La/a/b/a/c;->e:[C

    iput-byte p5, p0, La/a/b/a/c;->f:B

    iput-byte p6, p0, La/a/b/a/c;->g:B

    iput p7, p0, La/a/b/a/c;->h:I

    iput-byte p8, p0, La/a/b/a/c;->i:B

    move/from16 v0, p9

    iput-byte v0, p0, La/a/b/a/c;->j:B

    move/from16 v0, p10

    iput-byte v0, p0, La/a/b/a/c;->k:B

    move/from16 v0, p11

    iput-short v0, p0, La/a/b/a/c;->l:S

    move/from16 v0, p12

    iput-short v0, p0, La/a/b/a/c;->m:S

    move/from16 v0, p13

    iput-short v0, p0, La/a/b/a/c;->n:S

    move/from16 v0, p14

    iput-byte v0, p0, La/a/b/a/c;->o:B

    move/from16 v0, p15

    iput-byte v0, p0, La/a/b/a/c;->p:B

    move/from16 v0, p16

    iput-short v0, p0, La/a/b/a/c;->q:S

    move/from16 v0, p17

    iput-short v0, p0, La/a/b/a/c;->r:S

    move/from16 v0, p18

    iput-short v0, p0, La/a/b/a/c;->s:S

    move-object/from16 v0, p19

    iput-object v0, p0, La/a/b/a/c;->t:[C

    move-object/from16 v0, p20

    iput-object v0, p0, La/a/b/a/c;->u:[C

    move/from16 v0, p21

    iput-byte v0, p0, La/a/b/a/c;->v:B

    move/from16 v0, p22

    iput-byte v0, p0, La/a/b/a/c;->w:B

    iput-boolean v1, p0, La/a/b/a/c;->a:Z

    move/from16 v0, p24

    iput v0, p0, La/a/b/a/c;->y:I

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-short v1, p0, La/a/b/a/c;->b:S

    if-eqz v1, :cond_2a3

    const-string v1, "-mcc"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "%03d"

    const/4 v4, 0x1

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v5, 0x0

    iget-short v6, p0, La/a/b/a/c;->b:S

    invoke-static {v6}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    move-result-object v6

    aput-object v6, v4, v5

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-short v1, p0, La/a/b/a/c;->c:S

    const/4 v3, -0x1

    if-eq v1, v3, :cond_29c

    iget-short v1, p0, La/a/b/a/c;->c:S

    if-eqz v1, :cond_11c

    const-string v1, "-mnc"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/a/b/a/c;->y:I

    const/16 v3, 0x20

    if-gt v1, v3, :cond_295

    iget-short v1, p0, La/a/b/a/c;->c:S

    if-lez v1, :cond_27e

    iget-short v1, p0, La/a/b/a/c;->c:S

    const/16 v3, 0xa

    if-ge v1, v3, :cond_27e

    const-string v1, "%02d"

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    iget-short v5, p0, La/a/b/a/c;->c:S

    invoke-static {v5}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    move-result-object v5

    aput-object v5, v3, v4

    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_11c
    :goto_11c
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, La/a/b/a/c;->u:[C

    if-nez v3, :cond_2b4

    iget-object v3, p0, La/a/b/a/c;->t:[C

    if-nez v3, :cond_2b4

    iget-object v3, p0, La/a/b/a/c;->e:[C

    const/4 v4, 0x0

    aget-char v3, v3, v4

    if-nez v3, :cond_137

    iget-object v3, p0, La/a/b/a/c;->d:[C

    const/4 v4, 0x0

    aget-char v3, v3, v4

    if-eqz v3, :cond_2b4

    :cond_137
    iget-object v3, p0, La/a/b/a/c;->e:[C

    array-length v3, v3

    const/4 v4, 0x3

    if-eq v3, v4, :cond_2b4

    const-string v3, "-"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, La/a/b/a/c;->d:[C

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append([C)Ljava/lang/StringBuilder;

    iget-object v3, p0, La/a/b/a/c;->e:[C

    const/4 v4, 0x0

    aget-char v3, v3, v4

    if-eqz v3, :cond_15a

    const-string v3, "-r"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, La/a/b/a/c;->e:[C

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append([C)Ljava/lang/StringBuilder;

    :cond_15a
    :goto_15a
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-byte v1, p0, La/a/b/a/c;->o:B

    and-int/lit16 v1, v1, 0xc0

    sparse-switch v1, :sswitch_data_4fe

    :goto_168
    iget-short v1, p0, La/a/b/a/c;->q:S

    if-eqz v1, :cond_17d

    const-string v1, "-sw"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-short v3, p0, La/a/b/a/c;->q:S

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "dp"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_17d
    iget-short v1, p0, La/a/b/a/c;->r:S

    if-eqz v1, :cond_192

    const-string v1, "-w"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-short v3, p0, La/a/b/a/c;->r:S

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "dp"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_192
    iget-short v1, p0, La/a/b/a/c;->s:S

    if-eqz v1, :cond_1a7

    const-string v1, "-h"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-short v3, p0, La/a/b/a/c;->s:S

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "dp"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1a7
    iget-byte v1, p0, La/a/b/a/c;->o:B

    and-int/lit8 v1, v1, 0xf

    packed-switch v1, :pswitch_data_508

    :goto_1ae
    iget-byte v1, p0, La/a/b/a/c;->o:B

    and-int/lit8 v1, v1, 0x30

    sparse-switch v1, :sswitch_data_514

    :goto_1b5
    iget-byte v1, p0, La/a/b/a/c;->v:B

    and-int/lit8 v1, v1, 0x3

    packed-switch v1, :pswitch_data_51e

    :goto_1bc
    iget-byte v1, p0, La/a/b/a/c;->w:B

    and-int/lit8 v1, v1, 0xc

    sparse-switch v1, :sswitch_data_526

    :goto_1c3
    iget-byte v1, p0, La/a/b/a/c;->w:B

    and-int/lit8 v1, v1, 0x3

    packed-switch v1, :pswitch_data_530

    :goto_1ca
    iget-byte v1, p0, La/a/b/a/c;->f:B

    packed-switch v1, :pswitch_data_538

    :goto_1cf
    iget-byte v1, p0, La/a/b/a/c;->p:B

    and-int/lit8 v1, v1, 0xf

    packed-switch v1, :pswitch_data_542

    :goto_1d6
    :pswitch_1d6  #0x8, 0x9, 0xa
    iget-byte v1, p0, La/a/b/a/c;->p:B

    and-int/lit8 v1, v1, 0x30

    sparse-switch v1, :sswitch_data_562

    :goto_1dd
    iget v1, p0, La/a/b/a/c;->h:I

    sparse-switch v1, :sswitch_data_56c

    const/16 v1, 0x2d

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v3, p0, La/a/b/a/c;->h:I

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "dpi"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_1f3
    :sswitch_1f3
    iget-byte v1, p0, La/a/b/a/c;->g:B

    packed-switch v1, :pswitch_data_596

    :goto_1f8
    iget-byte v1, p0, La/a/b/a/c;->k:B

    and-int/lit8 v1, v1, 0x3

    packed-switch v1, :pswitch_data_5a0

    :goto_1ff
    iget-byte v1, p0, La/a/b/a/c;->i:B

    packed-switch v1, :pswitch_data_5aa

    :goto_204
    iget-byte v1, p0, La/a/b/a/c;->k:B

    and-int/lit8 v1, v1, 0xc

    sparse-switch v1, :sswitch_data_5b4

    :goto_20b
    iget-byte v1, p0, La/a/b/a/c;->j:B

    packed-switch v1, :pswitch_data_5be

    :goto_210
    iget-short v1, p0, La/a/b/a/c;->l:S

    if-eqz v1, :cond_23c

    iget-short v1, p0, La/a/b/a/c;->m:S

    if-eqz v1, :cond_23c

    iget-short v1, p0, La/a/b/a/c;->l:S

    iget-short v3, p0, La/a/b/a/c;->m:S

    if-le v1, v3, :cond_49b

    const-string v1, "-%dx%d"

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    iget-short v5, p0, La/a/b/a/c;->l:S

    invoke-static {v5}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x1

    iget-short v5, p0, La/a/b/a/c;->m:S

    invoke-static {v5}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    move-result-object v5

    aput-object v5, v3, v4

    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_23c
    :goto_23c
    iget-short v1, p0, La/a/b/a/c;->n:S

    if-lez v1, :cond_264

    iget-short v3, p0, La/a/b/a/c;->n:S

    iget-byte v1, p0, La/a/b/a/c;->p:B

    and-int/lit8 v1, v1, 0xf

    const/4 v4, 0x7

    if-eq v1, v4, :cond_255

    iget-byte v1, p0, La/a/b/a/c;->w:B

    and-int/lit8 v1, v1, 0x3

    if-nez v1, :cond_255

    iget-byte v1, p0, La/a/b/a/c;->w:B

    and-int/lit8 v1, v1, 0xc

    if-eqz v1, :cond_4bb

    :cond_255
    const/16 v1, 0x1a

    :goto_257
    if-lt v3, v1, :cond_264

    const-string v1, "-v"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-short v3, p0, La/a/b/a/c;->n:S

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    :cond_264
    iget-boolean v1, p0, La/a/b/a/c;->a:Z

    if-eqz v1, :cond_277

    const-string v1, "-ERR"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget v3, La/a/b/a/c;->z:I

    add-int/lit8 v4, v3, 0x1

    sput v4, La/a/b/a/c;->z:I

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    :cond_277
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, La/a/b/a/c;->x:Ljava/lang/String;

    return-void

    :cond_27e
    const-string v1, "%03d"

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    iget-short v5, p0, La/a/b/a/c;->c:S

    invoke-static {v5}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    move-result-object v5

    aput-object v5, v3, v4

    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_11c

    :cond_295
    iget-short v1, p0, La/a/b/a/c;->c:S

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    goto/16 :goto_11c

    :cond_29c
    const-string v1, "-mnc00"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_11c

    :cond_2a3
    iget-short v1, p0, La/a/b/a/c;->c:S

    if-eqz v1, :cond_11c

    const-string v1, "-mnc"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-short v3, p0, La/a/b/a/c;->c:S

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    goto/16 :goto_11c

    :cond_2b4
    iget-object v3, p0, La/a/b/a/c;->d:[C

    const/4 v4, 0x0

    aget-char v3, v3, v4

    if-nez v3, :cond_2c2

    iget-object v3, p0, La/a/b/a/c;->e:[C

    const/4 v4, 0x0

    aget-char v3, v3, v4

    if-eqz v3, :cond_15a

    :cond_2c2
    const-string v3, "-b+"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, La/a/b/a/c;->d:[C

    const/4 v4, 0x0

    aget-char v3, v3, v4

    if-eqz v3, :cond_2d3

    iget-object v3, p0, La/a/b/a/c;->d:[C

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append([C)Ljava/lang/StringBuilder;

    :cond_2d3
    iget-object v3, p0, La/a/b/a/c;->t:[C

    if-eqz v3, :cond_2e8

    iget-object v3, p0, La/a/b/a/c;->t:[C

    array-length v3, v3

    const/4 v4, 0x4

    if-ne v3, v4, :cond_2e8

    const-string v3, "+"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, La/a/b/a/c;->t:[C

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append([C)Ljava/lang/StringBuilder;

    :cond_2e8
    iget-object v3, p0, La/a/b/a/c;->e:[C

    array-length v3, v3

    const/4 v4, 0x2

    if-eq v3, v4, :cond_2f4

    iget-object v3, p0, La/a/b/a/c;->e:[C

    array-length v3, v3

    const/4 v4, 0x3

    if-ne v3, v4, :cond_306

    :cond_2f4
    iget-object v3, p0, La/a/b/a/c;->e:[C

    const/4 v4, 0x0

    aget-char v3, v3, v4

    if-eqz v3, :cond_306

    const-string v3, "+"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, La/a/b/a/c;->e:[C

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append([C)Ljava/lang/StringBuilder;

    :cond_306
    iget-object v3, p0, La/a/b/a/c;->u:[C

    if-eqz v3, :cond_15a

    iget-object v3, p0, La/a/b/a/c;->u:[C

    array-length v3, v3

    const/4 v4, 0x5

    if-lt v3, v4, :cond_15a

    const-string v3, "+"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, La/a/b/a/c;->u:[C

    invoke-static {v4}, La/a/b/a/c;->a([C)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_15a

    :sswitch_321
    const-string v1, "-ldrtl"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_168

    :sswitch_328
    const-string v1, "-ldltr"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_168

    :pswitch_32f  #0x1
    const-string v1, "-small"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1ae

    :pswitch_336  #0x2
    const-string v1, "-normal"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1ae

    :pswitch_33d  #0x3
    const-string v1, "-large"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1ae

    :pswitch_344  #0x4
    const-string v1, "-xlarge"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1ae

    :sswitch_34b
    const-string v1, "-long"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1b5

    :sswitch_352
    const-string v1, "-notlong"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1b5

    :pswitch_359  #0x1
    const-string v1, "-notround"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1bc

    :pswitch_360  #0x2
    const-string v1, "-round"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1bc

    :sswitch_367
    const-string v1, "-highdr"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1c3

    :sswitch_36e
    const-string v1, "-lowdr"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1c3

    :pswitch_375  #0x2
    const-string v1, "-widecg"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1ca

    :pswitch_37c  #0x1
    const-string v1, "-nowidecg"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1ca

    :pswitch_383  #0x1
    const-string v1, "-port"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1cf

    :pswitch_38a  #0x2
    const-string v1, "-land"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1cf

    :pswitch_391  #0x3
    const-string v1, "-square"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1cf

    :pswitch_398  #0x3
    const-string v1, "-car"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1d6

    :pswitch_39f  #0x2
    const-string v1, "-desk"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1d6

    :pswitch_3a6  #0x4
    const-string v1, "-television"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1d6

    :pswitch_3ad  #0xc
    const-string v1, "-smallui"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1d6

    :pswitch_3b4  #0xd
    const-string v1, "-mediumui"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1d6

    :pswitch_3bb  #0xe
    const-string v1, "-largeui"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1d6

    :pswitch_3c2  #0xb
    const-string v1, "-godzillaui"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1d6

    :pswitch_3c9  #0xf
    const-string v1, "-hugeui"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1d6

    :pswitch_3d0  #0x5
    const-string v1, "-appliance"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1d6

    :pswitch_3d7  #0x6
    const-string v1, "-watch"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1d6

    :pswitch_3de  #0x7
    const-string v1, "-vrheadset"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1d6

    :sswitch_3e5
    const-string v1, "-night"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1dd

    :sswitch_3ec
    const-string v1, "-notnight"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1dd

    :sswitch_3f3
    const-string v1, "-ldpi"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1f3

    :sswitch_3fa
    const-string v1, "-mdpi"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1f3

    :sswitch_401
    const-string v1, "-hdpi"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1f3

    :sswitch_408
    const-string v1, "-tvdpi"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1f3

    :sswitch_40f
    const-string v1, "-xhdpi"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1f3

    :sswitch_416
    const-string v1, "-xxhdpi"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1f3

    :sswitch_41d
    const-string v1, "-xxxhdpi"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1f3

    :sswitch_424
    const-string v1, "-anydpi"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1f3

    :sswitch_42b
    const-string v1, "-nodpi"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1f3

    :pswitch_432  #0x1
    const-string v1, "-notouch"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1f8

    :pswitch_439  #0x2
    const-string v1, "-stylus"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1f8

    :pswitch_440  #0x3
    const-string v1, "-finger"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1f8

    :pswitch_447  #0x1
    const-string v1, "-keysexposed"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1ff

    :pswitch_44e  #0x2
    const-string v1, "-keyshidden"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1ff

    :pswitch_455  #0x3
    const-string v1, "-keyssoft"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1ff

    :pswitch_45c  #0x1
    const-string v1, "-nokeys"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_204

    :pswitch_463  #0x2
    const-string v1, "-qwerty"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_204

    :pswitch_46a  #0x3
    const-string v1, "-12key"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_204

    :sswitch_471
    const-string v1, "-navexposed"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_20b

    :sswitch_478
    const-string v1, "-navhidden"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_20b

    :pswitch_47f  #0x1
    const-string v1, "-nonav"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_210

    :pswitch_486  #0x2
    const-string v1, "-dpad"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_210

    :pswitch_48d  #0x3
    const-string v1, "-trackball"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_210

    :pswitch_494  #0x4
    const-string v1, "-wheel"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_210

    :cond_49b
    const-string v1, "-%dx%d"

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    iget-short v5, p0, La/a/b/a/c;->m:S

    invoke-static {v5}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x1

    iget-short v5, p0, La/a/b/a/c;->l:S

    invoke-static {v5}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    move-result-object v5

    aput-object v5, v3, v4

    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_23c

    :cond_4bb
    iget-byte v1, p0, La/a/b/a/c;->v:B

    and-int/lit8 v1, v1, 0x3

    if-eqz v1, :cond_4c5

    const/16 v1, 0x17

    goto/16 :goto_257

    :cond_4c5
    iget v1, p0, La/a/b/a/c;->h:I

    const v4, 0xfffe

    if-ne v1, v4, :cond_4d0

    const/16 v1, 0x15

    goto/16 :goto_257

    :cond_4d0
    iget-short v1, p0, La/a/b/a/c;->q:S

    if-nez v1, :cond_4dc

    iget-short v1, p0, La/a/b/a/c;->r:S

    if-nez v1, :cond_4dc

    iget-short v1, p0, La/a/b/a/c;->s:S

    if-eqz v1, :cond_4e0

    :cond_4dc
    const/16 v1, 0xd

    goto/16 :goto_257

    :cond_4e0
    iget-byte v1, p0, La/a/b/a/c;->p:B

    and-int/lit8 v1, v1, 0x3f

    if-eqz v1, :cond_4ea

    const/16 v1, 0x8

    goto/16 :goto_257

    :cond_4ea
    iget-byte v1, p0, La/a/b/a/c;->o:B

    and-int/lit8 v1, v1, 0x3f

    if-nez v1, :cond_4f4

    iget v1, p0, La/a/b/a/c;->h:I

    if-eqz v1, :cond_4f7

    :cond_4f4
    const/4 v1, 0x4

    goto/16 :goto_257

    :cond_4f7
    const/4 v1, 0x0

    goto/16 :goto_257

    :cond_4fa
    move/from16 v1, p23

    goto/16 :goto_14

    :sswitch_data_4fe
    .sparse-switch
        0x40 -> :sswitch_328
        0x80 -> :sswitch_321
    .end sparse-switch

    :pswitch_data_508
    .packed-switch 0x1
        :pswitch_32f  #00000001
        :pswitch_336  #00000002
        :pswitch_33d  #00000003
        :pswitch_344  #00000004
    .end packed-switch

    :sswitch_data_514
    .sparse-switch
        0x10 -> :sswitch_352
        0x20 -> :sswitch_34b
    .end sparse-switch

    :pswitch_data_51e
    .packed-switch 0x1
        :pswitch_359  #00000001
        :pswitch_360  #00000002
    .end packed-switch

    :sswitch_data_526
    .sparse-switch
        0x4 -> :sswitch_36e
        0x8 -> :sswitch_367
    .end sparse-switch

    :pswitch_data_530
    .packed-switch 0x1
        :pswitch_37c  #00000001
        :pswitch_375  #00000002
    .end packed-switch

    :pswitch_data_538
    .packed-switch 0x1
        :pswitch_383  #00000001
        :pswitch_38a  #00000002
        :pswitch_391  #00000003
    .end packed-switch

    :pswitch_data_542
    .packed-switch 0x2
        :pswitch_39f  #00000002
        :pswitch_398  #00000003
        :pswitch_3a6  #00000004
        :pswitch_3d0  #00000005
        :pswitch_3d7  #00000006
        :pswitch_3de  #00000007
        :pswitch_1d6  #00000008
        :pswitch_1d6  #00000009
        :pswitch_1d6  #0000000a
        :pswitch_3c2  #0000000b
        :pswitch_3ad  #0000000c
        :pswitch_3b4  #0000000d
        :pswitch_3bb  #0000000e
        :pswitch_3c9  #0000000f
    .end packed-switch

    :sswitch_data_562
    .sparse-switch
        0x10 -> :sswitch_3ec
        0x20 -> :sswitch_3e5
    .end sparse-switch

    :sswitch_data_56c
    .sparse-switch
        0x0 -> :sswitch_1f3
        0x78 -> :sswitch_3f3
        0xa0 -> :sswitch_3fa
        0xd5 -> :sswitch_408
        0xf0 -> :sswitch_401
        0x140 -> :sswitch_40f
        0x1e0 -> :sswitch_416
        0x280 -> :sswitch_41d
        0xfffe -> :sswitch_424
        0xffff -> :sswitch_42b
    .end sparse-switch

    :pswitch_data_596
    .packed-switch 0x1
        :pswitch_432  #00000001
        :pswitch_439  #00000002
        :pswitch_440  #00000003
    .end packed-switch

    :pswitch_data_5a0
    .packed-switch 0x1
        :pswitch_447  #00000001
        :pswitch_44e  #00000002
        :pswitch_455  #00000003
    .end packed-switch

    :pswitch_data_5aa
    .packed-switch 0x1
        :pswitch_45c  #00000001
        :pswitch_463  #00000002
        :pswitch_46a  #00000003
    .end packed-switch

    :sswitch_data_5b4
    .sparse-switch
        0x4 -> :sswitch_471
        0x8 -> :sswitch_478
    .end sparse-switch

    :pswitch_data_5be
    .packed-switch 0x1
        :pswitch_47f  #00000001
        :pswitch_486  #00000002
        :pswitch_48d  #00000003
        :pswitch_494  #00000004
    .end packed-switch
.end method

.method private static a([C)Ljava/lang/String;
    .registers 5

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    array-length v2, p0

    const/4 v0, 0x0

    :goto_7
    if-ge v0, v2, :cond_15

    aget-char v3, p0, v0

    invoke-static {v3}, Ljava/lang/Character;->toUpperCase(C)C

    move-result v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x1

    goto :goto_7

    :cond_15
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La/a/b/a/c;->x:Ljava/lang/String;

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    const/4 v0, 0x0

    if-nez p1, :cond_4

    :cond_3
    :goto_3
    return v0

    :cond_4
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    if-ne v1, v2, :cond_3

    check-cast p1, La/a/b/a/c;

    iget-object v0, p0, La/a/b/a/c;->x:Ljava/lang/String;

    iget-object v1, p1, La/a/b/a/c;->x:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    goto :goto_3
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, La/a/b/a/c;->x:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    add-int/lit16 v0, v0, 0x20f

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    iget-object v0, p0, La/a/b/a/c;->x:Ljava/lang/String;

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_d

    iget-object v0, p0, La/a/b/a/c;->x:Ljava/lang/String;

    :goto_c
    return-object v0

    :cond_d
    const-string v0, "[DEFAULT]"

    goto :goto_c
.end method
