.class public final La/a/b/a/a;
.super Ljava/io/FilterInputStream;


# instance fields
.field private a:I

.field private b:I


# direct methods
.method public constructor <init>(Ljava/io/InputStream;)V
    .registers 3

    invoke-direct {p0, p1}, Ljava/io/FilterInputStream;-><init>(Ljava/io/InputStream;)V

    const/4 v0, -0x1

    iput v0, p0, La/a/b/a/a;->b:I

    return-void
.end method


# virtual methods
.method public final a()I
    .registers 2

    iget v0, p0, La/a/b/a/a;->a:I

    return v0
.end method

.method public final declared-synchronized mark(I)V
    .registers 3

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, La/a/b/a/a;->in:Ljava/io/InputStream;

    invoke-virtual {v0, p1}, Ljava/io/InputStream;->mark(I)V

    iget v0, p0, La/a/b/a/a;->a:I

    iput v0, p0, La/a/b/a/a;->b:I
    :try_end_a
    .catchall {:try_start_1 .. :try_end_a} :catchall_c

    monitor-exit p0

    return-void

    :catchall_c
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final read()I
    .registers 3

    iget-object v0, p0, La/a/b/a/a;->in:Ljava/io/InputStream;

    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_f

    iget v1, p0, La/a/b/a/a;->a:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, La/a/b/a/a;->a:I

    :cond_f
    return v0
.end method

.method public final read([BII)I
    .registers 6

    iget-object v0, p0, La/a/b/a/a;->in:Ljava/io/InputStream;

    invoke-virtual {v0, p1, p2, p3}, Ljava/io/InputStream;->read([BII)I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_e

    iget v1, p0, La/a/b/a/a;->a:I

    add-int/2addr v1, v0

    iput v1, p0, La/a/b/a/a;->a:I

    :cond_e
    return v0
.end method

.method public final declared-synchronized reset()V
    .registers 3

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, La/a/b/a/a;->in:Ljava/io/InputStream;

    invoke-virtual {v0}, Ljava/io/InputStream;->markSupported()Z

    move-result v0

    if-nez v0, :cond_14

    new-instance v0, Ljava/io/IOException;

    const-string v1, "Mark not supported"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_11
    .catchall {:try_start_1 .. :try_end_11} :catchall_11

    :catchall_11
    move-exception v0

    monitor-exit p0

    throw v0

    :cond_14
    :try_start_14
    iget v0, p0, La/a/b/a/a;->b:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_21

    new-instance v0, Ljava/io/IOException;

    const-string v1, "Mark not set"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_21
    iget-object v0, p0, La/a/b/a/a;->in:Ljava/io/InputStream;

    invoke-virtual {v0}, Ljava/io/InputStream;->reset()V

    iget v0, p0, La/a/b/a/a;->b:I

    iput v0, p0, La/a/b/a/a;->a:I
    :try_end_2a
    .catchall {:try_start_14 .. :try_end_2a} :catchall_11

    monitor-exit p0

    return-void
.end method

.method public final skip(J)J
    .registers 8

    iget-object v0, p0, La/a/b/a/a;->in:Ljava/io/InputStream;

    invoke-virtual {v0, p1, p2}, Ljava/io/InputStream;->skip(J)J

    move-result-wide v0

    iget v2, p0, La/a/b/a/a;->a:I

    int-to-long v2, v2

    add-long/2addr v2, v0

    long-to-int v2, v2

    iput v2, p0, La/a/b/a/a;->a:I

    return-wide v0
.end method
