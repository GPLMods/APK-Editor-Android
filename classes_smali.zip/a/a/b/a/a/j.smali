.class public final La/a/b/a/a/j;
.super La/a/b/a/a/b;


# instance fields
.field private final b:[La/a/b/a/a/l;

.field private c:[La/a/b/a/a/l;

.field private d:[La/a/b/a/a/l;


# direct methods
.method constructor <init>(La/a/b/a/a/s;ILjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;[La/d/e;)V
    .registers 12

    invoke-direct/range {p0 .. p5}, La/a/b/a/a/b;-><init>(La/a/b/a/a/s;ILjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;)V

    array-length v0, p6

    new-array v0, v0, [La/a/b/a/a/l;

    iput-object v0, p0, La/a/b/a/a/j;->b:[La/a/b/a/a/l;

    const/4 v0, 0x0

    move v2, v0

    :goto_a
    array-length v0, p6

    if-ge v2, v0, :cond_2a

    iget-object v3, p0, La/a/b/a/a/j;->b:[La/a/b/a/a/l;

    new-instance v4, La/a/b/a/a/l;

    aget-object v0, p6, v2

    iget-object v0, v0, La/d/e;->a:Ljava/lang/Object;

    check-cast v0, La/a/b/a/a/s;

    aget-object v1, p6, v2

    iget-object v1, v1, La/d/e;->b:Ljava/lang/Object;

    check-cast v1, La/a/b/a/a/q;

    invoke-virtual {v1}, La/a/b/a/a/q;->b()I

    move-result v1

    invoke-direct {v4, v0, v1}, La/a/b/a/a/l;-><init>(La/a/b/a/a/s;I)V

    aput-object v4, v3, v2

    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_a

    :cond_2a
    return-void
.end method

.method private static a([La/a/b/a/a/l;)Ljava/lang/String;
    .registers 4

    const-string v1, ""

    const/4 v0, 0x0

    :goto_3
    array-length v2, p0

    if-ge v0, v2, :cond_26

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "|"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    aget-object v2, p0, v0

    invoke-virtual {v2}, La/a/b/a/a/l;->a()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_26
    const-string v0, ""

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2f

    :goto_2e
    return-object v1

    :cond_2f
    const/4 v0, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_2e
.end method


# virtual methods
.method public final a(La/a/b/a/a/t;)Ljava/lang/String;
    .registers 12

    const/4 v1, 0x0

    instance-of v0, p1, La/a/b/a/a/s;

    if-eqz v0, :cond_a

    invoke-virtual {p1}, La/a/b/a/a/t;->a()Ljava/lang/String;

    move-result-object v0

    :goto_9
    return-object v0

    :cond_a
    instance-of v0, p1, La/a/b/a/a/q;

    if-nez v0, :cond_13

    invoke-super {p0, p1}, La/a/b/a/a/b;->a(La/a/b/a/a/t;)Ljava/lang/String;

    move-result-object v0

    goto :goto_9

    :cond_13
    iget-object v0, p0, La/a/b/a/a/j;->d:[La/a/b/a/a/l;

    if-nez v0, :cond_59

    iget-object v0, p0, La/a/b/a/a/j;->b:[La/a/b/a/a/l;

    array-length v0, v0

    new-array v5, v0, [La/a/b/a/a/l;

    iget-object v0, p0, La/a/b/a/a/j;->b:[La/a/b/a/a/l;

    array-length v0, v0

    new-array v6, v0, [La/a/b/a/a/l;

    move v0, v1

    move v2, v1

    move v3, v1

    :goto_24
    iget-object v4, p0, La/a/b/a/a/j;->b:[La/a/b/a/a/l;

    array-length v4, v4

    if-ge v0, v4, :cond_3f

    iget-object v4, p0, La/a/b/a/a/j;->b:[La/a/b/a/a/l;

    aget-object v7, v4, v0

    iget v4, v7, La/a/b/a/a/l;->a:I

    if-nez v4, :cond_39

    add-int/lit8 v4, v3, 0x1

    aput-object v7, v5, v3

    move v3, v4

    :goto_36
    add-int/lit8 v0, v0, 0x1

    goto :goto_24

    :cond_39
    add-int/lit8 v4, v2, 0x1

    aput-object v7, v6, v2

    move v2, v4

    goto :goto_36

    :cond_3f
    invoke-static {v5, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [La/a/b/a/a/l;

    iput-object v0, p0, La/a/b/a/a/j;->c:[La/a/b/a/a/l;

    invoke-static {v6, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [La/a/b/a/a/l;

    iput-object v0, p0, La/a/b/a/a/j;->d:[La/a/b/a/a/l;

    iget-object v0, p0, La/a/b/a/a/j;->d:[La/a/b/a/a/l;

    new-instance v2, La/a/b/a/a/k;

    invoke-direct {v2, p0}, La/a/b/a/a/k;-><init>(La/a/b/a/a/j;)V

    invoke-static {v0, v2}, Ljava/util/Arrays;->sort([Ljava/lang/Object;Ljava/util/Comparator;)V

    :cond_59
    check-cast p1, La/a/b/a/a/q;

    invoke-virtual {p1}, La/a/b/a/a/q;->b()I

    move-result v4

    if-nez v4, :cond_68

    iget-object v0, p0, La/a/b/a/a/j;->c:[La/a/b/a/a/l;

    invoke-static {v0}, La/a/b/a/a/j;->a([La/a/b/a/a/l;)Ljava/lang/String;

    move-result-object v0

    goto :goto_9

    :cond_68
    iget-object v0, p0, La/a/b/a/a/j;->d:[La/a/b/a/a/l;

    array-length v0, v0

    new-array v5, v0, [La/a/b/a/a/l;

    iget-object v0, p0, La/a/b/a/a/j;->d:[La/a/b/a/a/l;

    array-length v0, v0

    new-array v6, v0, [I

    move v3, v1

    move v2, v1

    :goto_74
    iget-object v0, p0, La/a/b/a/a/j;->d:[La/a/b/a/a/l;

    array-length v0, v0

    if-ge v3, v0, :cond_9f

    iget-object v0, p0, La/a/b/a/a/j;->d:[La/a/b/a/a/l;

    aget-object v7, v0, v3

    iget v8, v7, La/a/b/a/a/l;->a:I

    and-int v0, v4, v8

    if-ne v0, v8, :cond_ab

    move v0, v1

    :goto_84
    array-length v9, v6

    if-ge v0, v9, :cond_9d

    aget v9, v6, v0

    and-int/2addr v9, v8

    if-ne v9, v8, :cond_9a

    const/4 v0, 0x1

    :goto_8d
    if-nez v0, :cond_ab

    aput v8, v6, v2

    add-int/lit8 v0, v2, 0x1

    aput-object v7, v5, v2

    :goto_95
    add-int/lit8 v2, v3, 0x1

    move v3, v2

    move v2, v0

    goto :goto_74

    :cond_9a
    add-int/lit8 v0, v0, 0x1

    goto :goto_84

    :cond_9d
    move v0, v1

    goto :goto_8d

    :cond_9f
    invoke-static {v5, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [La/a/b/a/a/l;

    invoke-static {v0}, La/a/b/a/a/j;->a([La/a/b/a/a/l;)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_9

    :cond_ab
    move v0, v2

    goto :goto_95
.end method

.method protected final a(Lorg/xmlpull/v1/XmlSerializer;)V
    .registers 9

    const/4 v1, 0x0

    const/4 v6, 0x0

    move v0, v1

    :goto_3
    iget-object v2, p0, La/a/b/a/a/j;->b:[La/a/b/a/a/l;

    array-length v2, v2

    if-ge v0, v2, :cond_38

    iget-object v2, p0, La/a/b/a/a/j;->b:[La/a/b/a/a/l;

    aget-object v2, v2, v0

    const-string v3, "flag"

    invoke-interface {p1, v6, v3}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v3, "name"

    invoke-virtual {v2}, La/a/b/a/a/l;->a()Ljava/lang/String;

    move-result-object v4

    invoke-interface {p1, v6, v3, v4}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v3, "value"

    const-string v4, "0x%08x"

    const/4 v5, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    iget v2, v2, La/a/b/a/a/l;->a:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v5, v1

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {p1, v6, v3, v2}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v2, "flag"

    invoke-interface {p1, v6, v2}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_38
    return-void
.end method
