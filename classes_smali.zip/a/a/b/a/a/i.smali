.class public final La/a/b/a/a/i;
.super La/a/b/a/a/p;


# instance fields
.field private final a:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;I)V
    .registers 3

    invoke-direct {p0, p2}, La/a/b/a/a/p;-><init>(I)V

    iput-object p1, p0, La/a/b/a/a/i;->a:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La/a/b/a/a/i;->a:Ljava/lang/String;

    return-object v0
.end method

.method public final b()Ljava/lang/String;
    .registers 3

    iget-object v0, p0, La/a/b/a/a/i;->a:Ljava/lang/String;

    const-string v1, "res/"

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_12

    iget-object v0, p0, La/a/b/a/a/i;->a:Ljava/lang/String;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    :goto_11
    return-object v0

    :cond_12
    iget-object v0, p0, La/a/b/a/a/i;->a:Ljava/lang/String;

    const-string v1, "r/"

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_26

    iget-object v0, p0, La/a/b/a/a/i;->a:Ljava/lang/String;

    const-string v1, "R/"

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2e

    :cond_26
    iget-object v0, p0, La/a/b/a/a/i;->a:Ljava/lang/String;

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_11

    :cond_2e
    iget-object v0, p0, La/a/b/a/a/i;->a:Ljava/lang/String;

    goto :goto_11
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La/a/b/a/a/i;->a:Ljava/lang/String;

    return-object v0
.end method
