.class public La/a/b/a/a/q;
.super La/a/b/a/a/t;


# instance fields
.field protected final a:I

.field private c:I


# direct methods
.method public constructor <init>(ILjava/lang/String;I)V
    .registers 5

    const-string v0, "integer"

    invoke-direct {p0, p1, p2, v0}, La/a/b/a/a/q;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    iput p3, p0, La/a/b/a/a/q;->c:I

    return-void
.end method

.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0, p3, p1, p2}, La/a/b/a/a/t;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    iput p1, p0, La/a/b/a/a/q;->a:I

    return-void
.end method


# virtual methods
.method protected a()Ljava/lang/String;
    .registers 3

    iget v0, p0, La/a/b/a/a/q;->c:I

    iget v1, p0, La/a/b/a/a/q;->a:I

    invoke-static {v0, v1}, Landroid/util/TypedValue;->coerceToString(II)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final b()I
    .registers 2

    iget v0, p0, La/a/b/a/a/q;->a:I

    return v0
.end method
