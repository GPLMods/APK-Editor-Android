.class public final La/a/b/a/a/h;
.super La/a/b/a/a/b;


# instance fields
.field private final b:[La/d/e;

.field private final c:Ljava/util/Map;


# direct methods
.method constructor <init>(La/a/b/a/a/s;ILjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;[La/d/e;)V
    .registers 8

    invoke-direct/range {p0 .. p5}, La/a/b/a/a/b;-><init>(La/a/b/a/a/s;ILjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;)V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, La/a/b/a/a/h;->c:Ljava/util/Map;

    iput-object p6, p0, La/a/b/a/a/h;->b:[La/d/e;

    return-void
.end method


# virtual methods
.method public final a(La/a/b/a/a/t;)Ljava/lang/String;
    .registers 10

    instance-of v0, p1, La/a/b/a/a/q;

    if-eqz v0, :cond_4b

    move-object v0, p1

    check-cast v0, La/a/b/a/a/q;

    invoke-virtual {v0}, La/a/b/a/a/q;->b()I

    move-result v4

    iget-object v0, p0, La/a/b/a/a/h;->c:Ljava/util/Map;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_44

    const/4 v2, 0x0

    iget-object v5, p0, La/a/b/a/a/h;->b:[La/d/e;

    array-length v6, v5

    const/4 v1, 0x0

    move v3, v1

    :goto_1f
    if-ge v3, v6, :cond_50

    aget-object v7, v5, v3

    iget-object v1, v7, La/d/e;->b:Ljava/lang/Object;

    check-cast v1, La/a/b/a/a/q;

    invoke-virtual {v1}, La/a/b/a/a/q;->b()I

    move-result v1

    if-ne v1, v4, :cond_47

    iget-object v1, v7, La/d/e;->a:Ljava/lang/Object;

    check-cast v1, La/a/b/a/a/s;

    :goto_31
    if-eqz v1, :cond_44

    invoke-virtual {v1}, La/a/b/a/a/s;->d()La/a/b/a/f;

    move-result-object v0

    invoke-virtual {v0}, La/a/b/a/f;->f()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, La/a/b/a/a/h;->c:Ljava/util/Map;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_44
    if-eqz v0, :cond_4b

    :goto_46
    return-object v0

    :cond_47
    add-int/lit8 v1, v3, 0x1

    move v3, v1

    goto :goto_1f

    :cond_4b
    invoke-super {p0, p1}, La/a/b/a/a/b;->a(La/a/b/a/a/t;)Ljava/lang/String;

    move-result-object v0

    goto :goto_46

    :cond_50
    move-object v1, v2

    goto :goto_31
.end method

.method protected final a(Lorg/xmlpull/v1/XmlSerializer;)V
    .registers 10

    const/4 v7, 0x0

    iget-object v2, p0, La/a/b/a/a/h;->b:[La/d/e;

    array-length v3, v2

    const/4 v0, 0x0

    move v1, v0

    :goto_6
    if-ge v1, v3, :cond_3a

    aget-object v4, v2, v1

    iget-object v0, v4, La/d/e;->b:Ljava/lang/Object;

    check-cast v0, La/a/b/a/a/q;

    invoke-virtual {v0}, La/a/b/a/a/q;->b()I

    move-result v5

    const-string v0, "enum"

    invoke-interface {p1, v7, v0}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v6, "name"

    iget-object v0, v4, La/d/e;->a:Ljava/lang/Object;

    check-cast v0, La/a/b/a/a/s;

    invoke-virtual {v0}, La/a/b/a/a/s;->d()La/a/b/a/f;

    move-result-object v0

    invoke-virtual {v0}, La/a/b/a/f;->f()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1, v7, v6, v0}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v0, "value"

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-interface {p1, v7, v0, v4}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v0, "enum"

    invoke-interface {p1, v7, v0}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_6

    :cond_3a
    return-void
.end method
