.class public final La/a/b/a/a/s;
.super La/a/b/a/a/q;

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field private final c:La/a/b/a/e;

.field private final d:Z


# direct methods
.method public constructor <init>(La/a/b/a/e;ILjava/lang/String;)V
    .registers 6

    const/4 v1, 0x0

    const/4 v0, 0x0

    invoke-direct {p0, p1, v1, v0, v1}, La/a/b/a/a/s;-><init>(La/a/b/a/e;ILjava/lang/String;Z)V

    return-void
.end method

.method public constructor <init>(La/a/b/a/e;ILjava/lang/String;Z)V
    .registers 6

    const-string v0, "reference"

    invoke-direct {p0, p2, p3, v0}, La/a/b/a/a/q;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    iput-object p1, p0, La/a/b/a/a/s;->c:La/a/b/a/e;

    iput-boolean p4, p0, La/a/b/a/a/s;->d:Z

    return-void
.end method


# virtual methods
.method protected final a()Ljava/lang/String;
    .registers 8

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, La/a/b/a/a/s;->e()Z

    move-result v0

    if-eqz v0, :cond_b

    const-string v0, "@null"

    :goto_a
    return-object v0

    :cond_b
    invoke-virtual {p0}, La/a/b/a/a/s;->d()La/a/b/a/f;

    move-result-object v4

    if-nez v4, :cond_14

    const-string v0, "@null"

    goto :goto_a

    :cond_14
    invoke-virtual {v4}, La/a/b/a/f;->d()Z

    move-result v0

    if-eqz v0, :cond_6e

    invoke-virtual {v4}, La/a/b/a/f;->c()La/a/b/a/g;

    move-result-object v0

    invoke-virtual {v0}, La/a/b/a/g;->d()La/a/b/a/a/w;

    move-result-object v0

    instance-of v0, v0, La/a/b/a/a/o;

    if-eqz v0, :cond_6e

    move v0, v1

    :goto_27
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    iget-boolean v3, p0, La/a/b/a/a/s;->d:Z

    if-eqz v3, :cond_70

    const/16 v3, 0x3f

    :goto_32
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v3

    if-eqz v0, :cond_73

    const-string v0, "+"

    :goto_3a
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v3, p0, La/a/b/a/a/s;->c:La/a/b/a/e;

    iget-boolean v5, p0, La/a/b/a/a/s;->d:Z

    if-eqz v5, :cond_76

    invoke-virtual {v4}, La/a/b/a/f;->h()La/a/b/a/i;

    move-result-object v5

    invoke-virtual {v5}, La/a/b/a/i;->a()Ljava/lang/String;

    move-result-object v5

    const-string v6, "attr"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_76

    :goto_61
    invoke-virtual {v4, v3, v1}, La/a/b/a/f;->a(La/a/b/a/e;Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_a

    :cond_6e
    move v0, v2

    goto :goto_27

    :cond_70
    const/16 v3, 0x40

    goto :goto_32

    :cond_73
    const-string v0, ""

    goto :goto_3a

    :cond_76
    move v1, v2

    goto :goto_61
.end method

.method public final d()La/a/b/a/f;
    .registers 3

    :try_start_0
    iget-object v0, p0, La/a/b/a/a/s;->c:La/a/b/a/e;

    invoke-virtual {v0}, La/a/b/a/e;->d()Lcom/gmail/heagoo/a/c/a;

    move-result-object v0

    invoke-virtual {p0}, La/a/b/a/a/s;->b()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/gmail/heagoo/a/c/a;->a(I)La/a/b/a/f;
    :try_end_d
    .catch La/a/a/b; {:try_start_0 .. :try_end_d} :catch_f

    move-result-object v0

    :goto_e
    return-object v0

    :catch_f
    move-exception v0

    const/4 v0, 0x0

    goto :goto_e
.end method

.method public final e()Z
    .registers 2

    iget v0, p0, La/a/b/a/a/s;->a:I

    if-nez v0, :cond_6

    const/4 v0, 0x1

    :goto_5
    return v0

    :cond_6
    const/4 v0, 0x0

    goto :goto_5
.end method
