.class public final La/a/b/a/a/a;
.super La/a/b/a/a/c;

# interfaces
.implements La/a/b/d/a;


# instance fields
.field private final b:[La/a/b/a/a/t;

.field private final c:[Ljava/lang/String;


# direct methods
.method constructor <init>(La/a/b/a/a/s;[La/d/e;)V
    .registers 7

    const/4 v0, 0x0

    invoke-direct {p0, p1}, La/a/b/a/a/c;-><init>(La/a/b/a/a/s;)V

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/String;

    const-string v2, "string"

    aput-object v2, v1, v0

    const/4 v2, 0x1

    const-string v3, "integer"

    aput-object v3, v1, v2

    iput-object v1, p0, La/a/b/a/a/a;->c:[Ljava/lang/String;

    array-length v1, p2

    new-array v1, v1, [La/a/b/a/a/t;

    iput-object v1, p0, La/a/b/a/a/a;->b:[La/a/b/a/a/t;

    move v1, v0

    :goto_18
    array-length v0, p2

    if-ge v1, v0, :cond_29

    iget-object v2, p0, La/a/b/a/a/a;->b:[La/a/b/a/a/t;

    aget-object v0, p2, v1

    iget-object v0, v0, La/d/e;->b:Ljava/lang/Object;

    check-cast v0, La/a/b/a/a/t;

    aput-object v0, v2, v1

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_18

    :cond_29
    return-void
.end method


# virtual methods
.method public final a(Lorg/xmlpull/v1/XmlSerializer;La/a/b/a/g;)V
    .registers 9

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, La/a/b/a/a/a;->b:[La/a/b/a/a/t;

    array-length v0, v0

    if-nez v0, :cond_63

    move-object v0, v2

    :goto_8
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    if-nez v0, :cond_e5

    const-string v0, ""

    :goto_11
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, "array"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-interface {p1, v2, v3}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v0, "name"

    invoke-virtual {p2}, La/a/b/a/g;->c()La/a/b/a/f;

    move-result-object v4

    invoke-virtual {v4}, La/a/b/a/f;->f()Ljava/lang/String;

    move-result-object v4

    invoke-interface {p1, v2, v0, v4}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    move v0, v1

    :goto_30
    iget-object v4, p0, La/a/b/a/a/a;->b:[La/a/b/a/a/t;

    array-length v4, v4

    if-ge v0, v4, :cond_46

    iget-object v4, p0, La/a/b/a/a/a;->b:[La/a/b/a/a/t;

    aget-object v4, v4, v0

    invoke-virtual {v4}, La/a/b/a/a/t;->j()Z

    move-result v4

    if-eqz v4, :cond_fa

    const-string v0, "formatted"

    const-string v4, "false"

    invoke-interface {p1, v2, v0, v4}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    :cond_46
    :goto_46
    iget-object v0, p0, La/a/b/a/a/a;->b:[La/a/b/a/a/t;

    array-length v0, v0

    if-ge v1, v0, :cond_fe

    const-string v0, "item"

    invoke-interface {p1, v2, v0}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    iget-object v0, p0, La/a/b/a/a/a;->b:[La/a/b/a/a/t;

    aget-object v0, v0, v1

    invoke-virtual {v0}, La/a/b/a/a/t;->i()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1, v0}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v0, "item"

    invoke-interface {p1, v2, v0}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    add-int/lit8 v1, v1, 0x1

    goto :goto_46

    :cond_63
    iget-object v0, p0, La/a/b/a/a/a;->b:[La/a/b/a/a/t;

    aget-object v0, v0, v1

    invoke-virtual {v0}, La/a/b/a/a/t;->k()Ljava/lang/String;

    move-result-object v3

    move v0, v1

    :goto_6c
    iget-object v4, p0, La/a/b/a/a/a;->b:[La/a/b/a/a/t;

    array-length v4, v4

    if-ge v0, v4, :cond_d2

    iget-object v4, p0, La/a/b/a/a/a;->b:[La/a/b/a/a/t;

    aget-object v4, v4, v0

    invoke-virtual {v4}, La/a/b/a/a/t;->g()Ljava/lang/String;

    move-result-object v4

    const-string v5, "@string"

    invoke-virtual {v4, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_84

    const-string v0, "string"

    goto :goto_8

    :cond_84
    iget-object v4, p0, La/a/b/a/a/a;->b:[La/a/b/a/a/t;

    aget-object v4, v4, v0

    invoke-virtual {v4}, La/a/b/a/a/t;->g()Ljava/lang/String;

    move-result-object v4

    const-string v5, "@drawable"

    invoke-virtual {v4, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_97

    move-object v0, v2

    goto/16 :goto_8

    :cond_97
    iget-object v4, p0, La/a/b/a/a/a;->b:[La/a/b/a/a/t;

    aget-object v4, v4, v0

    invoke-virtual {v4}, La/a/b/a/a/t;->g()Ljava/lang/String;

    move-result-object v4

    const-string v5, "@integer"

    invoke-virtual {v4, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_ab

    const-string v0, "integer"

    goto/16 :goto_8

    :cond_ab
    const-string v4, "string"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_be

    const-string v4, "integer"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_be

    move-object v0, v2

    goto/16 :goto_8

    :cond_be
    iget-object v4, p0, La/a/b/a/a/a;->b:[La/a/b/a/a/t;

    aget-object v4, v4, v0

    invoke-virtual {v4}, La/a/b/a/a/t;->k()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_cf

    move-object v0, v2

    goto/16 :goto_8

    :cond_cf
    add-int/lit8 v0, v0, 0x1

    goto :goto_6c

    :cond_d2
    iget-object v0, p0, La/a/b/a/a/a;->c:[Ljava/lang/String;

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_e2

    const-string v0, "string"

    goto/16 :goto_8

    :cond_e2
    move-object v0, v3

    goto/16 :goto_8

    :cond_e5
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v4, "-"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_11

    :cond_fa
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_30

    :cond_fe
    invoke-interface {p1, v2, v3}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    return-void
.end method
