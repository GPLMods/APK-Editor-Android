.class public final La/a/b/a/a/v;
.super La/a/b/a/a/c;

# interfaces
.implements La/a/b/d/a;


# instance fields
.field private final b:[La/d/e;


# direct methods
.method constructor <init>(La/a/b/a/a/s;[La/d/e;La/a/b/a/a/x;)V
    .registers 9

    invoke-direct {p0, p1}, La/a/b/a/a/c;-><init>(La/a/b/a/a/s;)V

    array-length v0, p2

    new-array v0, v0, [La/d/e;

    iput-object v0, p0, La/a/b/a/a/v;->b:[La/d/e;

    const/4 v0, 0x0

    move v1, v0

    :goto_a
    array-length v0, p2

    if-ge v1, v0, :cond_2d

    iget-object v2, p0, La/a/b/a/a/v;->b:[La/d/e;

    new-instance v3, La/d/e;

    aget-object v0, p2, v1

    iget-object v0, v0, La/d/e;->a:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v4, 0x0

    invoke-virtual {p3, v0, v4}, La/a/b/a/a/x;->a(ILjava/lang/String;)La/a/b/a/a/s;

    move-result-object v0

    aget-object v4, p2, v1

    iget-object v4, v4, La/d/e;->b:Ljava/lang/Object;

    invoke-direct {v3, v0, v4}, La/d/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    aput-object v3, v2, v1

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_a

    :cond_2d
    return-void
.end method


# virtual methods
.method public final a(Lorg/xmlpull/v1/XmlSerializer;La/a/b/a/g;)V
    .registers 10

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v0, "style"

    invoke-interface {p1, v4, v0}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v0, "name"

    invoke-virtual {p2}, La/a/b/a/g;->c()La/a/b/a/f;

    move-result-object v1

    invoke-virtual {v1}, La/a/b/a/f;->f()Ljava/lang/String;

    move-result-object v1

    invoke-interface {p1, v4, v0, v1}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    iget-object v0, p0, La/a/b/a/a/v;->a:La/a/b/a/a/s;

    invoke-virtual {v0}, La/a/b/a/a/s;->e()Z

    move-result v0

    if-nez v0, :cond_99

    iget-object v0, p0, La/a/b/a/a/v;->a:La/a/b/a/a/s;

    invoke-virtual {v0}, La/a/b/a/a/s;->d()La/a/b/a/f;

    move-result-object v0

    if-nez v0, :cond_97

    move v0, v5

    :goto_26
    if-nez v0, :cond_99

    const-string v0, "parent"

    iget-object v1, p0, La/a/b/a/a/v;->a:La/a/b/a/a/s;

    invoke-virtual {v1}, La/a/b/a/a/s;->f()Ljava/lang/String;

    move-result-object v1

    invoke-interface {p1, v4, v0, v1}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    :cond_33
    :goto_33
    move v2, v3

    :goto_34
    iget-object v0, p0, La/a/b/a/a/v;->b:[La/d/e;

    array-length v0, v0

    if-ge v2, v0, :cond_d0

    iget-object v0, p0, La/a/b/a/a/v;->b:[La/d/e;

    aget-object v0, v0, v2

    iget-object v0, v0, La/d/e;->a:Ljava/lang/Object;

    check-cast v0, La/a/b/a/a/s;

    invoke-virtual {v0}, La/a/b/a/a/s;->d()La/a/b/a/f;

    move-result-object v6

    if-eqz v6, :cond_93

    invoke-virtual {v6}, La/a/b/a/f;->c()La/a/b/a/g;

    move-result-object v0

    invoke-virtual {v0}, La/a/b/a/g;->d()La/a/b/a/a/w;

    move-result-object v0

    instance-of v1, v0, La/a/b/a/a/s;

    if-nez v1, :cond_93

    instance-of v1, v0, La/a/b/a/a/b;

    if-eqz v1, :cond_b2

    check-cast v0, La/a/b/a/a/b;

    iget-object v1, p0, La/a/b/a/a/v;->b:[La/d/e;

    aget-object v1, v1, v2

    iget-object v1, v1, La/d/e;->b:Ljava/lang/Object;

    check-cast v1, La/a/b/a/a/t;

    invoke-virtual {v0, v1}, La/a/b/a/a/b;->a(La/a/b/a/a/t;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2}, La/a/b/a/g;->c()La/a/b/a/f;

    move-result-object v1

    invoke-virtual {v1}, La/a/b/a/f;->g()La/a/b/a/e;

    move-result-object v1

    invoke-virtual {v6, v1, v5}, La/a/b/a/f;->a(La/a/b/a/e;Z)Ljava/lang/String;

    move-result-object v1

    :goto_71
    if-nez v0, :cond_7f

    iget-object v0, p0, La/a/b/a/a/v;->b:[La/d/e;

    aget-object v0, v0, v2

    iget-object v0, v0, La/d/e;->b:Ljava/lang/Object;

    check-cast v0, La/a/b/a/a/t;

    invoke-virtual {v0}, La/a/b/a/a/t;->h()Ljava/lang/String;

    move-result-object v0

    :cond_7f
    if-eqz v0, :cond_93

    const-string v6, "item"

    invoke-interface {p1, v4, v6}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v6, "name"

    invoke-interface {p1, v4, v6, v1}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    invoke-interface {p1, v0}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v0, "item"

    invoke-interface {p1, v4, v0}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    :cond_93
    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_34

    :cond_97
    move v0, v3

    goto :goto_26

    :cond_99
    invoke-virtual {p2}, La/a/b/a/g;->c()La/a/b/a/f;

    move-result-object v0

    invoke-virtual {v0}, La/a/b/a/f;->f()Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x2e

    invoke-virtual {v0, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_33

    const-string v0, "parent"

    const-string v1, ""

    invoke-interface {p1, v4, v0, v1}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    goto :goto_33

    :cond_b2
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "@"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2}, La/a/b/a/g;->c()La/a/b/a/f;

    move-result-object v1

    invoke-virtual {v1}, La/a/b/a/f;->g()La/a/b/a/e;

    move-result-object v1

    invoke-virtual {v6, v1, v3}, La/a/b/a/f;->a(La/a/b/a/e;Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move-object v1, v0

    move-object v0, v4

    goto :goto_71

    :cond_d0
    const-string v0, "style"

    invoke-interface {p1, v4, v0}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    return-void
.end method
