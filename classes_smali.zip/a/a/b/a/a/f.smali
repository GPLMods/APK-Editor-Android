.class public final La/a/b/a/a/f;
.super La/a/b/a/a/q;


# direct methods
.method public constructor <init>(ILjava/lang/String;)V
    .registers 4

    const-string v0, "dimen"

    invoke-direct {p0, p1, p2, v0}, La/a/b/a/a/q;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method protected final a()Ljava/lang/String;
    .registers 3

    const/4 v0, 0x5

    iget v1, p0, La/a/b/a/a/f;->a:I

    invoke-static {v0, v1}, Landroid/util/TypedValue;->coerceToString(II)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
