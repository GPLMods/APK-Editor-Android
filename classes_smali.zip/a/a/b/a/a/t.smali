.class public abstract La/a/b/a/a/t;
.super La/a/b/a/a/p;

# interfaces
.implements La/a/b/d/a;


# instance fields
.field private a:Ljava/lang/String;

.field protected b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Z


# direct methods
.method protected constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .registers 5

    invoke-direct {p0, p2}, La/a/b/a/a/p;-><init>(I)V

    const/4 v0, 0x0

    iput-boolean v0, p0, La/a/b/a/a/t;->d:Z

    iput-object p1, p0, La/a/b/a/a/t;->a:Ljava/lang/String;

    iput-object p3, p0, La/a/b/a/a/t;->b:Ljava/lang/String;

    return-void
.end method

.method protected constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Z)V
    .registers 7

    invoke-direct {p0, p2}, La/a/b/a/a/p;-><init>(I)V

    const/4 v0, 0x0

    iput-boolean v0, p0, La/a/b/a/a/t;->d:Z

    iput-object p1, p0, La/a/b/a/a/t;->a:Ljava/lang/String;

    iput-object p3, p0, La/a/b/a/a/t;->b:Ljava/lang/String;

    iput-object p4, p0, La/a/b/a/a/t;->c:Ljava/lang/String;

    iput-boolean p5, p0, La/a/b/a/a/t;->d:Z

    return-void
.end method


# virtual methods
.method protected abstract a()Ljava/lang/String;
.end method

.method protected a(Lorg/xmlpull/v1/XmlSerializer;)V
    .registers 2

    return-void
.end method

.method public final a(Lorg/xmlpull/v1/XmlSerializer;La/a/b/a/g;)V
    .registers 10

    const/4 v1, 0x1

    const/4 v6, 0x0

    invoke-virtual {p2}, La/a/b/a/g;->c()La/a/b/a/f;

    move-result-object v0

    invoke-virtual {v0}, La/a/b/a/f;->h()La/a/b/a/i;

    move-result-object v0

    invoke-virtual {v0}, La/a/b/a/i;->a()Ljava/lang/String;

    move-result-object v2

    const-string v0, "reference"

    iget-object v3, p0, La/a/b/a/a/t;->a:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6c

    iget-object v0, p0, La/a/b/a/a/t;->a:Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6c

    move v0, v1

    :goto_21
    invoke-virtual {p0}, La/a/b/a/a/t;->h()Ljava/lang/String;

    move-result-object v3

    const-string v4, "color"

    invoke-virtual {v2, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_70

    const-string v4, "@"

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_70

    invoke-virtual {p2}, La/a/b/a/g;->a()Ljava/lang/String;

    move-result-object v4

    const-string v5, "string"

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_70

    :goto_41
    if-eqz v1, :cond_6e

    const-string v0, "item"

    :goto_45
    invoke-interface {p1, v6, v0}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    if-eqz v1, :cond_4f

    const-string v1, "type"

    invoke-interface {p1, v6, v1, v2}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    :cond_4f
    const-string v1, "name"

    invoke-virtual {p2}, La/a/b/a/g;->c()La/a/b/a/f;

    move-result-object v2

    invoke-virtual {v2}, La/a/b/a/f;->f()Ljava/lang/String;

    move-result-object v2

    invoke-interface {p1, v6, v1, v2}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    invoke-virtual {p0, p1}, La/a/b/a/a/t;->a(Lorg/xmlpull/v1/XmlSerializer;)V

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_68

    invoke-interface {p1, v3}, Lorg/xmlpull/v1/XmlSerializer;->ignorableWhitespace(Ljava/lang/String;)V

    :cond_68
    invoke-interface {p1, v6, v0}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    return-void

    :cond_6c
    const/4 v0, 0x0

    goto :goto_21

    :cond_6e
    move-object v0, v2

    goto :goto_45

    :cond_70
    move v1, v0

    goto :goto_41
.end method

.method public f()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La/a/b/a/a/t;->b:Ljava/lang/String;

    if-eqz v0, :cond_7

    iget-object v0, p0, La/a/b/a/a/t;->b:Ljava/lang/String;

    :goto_6
    return-object v0

    :cond_7
    invoke-virtual {p0}, La/a/b/a/a/t;->a()Ljava/lang/String;

    move-result-object v0

    goto :goto_6
.end method

.method public g()Ljava/lang/String;
    .registers 2

    invoke-virtual {p0}, La/a/b/a/a/t;->h()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public h()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La/a/b/a/a/t;->b:Ljava/lang/String;

    if-eqz v0, :cond_7

    iget-object v0, p0, La/a/b/a/a/t;->b:Ljava/lang/String;

    :goto_6
    return-object v0

    :cond_7
    invoke-virtual {p0}, La/a/b/a/a/t;->a()Ljava/lang/String;

    move-result-object v0

    goto :goto_6
.end method

.method public final i()Ljava/lang/String;
    .registers 4

    invoke-virtual {p0}, La/a/b/a/a/t;->h()Ljava/lang/String;

    move-result-object v0

    const-string v1, "&amp;"

    const-string v2, "&"

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "&lt;"

    const-string v2, "<"

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final j()Z
    .registers 2

    iget-object v0, p0, La/a/b/a/a/t;->b:Ljava/lang/String;

    invoke-static {v0}, Lcom/gmail/heagoo/a/c/a;->d(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public final k()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La/a/b/a/a/t;->a:Ljava/lang/String;

    return-object v0
.end method

.method public final l()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La/a/b/a/a/t;->b:Ljava/lang/String;

    return-object v0
.end method

.method public final m()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La/a/b/a/a/t;->c:Ljava/lang/String;

    return-object v0
.end method

.method public final n()Z
    .registers 2

    iget-boolean v0, p0, La/a/b/a/a/t;->d:Z

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    :try_start_0
    invoke-virtual {p0}, La/a/b/a/a/t;->h()Ljava/lang/String;
    :try_end_3
    .catch La/a/a; {:try_start_0 .. :try_end_3} :catch_5

    move-result-object v0

    :goto_4
    return-object v0

    :catch_5
    move-exception v0

    const/4 v0, 0x0

    goto :goto_4
.end method
