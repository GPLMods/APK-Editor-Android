.class public final La/a/b/a/a/r;
.super La/a/b/a/a/c;

# interfaces
.implements La/a/b/d/a;


# static fields
.field private static final c:[Ljava/lang/String;


# instance fields
.field private final b:[La/a/b/a/a/t;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/4 v0, 0x6

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "other"

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string v2, "zero"

    aput-object v2, v0, v1

    const/4 v1, 0x2

    const-string v2, "one"

    aput-object v2, v0, v1

    const/4 v1, 0x3

    const-string v2, "two"

    aput-object v2, v0, v1

    const/4 v1, 0x4

    const-string v2, "few"

    aput-object v2, v0, v1

    const/4 v1, 0x5

    const-string v2, "many"

    aput-object v2, v0, v1

    sput-object v0, La/a/b/a/a/r;->c:[Ljava/lang/String;

    return-void
.end method

.method constructor <init>(La/a/b/a/a/s;[La/d/e;)V
    .registers 7

    invoke-direct {p0, p1}, La/a/b/a/a/c;-><init>(La/a/b/a/a/s;)V

    const/4 v0, 0x6

    new-array v0, v0, [La/a/b/a/a/t;

    iput-object v0, p0, La/a/b/a/a/r;->b:[La/a/b/a/a/t;

    const/4 v0, 0x0

    move v1, v0

    :goto_a
    array-length v0, p2

    if-ge v1, v0, :cond_2a

    iget-object v2, p0, La/a/b/a/a/r;->b:[La/a/b/a/a/t;

    aget-object v0, p2, v1

    iget-object v0, v0, La/d/e;->a:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const v3, 0x1000004

    sub-int v3, v0, v3

    aget-object v0, p2, v1

    iget-object v0, v0, La/d/e;->b:Ljava/lang/Object;

    check-cast v0, La/a/b/a/a/t;

    aput-object v0, v2, v3

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_a

    :cond_2a
    return-void
.end method


# virtual methods
.method public final a(Lorg/xmlpull/v1/XmlSerializer;La/a/b/a/g;)V
    .registers 8

    const/4 v4, 0x0

    const-string v0, "plurals"

    invoke-interface {p1, v4, v0}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v0, "name"

    invoke-virtual {p2}, La/a/b/a/g;->c()La/a/b/a/f;

    move-result-object v1

    invoke-virtual {v1}, La/a/b/a/f;->f()Ljava/lang/String;

    move-result-object v1

    invoke-interface {p1, v4, v0, v1}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const/4 v0, 0x0

    :goto_14
    const/4 v1, 0x6

    if-ge v0, v1, :cond_3e

    iget-object v1, p0, La/a/b/a/a/r;->b:[La/a/b/a/a/t;

    aget-object v1, v1, v0

    if-eqz v1, :cond_3b

    const-string v2, "item"

    invoke-interface {p1, v4, v2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v2, "quantity"

    sget-object v3, La/a/b/a/a/r;->c:[Ljava/lang/String;

    aget-object v3, v3, v0

    invoke-interface {p1, v4, v2, v3}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    invoke-virtual {v1}, La/a/b/a/a/t;->i()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/gmail/heagoo/a/c/a;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {p1, v1}, Lorg/xmlpull/v1/XmlSerializer;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v1, "item"

    invoke-interface {p1, v4, v1}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    :cond_3b
    add-int/lit8 v0, v0, 0x1

    goto :goto_14

    :cond_3e
    const-string v0, "plurals"

    invoke-interface {p1, v4, v0}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    return-void
.end method
