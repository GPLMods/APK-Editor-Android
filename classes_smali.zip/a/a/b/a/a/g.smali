.class public final La/a/b/a/a/g;
.super La/a/b/a/a/t;


# direct methods
.method public constructor <init>(ILjava/lang/String;I)V
    .registers 5

    const-string v0, "integer"

    invoke-direct {p0, p1, p2, v0}, La/a/b/a/a/g;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private constructor <init>(ILjava/lang/String;Ljava/lang/String;)V
    .registers 5

    invoke-direct {p0, p3, p1, p2}, La/a/b/a/a/t;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    const/4 v0, 0x1

    if-eq p1, v0, :cond_c

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0

    :cond_c
    return-void
.end method


# virtual methods
.method protected final a()Ljava/lang/String;
    .registers 2

    const-string v0, "@empty"

    return-object v0
.end method
