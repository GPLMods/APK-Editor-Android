.class public La/a/b/a/a/c;
.super La/a/b/a/a/w;

# interfaces
.implements La/a/b/d/a;
.implements Ljava/io/Serializable;


# instance fields
.field protected final a:La/a/b/a/a/s;


# direct methods
.method public constructor <init>(La/a/b/a/a/s;)V
    .registers 2

    invoke-direct {p0}, La/a/b/a/a/w;-><init>()V

    iput-object p1, p0, La/a/b/a/a/c;->a:La/a/b/a/a/s;

    return-void
.end method


# virtual methods
.method public a(Lorg/xmlpull/v1/XmlSerializer;La/a/b/a/g;)V
    .registers 7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p2}, La/a/b/a/g;->c()La/a/b/a/f;

    move-result-object v0

    invoke-virtual {v0}, La/a/b/a/f;->h()La/a/b/a/i;

    move-result-object v0

    invoke-virtual {v0}, La/a/b/a/i;->a()Ljava/lang/String;

    move-result-object v0

    const-string v1, "style"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_23

    new-instance v0, La/a/b/a/a/v;

    iget-object v1, p0, La/a/b/a/a/c;->a:La/a/b/a/a/s;

    new-array v2, v2, [La/d/e;

    invoke-direct {v0, v1, v2, v3}, La/a/b/a/a/v;-><init>(La/a/b/a/a/s;[La/d/e;La/a/b/a/a/x;)V

    invoke-virtual {v0, p1, p2}, La/a/b/a/a/v;->a(Lorg/xmlpull/v1/XmlSerializer;La/a/b/a/g;)V

    :goto_22
    return-void

    :cond_23
    const-string v1, "array"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_38

    new-instance v0, La/a/b/a/a/a;

    iget-object v1, p0, La/a/b/a/a/c;->a:La/a/b/a/a/s;

    new-array v2, v2, [La/d/e;

    invoke-direct {v0, v1, v2}, La/a/b/a/a/a;-><init>(La/a/b/a/a/s;[La/d/e;)V

    invoke-virtual {v0, p1, p2}, La/a/b/a/a/a;->a(Lorg/xmlpull/v1/XmlSerializer;La/a/b/a/g;)V

    goto :goto_22

    :cond_38
    const-string v1, "plurals"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4d

    new-instance v0, La/a/b/a/a/r;

    iget-object v1, p0, La/a/b/a/a/c;->a:La/a/b/a/a/s;

    new-array v2, v2, [La/d/e;

    invoke-direct {v0, v1, v2}, La/a/b/a/a/r;-><init>(La/a/b/a/a/s;[La/d/e;)V

    invoke-virtual {v0, p1, p2}, La/a/b/a/a/r;->a(Lorg/xmlpull/v1/XmlSerializer;La/a/b/a/g;)V

    goto :goto_22

    :cond_4d
    const-string v1, "item"

    invoke-interface {p1, v3, v1}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v1, "type"

    invoke-interface {p1, v3, v1, v0}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v0, "name"

    invoke-virtual {p2}, La/a/b/a/g;->c()La/a/b/a/f;

    move-result-object v1

    invoke-virtual {v1}, La/a/b/a/f;->f()Ljava/lang/String;

    move-result-object v1

    invoke-interface {p1, v3, v0, v1}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v0, "item"

    invoke-interface {p1, v3, v0}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    goto :goto_22
.end method
