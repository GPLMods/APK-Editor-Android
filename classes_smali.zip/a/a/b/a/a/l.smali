.class final La/a/b/a/a/l;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public final a:I

.field private b:La/a/b/a/a/s;

.field private c:Ljava/lang/String;


# direct methods
.method public constructor <init>(La/a/b/a/a/s;I)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/a/b/a/a/l;->b:La/a/b/a/a/s;

    iput p2, p0, La/a/b/a/a/l;->a:I

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, La/a/b/a/a/l;->c:Ljava/lang/String;

    if-nez v0, :cond_10

    iget-object v0, p0, La/a/b/a/a/l;->b:La/a/b/a/a/s;

    invoke-virtual {v0}, La/a/b/a/a/s;->d()La/a/b/a/f;

    move-result-object v0

    invoke-virtual {v0}, La/a/b/a/f;->f()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, La/a/b/a/a/l;->c:Ljava/lang/String;

    :cond_10
    iget-object v0, p0, La/a/b/a/a/l;->c:Ljava/lang/String;

    return-object v0
.end method
