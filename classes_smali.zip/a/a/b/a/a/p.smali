.class public La/a/b/a/a/p;
.super La/a/b/a/a/w;


# instance fields
.field private a:I


# direct methods
.method protected constructor <init>(I)V
    .registers 2

    invoke-direct {p0}, La/a/b/a/a/w;-><init>()V

    iput p1, p0, La/a/b/a/a/p;->a:I

    return-void
.end method


# virtual methods
.method public final c()I
    .registers 2

    iget v0, p0, La/a/b/a/a/p;->a:I

    return v0
.end method
