.class public La/a/b/a/a/b;
.super La/a/b/a/a/c;

# interfaces
.implements La/a/b/d/a;


# instance fields
.field private final b:I

.field private final c:Ljava/lang/Integer;

.field private final d:Ljava/lang/Integer;

.field private final e:Ljava/lang/Boolean;


# direct methods
.method constructor <init>(La/a/b/a/a/s;ILjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;)V
    .registers 6

    invoke-direct {p0, p1}, La/a/b/a/a/c;-><init>(La/a/b/a/a/s;)V

    iput p2, p0, La/a/b/a/a/b;->b:I

    iput-object p3, p0, La/a/b/a/a/b;->c:Ljava/lang/Integer;

    iput-object p4, p0, La/a/b/a/a/b;->d:Ljava/lang/Integer;

    iput-object p5, p0, La/a/b/a/a/b;->e:Ljava/lang/Boolean;

    return-void
.end method

.method public static a(La/a/b/a/a/s;[La/d/e;La/a/b/a/a/x;La/a/b/a/e;)La/a/b/a/a/b;
    .registers 16

    const/4 v0, 0x0

    aget-object v0, p1, v0

    iget-object v0, v0, La/d/e;->b:Ljava/lang/Object;

    check-cast v0, La/a/b/a/a/q;

    invoke-virtual {v0}, La/a/b/a/a/q;->b()I

    move-result v9

    const v0, 0xffff

    and-int v2, v9, v0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v0, 0x1

    move v1, v0

    :goto_15
    array-length v0, p1

    if-ge v1, v0, :cond_25

    aget-object v0, p1, v1

    iget-object v0, v0, La/d/e;->a:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    packed-switch v0, :pswitch_data_b2

    :cond_25
    array-length v0, p1

    if-ne v1, v0, :cond_64

    new-instance v0, La/a/b/a/a/b;

    move-object v1, p0

    invoke-direct/range {v0 .. v5}, La/a/b/a/a/b;-><init>(La/a/b/a/a/s;ILjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;)V

    :goto_2e
    return-object v0

    :pswitch_2f  #0x1000001
    aget-object v0, p1, v1

    iget-object v0, v0, La/d/e;->b:Ljava/lang/Object;

    check-cast v0, La/a/b/a/a/q;

    invoke-virtual {v0}, La/a/b/a/a/q;->b()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    :goto_3d
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_15

    :pswitch_41  #0x1000002
    aget-object v0, p1, v1

    iget-object v0, v0, La/d/e;->b:Ljava/lang/Object;

    check-cast v0, La/a/b/a/a/q;

    invoke-virtual {v0}, La/a/b/a/a/q;->b()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    goto :goto_3d

    :pswitch_50  #0x1000003
    aget-object v0, p1, v1

    iget-object v0, v0, La/d/e;->b:Ljava/lang/Object;

    check-cast v0, La/a/b/a/a/q;

    invoke-virtual {v0}, La/a/b/a/a/q;->b()I

    move-result v0

    if-eqz v0, :cond_62

    const/4 v0, 0x1

    :goto_5d
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    goto :goto_3d

    :cond_62
    const/4 v0, 0x0

    goto :goto_5d

    :cond_64
    array-length v0, p1

    sub-int/2addr v0, v1

    new-array v6, v0, [La/d/e;

    const/4 v0, 0x0

    move v8, v1

    move v1, v0

    :goto_6b
    array-length v0, p1

    if-ge v8, v0, :cond_94

    aget-object v0, p1, v8

    iget-object v0, v0, La/d/e;->a:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-virtual {p3, v0}, La/a/b/a/e;->a(I)V

    add-int/lit8 v7, v1, 0x1

    new-instance v10, La/d/e;

    const/4 v11, 0x0

    invoke-virtual {p2, v0, v11}, La/a/b/a/a/x;->a(ILjava/lang/String;)La/a/b/a/a/s;

    move-result-object v11

    aget-object v0, p1, v8

    iget-object v0, v0, La/d/e;->b:Ljava/lang/Object;

    check-cast v0, La/a/b/a/a/q;

    invoke-direct {v10, v11, v0}, La/d/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    aput-object v10, v6, v1

    add-int/lit8 v1, v8, 0x1

    move v8, v1

    move v1, v7

    goto :goto_6b

    :cond_94
    const/high16 v0, 0xff0000

    and-int/2addr v0, v9

    sparse-switch v0, :sswitch_data_bc

    new-instance v0, La/a/a;

    const-string v1, "Could not decode attr value"

    invoke-direct {v0, v1}, La/a/a;-><init>(Ljava/lang/String;)V

    throw v0

    :sswitch_a2
    new-instance v0, La/a/b/a/a/h;

    move-object v1, p0

    invoke-direct/range {v0 .. v6}, La/a/b/a/a/h;-><init>(La/a/b/a/a/s;ILjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;[La/d/e;)V

    goto :goto_2e

    :sswitch_a9
    new-instance v0, La/a/b/a/a/j;

    move-object v1, p0

    invoke-direct/range {v0 .. v6}, La/a/b/a/a/j;-><init>(La/a/b/a/a/s;ILjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Boolean;[La/d/e;)V

    goto/16 :goto_2e

    nop

    :pswitch_data_b2
    .packed-switch 0x1000001
        :pswitch_2f  #01000001
        :pswitch_41  #01000002
        :pswitch_50  #01000003
    .end packed-switch

    :sswitch_data_bc
    .sparse-switch
        0x10000 -> :sswitch_a2
        0x20000 -> :sswitch_a9
    .end sparse-switch
.end method


# virtual methods
.method public a(La/a/b/a/a/t;)Ljava/lang/String;
    .registers 3

    const/4 v0, 0x0

    return-object v0
.end method

.method protected a(Lorg/xmlpull/v1/XmlSerializer;)V
    .registers 2

    return-void
.end method

.method public final a(Lorg/xmlpull/v1/XmlSerializer;La/a/b/a/g;)V
    .registers 7

    const/4 v1, 0x0

    const-string v0, ""

    iget v2, p0, La/a/b/a/a/b;->b:I

    and-int/lit8 v2, v2, 0x1

    if-eqz v2, :cond_1c

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "|reference"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_1c
    iget v2, p0, La/a/b/a/a/b;->b:I

    and-int/lit8 v2, v2, 0x2

    if-eqz v2, :cond_35

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "|string"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_35
    iget v2, p0, La/a/b/a/a/b;->b:I

    and-int/lit8 v2, v2, 0x4

    if-eqz v2, :cond_4e

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "|integer"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_4e
    iget v2, p0, La/a/b/a/a/b;->b:I

    and-int/lit8 v2, v2, 0x8

    if-eqz v2, :cond_67

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "|boolean"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_67
    iget v2, p0, La/a/b/a/a/b;->b:I

    and-int/lit8 v2, v2, 0x10

    if-eqz v2, :cond_80

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "|color"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_80
    iget v2, p0, La/a/b/a/a/b;->b:I

    and-int/lit8 v2, v2, 0x20

    if-eqz v2, :cond_99

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "|float"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_99
    iget v2, p0, La/a/b/a/a/b;->b:I

    and-int/lit8 v2, v2, 0x40

    if-eqz v2, :cond_b2

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "|dimension"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_b2
    iget v2, p0, La/a/b/a/a/b;->b:I

    and-int/lit16 v2, v2, 0x80

    if-eqz v2, :cond_cb

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "|fraction"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_cb
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_125

    move-object v0, v1

    :goto_d2
    const-string v2, "attr"

    invoke-interface {p1, v1, v2}, Lorg/xmlpull/v1/XmlSerializer;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    const-string v2, "name"

    invoke-virtual {p2}, La/a/b/a/g;->c()La/a/b/a/f;

    move-result-object v3

    invoke-virtual {v3}, La/a/b/a/f;->f()Ljava/lang/String;

    move-result-object v3

    invoke-interface {p1, v1, v2, v3}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    if-eqz v0, :cond_eb

    const-string v2, "format"

    invoke-interface {p1, v1, v2, v0}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    :cond_eb
    iget-object v0, p0, La/a/b/a/a/b;->c:Ljava/lang/Integer;

    if-eqz v0, :cond_fa

    const-string v0, "min"

    iget-object v2, p0, La/a/b/a/a/b;->c:Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {p1, v1, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    :cond_fa
    iget-object v0, p0, La/a/b/a/a/b;->d:Ljava/lang/Integer;

    if-eqz v0, :cond_109

    const-string v0, "max"

    iget-object v2, p0, La/a/b/a/a/b;->d:Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {p1, v1, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    :cond_109
    iget-object v0, p0, La/a/b/a/a/b;->e:Ljava/lang/Boolean;

    if-eqz v0, :cond_11c

    iget-object v0, p0, La/a/b/a/a/b;->e:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_11c

    const-string v0, "localization"

    const-string v2, "suggested"

    invoke-interface {p1, v1, v0, v2}, Lorg/xmlpull/v1/XmlSerializer;->attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    :cond_11c
    invoke-virtual {p0, p1}, La/a/b/a/a/b;->a(Lorg/xmlpull/v1/XmlSerializer;)V

    const-string v0, "attr"

    invoke-interface {p1, v1, v0}, Lorg/xmlpull/v1/XmlSerializer;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    return-void

    :cond_125
    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_d2
.end method
