.class public final La/a/b/a/a/d;
.super La/a/b/a/a/t;


# instance fields
.field private final a:Z


# direct methods
.method public constructor <init>(ZILjava/lang/String;)V
    .registers 5

    const-string v0, "bool"

    invoke-direct {p0, v0, p2, p3}, La/a/b/a/a/t;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    iput-boolean p1, p0, La/a/b/a/a/d;->a:Z

    return-void
.end method


# virtual methods
.method protected final a()Ljava/lang/String;
    .registers 2

    iget-boolean v0, p0, La/a/b/a/a/d;->a:Z

    if-eqz v0, :cond_7

    const-string v0, "true"

    :goto_6
    return-object v0

    :cond_7
    const-string v0, "false"

    goto :goto_6
.end method
