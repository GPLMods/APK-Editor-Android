.class public final La/a/b/a/a/m;
.super La/a/b/a/a/t;


# instance fields
.field private final a:F


# direct methods
.method public constructor <init>(FILjava/lang/String;)V
    .registers 5

    const-string v0, "float"

    invoke-direct {p0, v0, p2, p3}, La/a/b/a/a/t;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    iput p1, p0, La/a/b/a/a/m;->a:F

    return-void
.end method


# virtual methods
.method protected final a()Ljava/lang/String;
    .registers 2

    iget v0, p0, La/a/b/a/a/m;->a:F

    invoke-static {v0}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
