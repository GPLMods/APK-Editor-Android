.class public final La/a/b/c/a;
.super Ljava/io/File;


# instance fields
.field private a:La/c/d;


# direct methods
.method public constructor <init>(Ljava/io/File;)V
    .registers 3

    invoke-virtual {p1}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final a()La/c/d;
    .registers 2

    iget-object v0, p0, La/a/b/c/a;->a:La/c/d;

    if-nez v0, :cond_11

    invoke-virtual {p0}, La/a/b/c/a;->isDirectory()Z

    move-result v0

    if-eqz v0, :cond_14

    new-instance v0, La/c/f;

    invoke-direct {v0, p0}, La/c/f;-><init>(Ljava/io/File;)V

    iput-object v0, p0, La/a/b/c/a;->a:La/c/d;

    :cond_11
    :goto_11
    iget-object v0, p0, La/a/b/c/a;->a:La/c/d;

    return-object v0

    :cond_14
    new-instance v0, La/c/i;

    invoke-direct {v0, p0}, La/c/i;-><init>(Ljava/io/File;)V

    iput-object v0, p0, La/a/b/c/a;->a:La/c/d;

    goto :goto_11
.end method
