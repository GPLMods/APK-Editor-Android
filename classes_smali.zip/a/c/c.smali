.class final La/c/c;
.super Ljava/lang/Object;


# instance fields
.field public a:La/c/a;

.field public b:Ljava/lang/String;


# direct methods
.method public constructor <init>(La/c/a;La/c/a;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, La/c/c;->a:La/c/a;

    iput-object p3, p0, La/c/c;->b:Ljava/lang/String;

    return-void
.end method
