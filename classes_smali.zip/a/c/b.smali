.class final La/c/b;
.super Ljava/lang/Object;


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;


# direct methods
.method public constructor <init>(La/c/a;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, La/c/b;->a:Ljava/lang/String;

    iput-object p3, p0, La/c/b;->b:Ljava/lang/String;

    return-void
.end method
