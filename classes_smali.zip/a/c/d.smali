.class public interface abstract La/c/d;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Z)Ljava/util/Set;
.end method

.method public abstract a(Ljava/io/File;)V
.end method

.method public abstract a(Ljava/io/File;Ljava/lang/String;)V
.end method

.method public abstract a(Ljava/lang/String;)Z
.end method

.method public abstract b(Ljava/lang/String;)Ljava/io/InputStream;
.end method

.method public abstract c(Ljava/lang/String;)Ljava/io/OutputStream;
.end method

.method public abstract d(Ljava/lang/String;)La/c/d;
.end method

.method public abstract e(Ljava/lang/String;)Z
.end method

.method public abstract getCompressionLevel(Ljava/lang/String;)I
.end method

.method public abstract getSize(Ljava/lang/String;)J
.end method
