.class public abstract La/c/a;
.super Ljava/lang/Object;

# interfaces
.implements La/c/d;


# instance fields
.field protected a:Ljava/util/Set;

.field protected b:Ljava/util/Map;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private b(Z)Ljava/util/Map;
    .registers 9

    iget-object v0, p0, La/c/a;->b:Ljava/util/Map;

    if-nez v0, :cond_7

    invoke-virtual {p0}, La/c/a;->b()V

    :cond_7
    if-nez p1, :cond_c

    iget-object v0, p0, La/c/a;->b:Ljava/util/Map;

    :goto_b
    return-object v0

    :cond_c
    new-instance v3, Ljava/util/LinkedHashMap;

    iget-object v0, p0, La/c/a;->b:Ljava/util/Map;

    invoke-direct {v3, v0}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V

    invoke-direct {p0}, La/c/a;->c()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_1f
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_75

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/c/a;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, La/c/a;->b(Z)Ljava/util/Map;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_3e
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1f

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const/16 v6, 0x2f

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    invoke-interface {v3, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_3e

    :cond_75
    move-object v0, v3

    goto :goto_b
.end method

.method private c()Ljava/util/Map;
    .registers 2

    const/4 v0, 0x0

    invoke-direct {p0, v0}, La/c/a;->b(Z)Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method

.method private j(Ljava/lang/String;)La/c/d;
    .registers 7

    const/4 v4, 0x0

    :goto_1
    invoke-direct {p0, p1}, La/c/a;->l(Ljava/lang/String;)La/c/b;

    move-result-object v1

    iget-object v0, v1, La/c/b;->a:Ljava/lang/String;

    if-nez v0, :cond_2b

    invoke-direct {p0, v4}, La/c/a;->b(Z)Ljava/util/Map;

    move-result-object v0

    iget-object v2, v1, La/c/b;->b:Ljava/lang/String;

    invoke-interface {v0, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1b

    new-instance v0, La/c/g;

    invoke-direct {v0, p1}, La/c/g;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1b
    iget-object v0, v1, La/c/b;->b:Ljava/lang/String;

    invoke-virtual {p0, v0}, La/c/a;->h(Ljava/lang/String;)La/c/a;

    move-result-object v0

    invoke-direct {p0, v4}, La/c/a;->b(Z)Ljava/util/Map;

    move-result-object v2

    iget-object v1, v1, La/c/b;->b:Ljava/lang/String;

    invoke-interface {v2, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-object v0

    :cond_2b
    invoke-direct {p0, v4}, La/c/a;->b(Z)Ljava/util/Map;

    move-result-object v0

    iget-object v2, v1, La/c/b;->a:Ljava/lang/String;

    invoke-interface {v0, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_47

    invoke-direct {p0, v4}, La/c/a;->b(Z)Ljava/util/Map;

    move-result-object v0

    iget-object v2, v1, La/c/b;->a:Ljava/lang/String;

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/c/a;

    move-object p0, v0

    :goto_44
    iget-object p1, v1, La/c/b;->b:Ljava/lang/String;

    goto :goto_1

    :cond_47
    iget-object v0, v1, La/c/b;->a:Ljava/lang/String;

    invoke-virtual {p0, v0}, La/c/a;->h(Ljava/lang/String;)La/c/a;

    move-result-object v0

    invoke-direct {p0, v4}, La/c/a;->b(Z)Ljava/util/Map;

    move-result-object v2

    iget-object v3, v1, La/c/b;->a:Ljava/lang/String;

    invoke-interface {v2, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object p0, v0

    goto :goto_44
.end method

.method private k(Ljava/lang/String;)La/c/c;
    .registers 6

    invoke-direct {p0, p1}, La/c/a;->l(Ljava/lang/String;)La/c/b;

    move-result-object v2

    iget-object v0, v2, La/c/b;->a:Ljava/lang/String;

    if-nez v0, :cond_11

    new-instance v0, La/c/c;

    const/4 v1, 0x0

    iget-object v2, v2, La/c/b;->b:Ljava/lang/String;

    invoke-direct {v0, p0, v1, v2}, La/c/c;-><init>(La/c/a;La/c/a;Ljava/lang/String;)V

    :goto_10
    return-object v0

    :cond_11
    const/4 v0, 0x0

    invoke-direct {p0, v0}, La/c/a;->b(Z)Ljava/util/Map;

    move-result-object v0

    iget-object v1, v2, La/c/b;->a:Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_24

    new-instance v0, La/c/h;

    invoke-direct {v0, p1}, La/c/h;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_24
    new-instance v1, La/c/c;

    invoke-direct {p0}, La/c/a;->c()Ljava/util/Map;

    move-result-object v0

    iget-object v3, v2, La/c/b;->a:Ljava/lang/String;

    invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/c/a;

    iget-object v2, v2, La/c/b;->b:Ljava/lang/String;

    invoke-direct {v1, p0, v0, v2}, La/c/c;-><init>(La/c/a;La/c/a;Ljava/lang/String;)V

    move-object v0, v1

    goto :goto_10
.end method

.method private l(Ljava/lang/String;)La/c/b;
    .registers 5

    const/16 v0, 0x2f

    invoke-virtual {p1, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v1

    const/4 v0, -0x1

    if-ne v1, v0, :cond_10

    new-instance v0, La/c/b;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1, p1}, La/c/b;-><init>(La/c/a;Ljava/lang/String;Ljava/lang/String;)V

    :goto_f
    return-object v0

    :cond_10
    new-instance v0, La/c/b;

    const/4 v2, 0x0

    invoke-virtual {p1, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    add-int/lit8 v1, v1, 0x1

    invoke-virtual {p1, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, p0, v2, v1}, La/c/b;-><init>(La/c/a;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_f
.end method


# virtual methods
.method public final a(Z)Ljava/util/Set;
    .registers 9

    iget-object v0, p0, La/c/a;->a:Ljava/util/Set;

    if-nez v0, :cond_7

    invoke-virtual {p0}, La/c/a;->a()V

    :cond_7
    if-nez p1, :cond_c

    iget-object v0, p0, La/c/a;->a:Ljava/util/Set;

    :goto_b
    return-object v0

    :cond_c
    new-instance v3, Ljava/util/LinkedHashSet;

    iget-object v0, p0, La/c/a;->a:Ljava/util/Set;

    invoke-direct {v3, v0}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    invoke-direct {p0}, La/c/a;->c()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_1f
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_67

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/c/d;

    const/4 v2, 0x1

    invoke-interface {v1, v2}, La/c/d;->a(Z)Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_3a
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1f

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const/16 v6, 0x2f

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v3, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_3a

    :cond_67
    move-object v0, v3

    goto :goto_b
.end method

.method protected abstract a()V
.end method

.method public final a(Ljava/io/File;)V
    .registers 4

    const/4 v0, 0x1

    invoke-interface {p0, v0}, La/c/d;->a(Z)Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_9
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_19

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {p0, p1, v0}, Lcom/gmail/heagoo/a/c/a;->a(La/c/d;Ljava/io/File;Ljava/lang/String;)V

    goto :goto_9

    :cond_19
    return-void
.end method

.method public final a(Ljava/io/File;Ljava/lang/String;)V
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/gmail/heagoo/a/c/a;->a(La/c/d;Ljava/io/File;Ljava/lang/String;)V

    return-void
.end method

.method public final a(Ljava/lang/String;)Z
    .registers 5

    const/4 v0, 0x0

    :goto_1
    :try_start_1
    invoke-direct {p0, p1}, La/c/a;->k(Ljava/lang/String;)La/c/c;
    :try_end_4
    .catch La/c/h; {:try_start_1 .. :try_end_4} :catch_19

    move-result-object v1

    iget-object v2, v1, La/c/c;->a:La/c/a;

    if-eqz v2, :cond_e

    iget-object p0, v1, La/c/c;->a:La/c/a;

    iget-object p1, v1, La/c/c;->b:Ljava/lang/String;

    goto :goto_1

    :cond_e
    invoke-direct {p0, v0}, La/c/a;->b(Z)Ljava/util/Map;

    move-result-object v0

    iget-object v1, v1, La/c/c;->b:Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    :goto_18
    return v0

    :catch_19
    move-exception v1

    goto :goto_18
.end method

.method public final b(Ljava/lang/String;)Ljava/io/InputStream;
    .registers 5

    :goto_0
    invoke-direct {p0, p1}, La/c/a;->k(Ljava/lang/String;)La/c/c;

    move-result-object v0

    iget-object v1, v0, La/c/c;->a:La/c/a;

    if-eqz v1, :cond_d

    iget-object p0, v0, La/c/c;->a:La/c/a;

    iget-object p1, v0, La/c/c;->b:Ljava/lang/String;

    goto :goto_0

    :cond_d
    const/4 v1, 0x0

    invoke-virtual {p0, v1}, La/c/a;->a(Z)Ljava/util/Set;

    move-result-object v1

    iget-object v2, v0, La/c/c;->b:Ljava/lang/String;

    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_20

    new-instance v0, La/c/h;

    invoke-direct {v0, p1}, La/c/h;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_20
    iget-object v0, v0, La/c/c;->b:Ljava/lang/String;

    invoke-virtual {p0, v0}, La/c/a;->f(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    return-object v0
.end method

.method protected abstract b()V
.end method

.method public final c(Ljava/lang/String;)Ljava/io/OutputStream;
    .registers 5

    const/4 v2, 0x0

    invoke-direct {p0, p1}, La/c/a;->l(Ljava/lang/String;)La/c/b;

    move-result-object v1

    iget-object v0, v1, La/c/b;->a:Ljava/lang/String;

    if-nez v0, :cond_19

    invoke-virtual {p0, v2}, La/c/a;->a(Z)Ljava/util/Set;

    move-result-object v0

    iget-object v2, v1, La/c/b;->b:Ljava/lang/String;

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    iget-object v0, v1, La/c/b;->b:Ljava/lang/String;

    invoke-virtual {p0, v0}, La/c/a;->g(Ljava/lang/String;)Ljava/io/OutputStream;

    move-result-object v0

    :goto_18
    return-object v0

    :cond_19
    :try_start_19
    iget-object v0, v1, La/c/b;->a:Ljava/lang/String;

    invoke-direct {p0, v0}, La/c/a;->j(Ljava/lang/String;)La/c/d;
    :try_end_1e
    .catch La/c/g; {:try_start_19 .. :try_end_1e} :catch_26

    move-result-object v0

    :goto_1f
    iget-object v1, v1, La/c/b;->b:Ljava/lang/String;

    invoke-interface {v0, v1}, La/c/d;->c(Ljava/lang/String;)Ljava/io/OutputStream;

    move-result-object v0

    goto :goto_18

    :catch_26
    move-exception v0

    invoke-direct {p0, v2}, La/c/a;->b(Z)Ljava/util/Map;

    move-result-object v0

    iget-object v2, v1, La/c/b;->a:Ljava/lang/String;

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/c/d;

    goto :goto_1f
.end method

.method public final d(Ljava/lang/String;)La/c/d;
    .registers 6

    const/4 v3, 0x0

    :goto_1
    invoke-direct {p0, p1}, La/c/a;->k(Ljava/lang/String;)La/c/c;

    move-result-object v0

    iget-object v1, v0, La/c/c;->a:La/c/a;

    if-eqz v1, :cond_e

    iget-object p0, v0, La/c/c;->a:La/c/a;

    iget-object p1, v0, La/c/c;->b:Ljava/lang/String;

    goto :goto_1

    :cond_e
    invoke-direct {p0, v3}, La/c/a;->b(Z)Ljava/util/Map;

    move-result-object v1

    iget-object v2, v0, La/c/c;->b:Ljava/lang/String;

    invoke-interface {v1, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_20

    new-instance v0, La/c/h;

    invoke-direct {v0, p1}, La/c/h;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_20
    invoke-direct {p0, v3}, La/c/a;->b(Z)Ljava/util/Map;

    move-result-object v1

    iget-object v0, v0, La/c/c;->b:Ljava/lang/String;

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/c/d;

    return-object v0
.end method

.method public final e(Ljava/lang/String;)Z
    .registers 6

    const/4 v0, 0x0

    :goto_1
    :try_start_1
    invoke-direct {p0, p1}, La/c/a;->k(Ljava/lang/String;)La/c/c;
    :try_end_4
    .catch La/c/h; {:try_start_1 .. :try_end_4} :catch_2b

    move-result-object v1

    iget-object v2, v1, La/c/c;->a:La/c/a;

    if-eqz v2, :cond_e

    iget-object p0, v1, La/c/c;->a:La/c/a;

    iget-object p1, v1, La/c/c;->b:Ljava/lang/String;

    goto :goto_1

    :cond_e
    invoke-virtual {p0, v0}, La/c/a;->a(Z)Ljava/util/Set;

    move-result-object v2

    iget-object v3, v1, La/c/c;->b:Ljava/lang/String;

    invoke-interface {v2, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1b

    :goto_1a
    return v0

    :cond_1b
    iget-object v2, v1, La/c/c;->b:Ljava/lang/String;

    invoke-virtual {p0, v2}, La/c/a;->i(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, La/c/a;->a(Z)Ljava/util/Set;

    move-result-object v0

    iget-object v1, v1, La/c/c;->b:Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    const/4 v0, 0x1

    goto :goto_1a

    :catch_2b
    move-exception v1

    goto :goto_1a
.end method

.method protected abstract f(Ljava/lang/String;)Ljava/io/InputStream;
.end method

.method protected abstract g(Ljava/lang/String;)Ljava/io/OutputStream;
.end method

.method protected abstract h(Ljava/lang/String;)La/c/a;
.end method

.method protected abstract i(Ljava/lang/String;)V
.end method
