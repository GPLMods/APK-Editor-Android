.class public final La/c/g;
.super La/c/e;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, La/c/e;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, La/c/e;-><init>(Ljava/lang/String;)V

    return-void
.end method
