.class final synthetic La/d/b;
.super Ljava/lang/Object;


# static fields
.field static final synthetic a:[I


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/4 v0, 0x5

    invoke-static {}, La/d/c;->a()[I

    new-array v0, v0, [I

    sput-object v0, La/d/b;->a:[I

    :try_start_8
    sget-object v0, La/d/b;->a:[I

    sget v1, La/d/c;->a:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_10
    .catch Ljava/lang/NoSuchFieldError; {:try_start_8 .. :try_end_10} :catch_39

    :goto_10
    :try_start_10
    sget-object v0, La/d/b;->a:[I

    sget v1, La/d/c;->b:I

    const/4 v1, 0x1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_18
    .catch Ljava/lang/NoSuchFieldError; {:try_start_10 .. :try_end_18} :catch_37

    :goto_18
    :try_start_18
    sget-object v0, La/d/b;->a:[I

    sget v1, La/d/c;->c:I

    const/4 v1, 0x2

    const/4 v2, 0x3

    aput v2, v0, v1
    :try_end_20
    .catch Ljava/lang/NoSuchFieldError; {:try_start_18 .. :try_end_20} :catch_35

    :goto_20
    :try_start_20
    sget-object v0, La/d/b;->a:[I

    sget v1, La/d/c;->d:I

    const/4 v1, 0x3

    const/4 v2, 0x4

    aput v2, v0, v1
    :try_end_28
    .catch Ljava/lang/NoSuchFieldError; {:try_start_20 .. :try_end_28} :catch_33

    :goto_28
    :try_start_28
    sget-object v0, La/d/b;->a:[I

    sget v1, La/d/c;->e:I

    const/4 v1, 0x4

    const/4 v2, 0x5

    aput v2, v0, v1
    :try_end_30
    .catch Ljava/lang/NoSuchFieldError; {:try_start_28 .. :try_end_30} :catch_31

    :goto_30
    return-void

    :catch_31
    move-exception v0

    goto :goto_30

    :catch_33
    move-exception v0

    goto :goto_28

    :catch_35
    move-exception v0

    goto :goto_20

    :catch_37
    move-exception v0

    goto :goto_18

    :catch_39
    move-exception v0

    goto :goto_10
.end method
