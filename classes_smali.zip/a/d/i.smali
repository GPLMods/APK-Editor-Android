.class public final La/d/i;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/util/LinkedHashMap;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    sput-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-aa"

    const-string v2, "Afar"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ab"

    const-string v2, "Abkhazian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-af"

    const-string v2, "Afrikaans"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ak"

    const-string v2, "Akan"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-sq"

    const-string v2, "Albanian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-am"

    const-string v2, "Amharic"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ar"

    const-string v2, "Arabic"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-an"

    const-string v2, "Aragonese"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-hy"

    const-string v2, "Armenian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-as"

    const-string v2, "Assamese"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-av"

    const-string v2, "Avaric"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ae"

    const-string v2, "Avestan"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ay"

    const-string v2, "Aymara"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-az"

    const-string v2, "Azerbaijani"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ba"

    const-string v2, "Bashkir"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-bm"

    const-string v2, "Bambara"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-eu"

    const-string v2, "Basque"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-be"

    const-string v2, "Belarusian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-bn"

    const-string v2, "Bengali"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-bh"

    const-string v2, "Bihari languages+B372"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-bi"

    const-string v2, "Bislama"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-bo"

    const-string v2, "Tibetan"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-bs"

    const-string v2, "Bosnian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-br"

    const-string v2, "Breton"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-bg"

    const-string v2, "Bulgarian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-my"

    const-string v2, "Burmese"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ca"

    const-string v2, "Catalan; Valencian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-cs"

    const-string v2, "Czech"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ch"

    const-string v2, "Chamorro"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ce"

    const-string v2, "Chechen"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-zh"

    const-string v2, "Chinese"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "cu"

    const-string v2, "Church Slavic; Old Slavonic; Church Slavonic; Old Bulgarian; Old Church Slavonic"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-cv"

    const-string v2, "Chuvash"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-kw"

    const-string v2, "Cornish"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-co"

    const-string v2, "Corsican"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-cr"

    const-string v2, "Cree"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-cy"

    const-string v2, "Welsh"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-cs"

    const-string v2, "Czech"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-da"

    const-string v2, "Danish"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-de"

    const-string v2, "German"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-dv"

    const-string v2, "Divehi; Dhivehi; Maldivian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-nl"

    const-string v2, "Dutch; Flemish"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-dz"

    const-string v2, "Dzongkha"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-el"

    const-string v2, "Greek, Modern (1453-)"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-en"

    const-string v2, "English"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-eo"

    const-string v2, "Esperanto"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-et"

    const-string v2, "Estonian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-eu"

    const-string v2, "Basque"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ee"

    const-string v2, "Ewe"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-fo"

    const-string v2, "Faroese"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-fa"

    const-string v2, "Persian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-fj"

    const-string v2, "Fijian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-fi"

    const-string v2, "Finnish"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-fr"

    const-string v2, "French"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-fy"

    const-string v2, "Western Frisian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ff"

    const-string v2, "Fulah"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ka"

    const-string v2, "Georgian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-de"

    const-string v2, "German"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-gd"

    const-string v2, "Gaelic; Scottish Gaelic"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ga"

    const-string v2, "Irish"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-gl"

    const-string v2, "Galician"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-gv"

    const-string v2, "Manx"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-el"

    const-string v2, "Greek, Modern"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-gn"

    const-string v2, "Guarani"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-gu"

    const-string v2, "Gujarati"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ht"

    const-string v2, "Haitian; Haitian Creole"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ha"

    const-string v2, "Hausa"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-iw"

    const-string v2, "Hebrew"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-he"

    const-string v2, "Hebrew"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-hz"

    const-string v2, "Herero"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-hi"

    const-string v2, "Hindi"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ho"

    const-string v2, "Hiri Motu"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-hr"

    const-string v2, "Croatian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-hu"

    const-string v2, "Hungarian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-hy"

    const-string v2, "Armenian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ig"

    const-string v2, "Igbo"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-is"

    const-string v2, "Icelandic"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-io"

    const-string v2, "Ido"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ii"

    const-string v2, "Sichuan Yi; Nuosu"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-iu"

    const-string v2, "Inuktitut"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ie"

    const-string v2, "Interlingue; Occidental"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ia"

    const-string v2, "Interlingua (International Auxiliary Language Association)"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-in"

    const-string v2, "Indonesian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-id"

    const-string v2, "Indonesian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ik"

    const-string v2, "Inupiaq"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-is"

    const-string v2, "Icelandic"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-it"

    const-string v2, "Italian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-jv"

    const-string v2, "Javanese"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ja"

    const-string v2, "Japanese"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-kl"

    const-string v2, "Kalaallisut; Greenlandic"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-kn"

    const-string v2, "Kannada"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ks"

    const-string v2, "Kashmiri"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ka"

    const-string v2, "Georgian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-kr"

    const-string v2, "Kanuri"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-kk"

    const-string v2, "Kazakh"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-km"

    const-string v2, "Central Khmer"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ki"

    const-string v2, "Kikuyu; Gikuyu"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-rw"

    const-string v2, "Kinyarwanda"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ky"

    const-string v2, "Kirghiz; Kyrgyz"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-kv"

    const-string v2, "Komi"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-kg"

    const-string v2, "Kongo"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ko"

    const-string v2, "Korean"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-kj"

    const-string v2, "Kuanyama; Kwanyama"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ku"

    const-string v2, "Kurdish"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-lo"

    const-string v2, "Lao"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-la"

    const-string v2, "Latin"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-lv"

    const-string v2, "Latvian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-li"

    const-string v2, "Limburgan; Limburger; Limburgish"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ln"

    const-string v2, "Lingala"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-lt"

    const-string v2, "Lithuanian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-lb"

    const-string v2, "Luxembourgish; Letzeburgesch"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-lu"

    const-string v2, "Luba-Katanga"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-lg"

    const-string v2, "Ganda"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-mk"

    const-string v2, "Macedonian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-mh"

    const-string v2, "Marshallese"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ml"

    const-string v2, "Malayalam"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-mi"

    const-string v2, "Maori"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-mr"

    const-string v2, "Marathi"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ms"

    const-string v2, "Malay"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-mk"

    const-string v2, "Macedonian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-mg"

    const-string v2, "Malagasy"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-mt"

    const-string v2, "Maltese"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-mn"

    const-string v2, "Mongolian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-mi"

    const-string v2, "Maori"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ms"

    const-string v2, "Malay"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-my"

    const-string v2, "Burmese"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-na"

    const-string v2, "Nauru"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-nv"

    const-string v2, "Navajo; Navaho"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-nr"

    const-string v2, "Ndebele, South; South Ndebele"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-nd"

    const-string v2, "Ndebele, North; North Ndebele"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ng"

    const-string v2, "Ndonga"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ne"

    const-string v2, "Nepali"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-nl"

    const-string v2, "Dutch; Flemish"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-nn"

    const-string v2, "Norwegian Nynorsk; Nynorsk, Norwegian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-nb"

    const-string v2, "Bokmål, Norwegian; Norwegian Bokmål"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-no"

    const-string v2, "Norwegian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ny"

    const-string v2, "Chichewa; Chewa; Nyanja"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-oc"

    const-string v2, "Occitan (post 1500)"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-oj"

    const-string v2, "Ojibwa"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-or"

    const-string v2, "Oriya"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-om"

    const-string v2, "Oromo"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-os"

    const-string v2, "Ossetian; Ossetic"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-pa"

    const-string v2, "Panjabi; Punjabi"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-fa"

    const-string v2, "Persian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-pi"

    const-string v2, "Pali"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-pl"

    const-string v2, "Polish"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-pt"

    const-string v2, "Portuguese"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ps"

    const-string v2, "Pushto; Pashto"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-qu"

    const-string v2, "Quechua"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-rm"

    const-string v2, "Romansh"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ro"

    const-string v2, "Romanian; Moldavian; Moldovan"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ro"

    const-string v2, "Romanian; Moldavian; Moldovan"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-rn"

    const-string v2, "Rundi"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ru"

    const-string v2, "Russian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-sg"

    const-string v2, "Sango"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-sa"

    const-string v2, "Sanskrit"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-si"

    const-string v2, "Sinhala; Sinhalese"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-sk"

    const-string v2, "Slovak"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-sk"

    const-string v2, "Slovak"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-sl"

    const-string v2, "Slovenian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-se"

    const-string v2, "Northern Sami"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-sm"

    const-string v2, "Samoan"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-sn"

    const-string v2, "Shona"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-sd"

    const-string v2, "Sindhi"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-so"

    const-string v2, "Somali"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-st"

    const-string v2, "Sotho, Southern"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-es"

    const-string v2, "Spanish; Castilian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-sq"

    const-string v2, "Albanian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-sc"

    const-string v2, "Sardinian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-sr"

    const-string v2, "Serbian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ss"

    const-string v2, "Swati"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-su"

    const-string v2, "Sundanese"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-sw"

    const-string v2, "Swahili"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-sv"

    const-string v2, "Swedish"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ty"

    const-string v2, "Tahitian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ta"

    const-string v2, "Tamil"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-tt"

    const-string v2, "Tatar"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-te"

    const-string v2, "Telugu"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-tg"

    const-string v2, "Tajik"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-tl"

    const-string v2, "Tagalog"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-th"

    const-string v2, "Thai"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-bo"

    const-string v2, "Tibetan"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ti"

    const-string v2, "Tigrinya"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-to"

    const-string v2, "Tonga (Tonga Islands)"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-tn"

    const-string v2, "Tswana"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ts"

    const-string v2, "Tsonga"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-tk"

    const-string v2, "Turkmen"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-tr"

    const-string v2, "Turkish"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-tw"

    const-string v2, "Twi"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ug"

    const-string v2, "Uighur; Uyghur"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-uk"

    const-string v2, "Ukrainian"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ur"

    const-string v2, "Urdu"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-uz"

    const-string v2, "Uzbek"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ve"

    const-string v2, "Venda"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-vi"

    const-string v2, "Vietnamese"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-vo"

    const-string v2, "Volapük"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-cy"

    const-string v2, "Welsh"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-wa"

    const-string v2, "Walloon"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-wo"

    const-string v2, "Wolof"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-xh"

    const-string v2, "Xhosa"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-ji"

    const-string v2, "Yiddish"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-yi"

    const-string v2, "Yiddish"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-yo"

    const-string v2, "Yoruba"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-za"

    const-string v2, "Zhuang; Chuang"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-zh"

    const-string v2, "Chinese"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    const-string v1, "-zu"

    const-string v2, "Zulu"

    invoke-virtual {v0, v1, v2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static a()I
    .registers 1

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->size()I

    move-result v0

    return v0
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    const-string v0, ""

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    const-string v0, "[ Default ]"

    :goto_a
    return-object v0

    :cond_b
    const/16 v0, 0x2d

    const/4 v1, 0x1

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->indexOf(II)I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_58

    const/4 v1, 0x0

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    :goto_1a
    sget-object v1, La/d/i;->a:Ljava/util/LinkedHashMap;

    invoke-virtual {v1, v0}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-eqz v0, :cond_42

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " ("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_a

    :cond_42
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, " ("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_a

    :cond_58
    move-object v0, p0

    goto :goto_1a
.end method

.method public static a([Ljava/lang/String;[Ljava/lang/String;)V
    .registers 6

    sget-object v0, La/d/i;->a:Ljava/util/LinkedHashMap;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v0, 0x0

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    move v2, v0

    :goto_c
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2c

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    aput-object v1, p0, v2

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    aput-object v0, p1, v2

    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_c

    :cond_2c
    return-void
.end method
