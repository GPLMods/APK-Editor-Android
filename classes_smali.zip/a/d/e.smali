.class public final La/d/e;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public final a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/d/e;->a:Ljava/lang/Object;

    iput-object p2, p0, La/d/e;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    const/4 v0, 0x0

    if-nez p1, :cond_4

    :cond_3
    :goto_3
    return v0

    :cond_4
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    if-ne v1, v2, :cond_3

    check-cast p1, La/d/e;

    iget-object v1, p0, La/d/e;->a:Ljava/lang/Object;

    iget-object v2, p1, La/d/e;->a:Ljava/lang/Object;

    if-eq v1, v2, :cond_24

    iget-object v1, p0, La/d/e;->a:Ljava/lang/Object;

    if-eqz v1, :cond_3

    iget-object v1, p0, La/d/e;->a:Ljava/lang/Object;

    iget-object v2, p1, La/d/e;->a:Ljava/lang/Object;

    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    :cond_24
    iget-object v1, p0, La/d/e;->b:Ljava/lang/Object;

    iget-object v2, p1, La/d/e;->b:Ljava/lang/Object;

    if-eq v1, v2, :cond_38

    iget-object v1, p0, La/d/e;->b:Ljava/lang/Object;

    if-eqz v1, :cond_3

    iget-object v1, p0, La/d/e;->b:Ljava/lang/Object;

    iget-object v2, p1, La/d/e;->b:Ljava/lang/Object;

    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    :cond_38
    const/4 v0, 0x1

    goto :goto_3
.end method

.method public final hashCode()I
    .registers 4

    const/4 v1, 0x0

    iget-object v0, p0, La/d/e;->a:Ljava/lang/Object;

    if-eqz v0, :cond_1b

    iget-object v0, p0, La/d/e;->a:Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    :goto_b
    add-int/lit16 v0, v0, 0xd5

    mul-int/lit8 v0, v0, 0x47

    iget-object v2, p0, La/d/e;->b:Ljava/lang/Object;

    if-eqz v2, :cond_19

    iget-object v1, p0, La/d/e;->b:Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :cond_19
    add-int/2addr v0, v1

    return v0

    :cond_1b
    move v0, v1

    goto :goto_b
.end method
