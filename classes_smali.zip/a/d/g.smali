.class public final La/d/g;
.super Ljava/lang/Object;

# interfaces
.implements Lorg/xmlpull/v1/XmlSerializer;


# static fields
.field private static final a:[Ljava/lang/String;


# instance fields
.field private final b:[C

.field private c:I

.field private d:Ljava/io/Writer;

.field private e:Ljava/io/OutputStream;

.field private f:Ljava/nio/charset/CharsetEncoder;

.field private g:Ljava/nio/ByteBuffer;

.field private h:Z

.field private i:I

.field private j:La/d/j;

.field private k:Z

.field private l:Z

.field private tab:Z


# direct methods
.method static constructor <clinit>()V
    .registers 4

    const/4 v3, 0x0

    const/16 v0, 0x40

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    aput-object v3, v0, v1

    const/4 v1, 0x1

    aput-object v3, v0, v1

    const/4 v1, 0x2

    aput-object v3, v0, v1

    const/4 v1, 0x3

    aput-object v3, v0, v1

    const/4 v1, 0x4

    aput-object v3, v0, v1

    const/4 v1, 0x5

    aput-object v3, v0, v1

    const/4 v1, 0x6

    aput-object v3, v0, v1

    const/4 v1, 0x7

    aput-object v3, v0, v1

    const/16 v1, 0x8

    aput-object v3, v0, v1

    const/16 v1, 0x9

    aput-object v3, v0, v1

    const/16 v1, 0xa

    aput-object v3, v0, v1

    const/16 v1, 0xb

    aput-object v3, v0, v1

    const/16 v1, 0xc

    aput-object v3, v0, v1

    const/16 v1, 0xd

    aput-object v3, v0, v1

    const/16 v1, 0xe

    aput-object v3, v0, v1

    const/16 v1, 0xf

    aput-object v3, v0, v1

    const/16 v1, 0x10

    aput-object v3, v0, v1

    const/16 v1, 0x11

    aput-object v3, v0, v1

    const/16 v1, 0x12

    aput-object v3, v0, v1

    const/16 v1, 0x13

    aput-object v3, v0, v1

    const/16 v1, 0x14

    aput-object v3, v0, v1

    const/16 v1, 0x15

    aput-object v3, v0, v1

    const/16 v1, 0x16

    aput-object v3, v0, v1

    const/16 v1, 0x17

    aput-object v3, v0, v1

    const/16 v1, 0x18

    aput-object v3, v0, v1

    const/16 v1, 0x19

    aput-object v3, v0, v1

    const/16 v1, 0x1a

    aput-object v3, v0, v1

    const/16 v1, 0x1b

    aput-object v3, v0, v1

    const/16 v1, 0x1c

    aput-object v3, v0, v1

    const/16 v1, 0x1d

    aput-object v3, v0, v1

    const/16 v1, 0x1e

    aput-object v3, v0, v1

    const/16 v1, 0x1f

    aput-object v3, v0, v1

    const/16 v1, 0x20

    aput-object v3, v0, v1

    const/16 v1, 0x21

    aput-object v3, v0, v1

    const/16 v1, 0x22

    const-string v2, "&quot;"

    aput-object v2, v0, v1

    const/16 v1, 0x23

    aput-object v3, v0, v1

    const/16 v1, 0x24

    aput-object v3, v0, v1

    const/16 v1, 0x25

    aput-object v3, v0, v1

    const/16 v1, 0x26

    const-string v2, "&amp;"

    aput-object v2, v0, v1

    const/16 v1, 0x27

    aput-object v3, v0, v1

    const/16 v1, 0x28

    aput-object v3, v0, v1

    const/16 v1, 0x29

    aput-object v3, v0, v1

    const/16 v1, 0x2a

    aput-object v3, v0, v1

    const/16 v1, 0x2b

    aput-object v3, v0, v1

    const/16 v1, 0x2c

    aput-object v3, v0, v1

    const/16 v1, 0x2d

    aput-object v3, v0, v1

    const/16 v1, 0x2e

    aput-object v3, v0, v1

    const/16 v1, 0x2f

    aput-object v3, v0, v1

    const/16 v1, 0x30

    aput-object v3, v0, v1

    const/16 v1, 0x31

    aput-object v3, v0, v1

    const/16 v1, 0x32

    aput-object v3, v0, v1

    const/16 v1, 0x33

    aput-object v3, v0, v1

    const/16 v1, 0x34

    aput-object v3, v0, v1

    const/16 v1, 0x35

    aput-object v3, v0, v1

    const/16 v1, 0x36

    aput-object v3, v0, v1

    const/16 v1, 0x37

    aput-object v3, v0, v1

    const/16 v1, 0x38

    aput-object v3, v0, v1

    const/16 v1, 0x39

    aput-object v3, v0, v1

    const/16 v1, 0x3a

    aput-object v3, v0, v1

    const/16 v1, 0x3b

    aput-object v3, v0, v1

    const/16 v1, 0x3c

    const-string v2, "&lt;"

    aput-object v2, v0, v1

    const/16 v1, 0x3d

    aput-object v3, v0, v1

    const/16 v1, 0x3e

    const-string v2, "&gt;"

    aput-object v2, v0, v1

    const/16 v1, 0x3f

    aput-object v3, v0, v1

    sput-object v0, La/d/g;->a:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    const/16 v1, 0x2000

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-array v0, v1, [C

    iput-object v0, p0, La/d/g;->b:[C

    invoke-static {v1}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    iput-object v0, p0, La/d/g;->g:Ljava/nio/ByteBuffer;

    const/4 v0, 0x0

    iput v0, p0, La/d/g;->i:I

    return-void
.end method

.method private a()V
    .registers 5

    iget-object v0, p0, La/d/g;->g:Ljava/nio/ByteBuffer;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->position()I

    move-result v0

    if-lez v0, :cond_1e

    iget-object v1, p0, La/d/g;->g:Ljava/nio/ByteBuffer;

    invoke-virtual {v1}, Ljava/nio/ByteBuffer;->flip()Ljava/nio/Buffer;

    iget-object v1, p0, La/d/g;->e:Ljava/io/OutputStream;

    iget-object v2, p0, La/d/g;->g:Ljava/nio/ByteBuffer;

    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3, v0}, Ljava/io/OutputStream;->write([BII)V

    iget-object v0, p0, La/d/g;->g:Ljava/nio/ByteBuffer;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    :cond_1e
    return-void
.end method

.method private a(C)V
    .registers 4

    iget v0, p0, La/d/g;->c:I

    const/16 v1, 0x1fff

    if-lt v0, v1, :cond_b

    invoke-virtual {p0}, La/d/g;->flush()V

    iget v0, p0, La/d/g;->c:I

    :cond_b
    iget-object v1, p0, La/d/g;->b:[C

    aput-char p1, v1, v0

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/d/g;->c:I

    return-void
.end method

.method private a(Ljava/lang/String;)V
    .registers 4

    const/4 v0, 0x0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    invoke-direct {p0, p1, v0, v1}, La/d/g;->a(Ljava/lang/String;II)V

    return-void
.end method

.method private a(Ljava/lang/String;II)V
    .registers 8

    const/16 v1, 0x2000

    if-le p3, v1, :cond_15

    add-int v3, p2, p3

    :goto_6
    if-ge p2, v3, :cond_2a

    add-int/lit16 v2, p2, 0x2000

    if-ge v2, v3, :cond_12

    move v0, v1

    :goto_d
    invoke-direct {p0, p1, p2, v0}, La/d/g;->a(Ljava/lang/String;II)V

    move p2, v2

    goto :goto_6

    :cond_12
    sub-int v0, v3, p2

    goto :goto_d

    :cond_15
    iget v0, p0, La/d/g;->c:I

    add-int v2, v0, p3

    if-le v2, v1, :cond_20

    invoke-virtual {p0}, La/d/g;->flush()V

    iget v0, p0, La/d/g;->c:I

    :cond_20
    add-int v1, p2, p3

    iget-object v2, p0, La/d/g;->b:[C

    invoke-virtual {p1, p2, v1, v2, v0}, Ljava/lang/String;->getChars(II[CI)V

    add-int/2addr v0, p3

    iput v0, p0, La/d/g;->c:I

    :cond_2a
    return-void
.end method

.method private a([CII)V
    .registers 8

    const/16 v1, 0x2000

    if-le p3, v1, :cond_15

    add-int v3, p2, p3

    :goto_6
    if-ge p2, v3, :cond_28

    add-int/lit16 v2, p2, 0x2000

    if-ge v2, v3, :cond_12

    move v0, v1

    :goto_d
    invoke-direct {p0, p1, p2, v0}, La/d/g;->a([CII)V

    move p2, v2

    goto :goto_6

    :cond_12
    sub-int v0, v3, p2

    goto :goto_d

    :cond_15
    iget v0, p0, La/d/g;->c:I

    add-int v2, v0, p3

    if-le v2, v1, :cond_20

    invoke-virtual {p0}, La/d/g;->flush()V

    iget v0, p0, La/d/g;->c:I

    :cond_20
    iget-object v1, p0, La/d/g;->b:[C

    invoke-static {p1, p2, v1, v0, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    add-int/2addr v0, p3

    iput v0, p0, La/d/g;->c:I

    :cond_28
    return-void
.end method

.method private b(Ljava/lang/String;)V
    .registers 8

    const/4 v0, 0x0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v2

    sget-object v3, La/d/g;->a:[Ljava/lang/String;

    move v1, v0

    :goto_8
    if-ge v1, v2, :cond_25

    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const/16 v5, 0x40

    if-ge v4, v5, :cond_22

    aget-object v4, v3, v4

    if-eqz v4, :cond_22

    if-ge v0, v1, :cond_1d

    sub-int v5, v1, v0

    invoke-direct {p0, p1, v0, v5}, La/d/g;->a(Ljava/lang/String;II)V

    :cond_1d
    add-int/lit8 v0, v1, 0x1

    invoke-direct {p0, v4}, La/d/g;->a(Ljava/lang/String;)V

    :cond_22
    add-int/lit8 v1, v1, 0x1

    goto :goto_8

    :cond_25
    if-ge v0, v1, :cond_2b

    sub-int/2addr v1, v0

    invoke-direct {p0, p1, v0, v1}, La/d/g;->a(Ljava/lang/String;II)V

    :cond_2b
    return-void
.end method

.method private replace(Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    const-string v0, "\\\""

    const-string v1, "\""

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public final a([Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    .registers 13

    const/4 v1, 0x0

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    move v0, v1

    :goto_c
    array-length v2, p1

    if-ge v0, v2, :cond_49

    aget-object v5, p1, v0

    aget-object v2, p2, v0

    aget-object v6, p3, v0

    if-eqz v5, :cond_40

    const-string v7, ""

    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_40

    iget-object v7, p0, La/d/g;->j:La/d/j;

    iget v8, p0, La/d/g;->i:I

    invoke-virtual {v7, v8, v5}, La/d/j;->a(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_40

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, ":"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :cond_40
    invoke-interface {v4, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-interface {v3, v2, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v0, v0, 0x1

    goto :goto_c

    :cond_49
    invoke-static {v4}, Ljava/util/Collections;->sort(Ljava/util/List;)V

    move v2, v1

    :goto_4d
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v0

    if-ge v2, v0, :cond_78

    invoke-interface {v4, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-interface {v3, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const/16 v5, 0x20

    invoke-direct {p0, v5}, La/d/g;->a(C)V

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    const-string v0, "=\""

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    invoke-direct {p0, v1}, La/d/g;->b(Ljava/lang/String;)V

    const/16 v0, 0x22

    invoke-direct {p0, v0}, La/d/g;->a(C)V

    add-int/lit8 v1, v2, 0x1

    move v2, v1

    goto :goto_4d

    :cond_78
    return-object p0
.end method

.method public final a(Lorg/xmlpull/v1/XmlPullParser;)V
    .registers 9

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getNamespace()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, La/d/g;->startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-interface {p1, v0}, Lorg/xmlpull/v1/XmlPullParser;->getNamespaceCount(I)I

    move-result v0

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v1

    invoke-interface {p1, v1}, Lorg/xmlpull/v1/XmlPullParser;->getNamespaceCount(I)I

    move-result v1

    :goto_1d
    if-eq v0, v1, :cond_4b

    invoke-interface {p1, v0}, Lorg/xmlpull/v1/XmlPullParser;->getNamespacePrefix(I)Ljava/lang/String;

    move-result-object v2

    invoke-interface {p1, v0}, Lorg/xmlpull/v1/XmlPullParser;->getNamespaceUri(I)Ljava/lang/String;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_48

    iget-object v4, p0, La/d/g;->j:La/d/j;

    iget v5, p0, La/d/g;->i:I

    invoke-virtual {v4, v5, v2, v3}, La/d/j;->a(ILjava/lang/String;Ljava/lang/String;)V

    const-string v4, " xmlns:%s=\"%s\""

    const/4 v5, 0x2

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v6, 0x0

    aput-object v2, v5, v6

    const/4 v2, 0x1

    aput-object v3, v5, v2

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, La/d/g;->a(Ljava/lang/String;)V

    :cond_48
    add-int/lit8 v0, v0, 0x1

    goto :goto_1d

    :cond_4b
    return-void
.end method

.method public final attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    .registers 9

    const/16 v4, 0x3a

    if-nez p3, :cond_5

    :goto_4
    return-object p0

    :cond_5
    const/16 v0, 0x20

    invoke-direct {p0, v0}, La/d/g;->a(C)V

    if-eqz p1, :cond_24

    const-string v0, ""

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_24

    iget-object v0, p0, La/d/g;->j:La/d/j;

    iget v1, p0, La/d/g;->i:I

    invoke-virtual {v0, v1, p1}, La/d/j;->a(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_35

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    invoke-direct {p0, v4}, La/d/g;->a(C)V

    :cond_24
    :goto_24
    invoke-direct {p0, p2}, La/d/g;->a(Ljava/lang/String;)V

    const-string v0, "=\""

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    invoke-direct {p0, p3}, La/d/g;->a(Ljava/lang/String;)V

    const/16 v0, 0x22

    invoke-direct {p0, v0}, La/d/g;->a(C)V

    goto :goto_4

    :cond_35
    const/16 v0, 0x2f

    invoke-virtual {p1, v0}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_6f

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    if-eq v0, v1, :cond_6f

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    :goto_4c
    iget-object v1, p0, La/d/g;->j:La/d/j;

    iget v2, p0, La/d/g;->i:I

    invoke-virtual {v1, v2, v0, p1}, La/d/j;->a(ILjava/lang/String;Ljava/lang/String;)V

    const-string v1, "xmlns:"

    invoke-direct {p0, v1}, La/d/g;->a(Ljava/lang/String;)V

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    const-string v1, "=\""

    invoke-direct {p0, v1}, La/d/g;->a(Ljava/lang/String;)V

    invoke-direct {p0, p1}, La/d/g;->a(Ljava/lang/String;)V

    const-string v1, "\" "

    invoke-direct {p0, v1}, La/d/g;->a(Ljava/lang/String;)V

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    invoke-direct {p0, v4}, La/d/g;->a(C)V

    goto :goto_24

    :cond_6f
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "ns"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    new-instance v1, Ljava/util/Random;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    invoke-direct {v1, v2, v3}, Ljava/util/Random;-><init>(J)V

    invoke-virtual {v1}, Ljava/util/Random;->nextInt()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_4c
.end method

.method public final cdsect(Ljava/lang/String;)V
    .registers 3

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final comment(Ljava/lang/String;)V
    .registers 3

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final docdecl(Ljava/lang/String;)V
    .registers 3

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final endDocument()V
    .registers 2

    invoke-virtual {p0}, La/d/g;->flush()V

    const/4 v0, 0x0

    iput-object v0, p0, La/d/g;->e:Ljava/io/OutputStream;

    return-void
.end method

.method public final endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    .registers 6

    const/4 v1, 0x0

    iget-object v0, p0, La/d/g;->j:La/d/j;

    iget v2, p0, La/d/g;->i:I

    invoke-virtual {v0, v2}, La/d/j;->a(I)V

    iget v0, p0, La/d/g;->i:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, La/d/g;->i:I

    iget-boolean v0, p0, La/d/g;->h:Z

    if-eqz v0, :cond_1a

    const-string v0, " />\n"

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    :goto_17
    iput-boolean v1, p0, La/d/g;->h:Z

    return-object p0

    :cond_1a
    iget-boolean v2, p0, La/d/g;->tab:Z

    if-nez v2, :cond_2b

    move v0, v1

    :goto_1f
    iget v2, p0, La/d/g;->i:I

    if-ge v0, v2, :cond_2b

    const/16 v2, 0x9

    invoke-direct {p0, v2}, La/d/g;->a(C)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_1f

    :cond_2b
    const/4 v0, 0x0

    iput-boolean v0, p0, La/d/g;->tab:Z

    const-string v0, "</"

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    if-eqz p1, :cond_47

    iget-object v0, p0, La/d/g;->j:La/d/j;

    iget v2, p0, La/d/g;->i:I

    invoke-virtual {v0, v2, p1}, La/d/j;->a(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_47

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-direct {p0, v0}, La/d/g;->a(C)V

    :cond_47
    invoke-direct {p0, p2}, La/d/g;->a(Ljava/lang/String;)V

    const-string v0, ">\n"

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    goto :goto_17
.end method

.method public final entityRef(Ljava/lang/String;)V
    .registers 3

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final flush()V
    .registers 6

    const/4 v4, 0x1

    const/4 v3, 0x0

    iget v0, p0, La/d/g;->c:I

    if-lez v0, :cond_46

    iget-object v0, p0, La/d/g;->e:Ljava/io/OutputStream;

    if-eqz v0, :cond_47

    iget-object v0, p0, La/d/g;->b:[C

    iget v1, p0, La/d/g;->c:I

    invoke-static {v0, v3, v1}, Ljava/nio/CharBuffer;->wrap([CII)Ljava/nio/CharBuffer;

    move-result-object v1

    iget-object v0, p0, La/d/g;->f:Ljava/nio/charset/CharsetEncoder;

    iget-object v2, p0, La/d/g;->g:Ljava/nio/ByteBuffer;

    invoke-virtual {v0, v1, v2, v4}, Ljava/nio/charset/CharsetEncoder;->encode(Ljava/nio/CharBuffer;Ljava/nio/ByteBuffer;Z)Ljava/nio/charset/CoderResult;

    move-result-object v0

    :goto_1a
    invoke-virtual {v0}, Ljava/nio/charset/CoderResult;->isError()Z

    move-result v2

    if-eqz v2, :cond_2a

    new-instance v1, Ljava/io/IOException;

    invoke-virtual {v0}, Ljava/nio/charset/CoderResult;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_2a
    invoke-virtual {v0}, Ljava/nio/charset/CoderResult;->isOverflow()Z

    move-result v0

    if-eqz v0, :cond_3c

    invoke-direct {p0}, La/d/g;->a()V

    iget-object v0, p0, La/d/g;->f:Ljava/nio/charset/CharsetEncoder;

    iget-object v2, p0, La/d/g;->g:Ljava/nio/ByteBuffer;

    invoke-virtual {v0, v1, v2, v4}, Ljava/nio/charset/CharsetEncoder;->encode(Ljava/nio/CharBuffer;Ljava/nio/ByteBuffer;Z)Ljava/nio/charset/CoderResult;

    move-result-object v0

    goto :goto_1a

    :cond_3c
    invoke-direct {p0}, La/d/g;->a()V

    iget-object v0, p0, La/d/g;->e:Ljava/io/OutputStream;

    invoke-virtual {v0}, Ljava/io/OutputStream;->flush()V

    :goto_44
    iput v3, p0, La/d/g;->c:I

    :cond_46
    return-void

    :cond_47
    iget-object v0, p0, La/d/g;->d:Ljava/io/Writer;

    iget-object v1, p0, La/d/g;->b:[C

    iget v2, p0, La/d/g;->c:I

    invoke-virtual {v0, v1, v3, v2}, Ljava/io/Writer;->write([CII)V

    iget-object v0, p0, La/d/g;->d:Ljava/io/Writer;

    invoke-virtual {v0}, Ljava/io/Writer;->flush()V

    goto :goto_44
.end method

.method public final getDepth()I
    .registers 2

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final getFeature(Ljava/lang/String;)Z
    .registers 3

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final getName()Ljava/lang/String;
    .registers 2

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final getNamespace()Ljava/lang/String;
    .registers 2

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final getPrefix(Ljava/lang/String;Z)Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final getProperty(Ljava/lang/String;)Ljava/lang/Object;
    .registers 3

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final ignorableWhitespace(Ljava/lang/String;)V
    .registers 3

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final processingInstruction(Ljava/lang/String;)V
    .registers 3

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final setFeature(Ljava/lang/String;Z)V
    .registers 4

    const-string v0, "http://xmlpull.org/v1/doc/features.html#indent-output"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9

    return-void

    :cond_9
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final setOutput(Ljava/io/OutputStream;Ljava/lang/String;)V
    .registers 5

    if-nez p1, :cond_8

    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v0

    :cond_8
    :try_start_8
    invoke-static {p2}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    invoke-virtual {v0}, Ljava/nio/charset/Charset;->newEncoder()Ljava/nio/charset/CharsetEncoder;

    move-result-object v0

    iput-object v0, p0, La/d/g;->f:Ljava/nio/charset/CharsetEncoder;
    :try_end_12
    .catch Ljava/nio/charset/IllegalCharsetNameException; {:try_start_8 .. :try_end_12} :catch_15
    .catch Ljava/nio/charset/UnsupportedCharsetException; {:try_start_8 .. :try_end_12} :catch_22

    iput-object p1, p0, La/d/g;->e:Ljava/io/OutputStream;

    return-void

    :catch_15
    move-exception v0

    new-instance v1, Ljava/io/UnsupportedEncodingException;

    invoke-direct {v1, p2}, Ljava/io/UnsupportedEncodingException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/io/UnsupportedEncodingException;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object v0

    check-cast v0, Ljava/io/UnsupportedEncodingException;

    throw v0

    :catch_22
    move-exception v0

    new-instance v1, Ljava/io/UnsupportedEncodingException;

    invoke-direct {v1, p2}, Ljava/io/UnsupportedEncodingException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/io/UnsupportedEncodingException;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object v0

    check-cast v0, Ljava/io/UnsupportedEncodingException;

    throw v0
.end method

.method public final setOutput(Ljava/io/Writer;)V
    .registers 2

    iput-object p1, p0, La/d/g;->d:Ljava/io/Writer;

    return-void
.end method

.method public final setPrefix(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final setProperty(Ljava/lang/String;Ljava/lang/Object;)V
    .registers 4

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final startDocument(Ljava/lang/String;Ljava/lang/Boolean;)V
    .registers 5

    const/4 v1, 0x0

    iput-boolean v1, p0, La/d/g;->tab:Z

    iput-boolean v1, p0, La/d/g;->l:Z

    iput-boolean v1, p0, La/d/g;->k:Z

    new-instance v0, La/d/j;

    invoke-direct {v0}, La/d/j;-><init>()V

    iput-object v0, p0, La/d/g;->j:La/d/j;

    iput v1, p0, La/d/g;->i:I

    iput v1, p0, La/d/g;->c:I

    iput-boolean v1, p0, La/d/g;->h:Z

    if-eqz p2, :cond_3a

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v0, "<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\""

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_37

    const-string v0, "yes"

    :goto_25
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\" ?>\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    :goto_36
    return-void

    :cond_37
    const-string v0, "no"

    goto :goto_25

    :cond_3a
    const-string v0, "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n"

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    goto :goto_36
.end method

.method public final startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    .registers 5

    iget-boolean v0, p0, La/d/g;->h:Z

    if-eqz v0, :cond_9

    const-string v0, ">\n"

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    :cond_9
    const/4 v0, 0x0

    :goto_a
    iget v1, p0, La/d/g;->i:I

    if-ge v0, v1, :cond_16

    const/16 v1, 0x9

    invoke-direct {p0, v1}, La/d/g;->a(C)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_a

    :cond_16
    const/16 v0, 0x3c

    invoke-direct {p0, v0}, La/d/g;->a(C)V

    if-eqz p1, :cond_2f

    iget-object v0, p0, La/d/g;->j:La/d/j;

    iget v1, p0, La/d/g;->i:I

    invoke-virtual {v0, v1, p1}, La/d/j;->a(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_2f

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-direct {p0, v0}, La/d/g;->a(C)V

    :cond_2f
    invoke-direct {p0, p2}, La/d/g;->a(Ljava/lang/String;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, La/d/g;->h:Z

    iget v0, p0, La/d/g;->i:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/d/g;->i:I

    return-object p0
.end method

.method public final text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    .registers 8

    invoke-direct {p0, p1}, La/d/g;->replace(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v1, 0x0

    iput-boolean v5, p0, La/d/g;->tab:Z

    iget-boolean v0, p0, La/d/g;->h:Z

    if-eqz v0, :cond_13

    const-string v0, ">"

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    iput-boolean v1, p0, La/d/g;->h:Z

    :cond_13
    iput-boolean v1, p0, La/d/g;->l:Z

    iput-boolean v1, p0, La/d/g;->k:Z

    move v0, v1

    move v2, v1

    :goto_19
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    if-ge v0, v3, :cond_a4

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/16 v4, 0x5d

    if-ne v3, v4, :cond_33

    iget-boolean v3, p0, La/d/g;->k:Z

    if-eqz v3, :cond_30

    iput-boolean v5, p0, La/d/g;->l:Z

    :cond_2d
    :goto_2d
    add-int/lit8 v0, v0, 0x1

    goto :goto_19

    :cond_30
    iput-boolean v5, p0, La/d/g;->k:Z

    goto :goto_2d

    :cond_33
    const/16 v4, 0x26

    if-ne v3, v4, :cond_76

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    add-int/lit8 v3, v3, -0x3

    if-ge v0, v3, :cond_5d

    add-int/lit8 v3, v0, 0x1

    invoke-virtual {p1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/16 v4, 0x6c

    if-ne v3, v4, :cond_5d

    add-int/lit8 v3, v0, 0x2

    invoke-virtual {p1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/16 v4, 0x74

    if-ne v3, v4, :cond_5d

    add-int/lit8 v3, v0, 0x3

    invoke-virtual {p1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/16 v4, 0x3b

    if-eq v3, v4, :cond_6d

    :cond_5d
    if-le v0, v2, :cond_66

    invoke-virtual {p1, v2, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, La/d/g;->a(Ljava/lang/String;)V

    :cond_66
    const-string v2, "&amp;"

    invoke-direct {p0, v2}, La/d/g;->a(Ljava/lang/String;)V

    add-int/lit8 v2, v0, 0x1

    :cond_6d
    :goto_6d
    iget-boolean v3, p0, La/d/g;->k:Z

    if-eqz v3, :cond_2d

    iput-boolean v1, p0, La/d/g;->k:Z

    iput-boolean v1, p0, La/d/g;->l:Z

    goto :goto_2d

    :cond_76
    const/16 v4, 0x3c

    if-ne v3, v4, :cond_8b

    if-le v0, v2, :cond_83

    invoke-virtual {p1, v2, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, La/d/g;->a(Ljava/lang/String;)V

    :cond_83
    const-string v2, "&lt;"

    invoke-direct {p0, v2}, La/d/g;->a(Ljava/lang/String;)V

    add-int/lit8 v2, v0, 0x1

    goto :goto_6d

    :cond_8b
    iget-boolean v4, p0, La/d/g;->l:Z

    if-eqz v4, :cond_6d

    const/16 v4, 0x3e

    if-ne v3, v4, :cond_6d

    if-le v0, v2, :cond_9c

    invoke-virtual {p1, v2, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, La/d/g;->a(Ljava/lang/String;)V

    :cond_9c
    const-string v2, "&gt;"

    invoke-direct {p0, v2}, La/d/g;->a(Ljava/lang/String;)V

    add-int/lit8 v2, v0, 0x1

    goto :goto_6d

    :cond_a4
    if-lez v2, :cond_ae

    invoke-virtual {p1, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    :goto_ad
    return-object p0

    :cond_ae
    invoke-direct {p0, p1}, La/d/g;->a(Ljava/lang/String;)V

    goto :goto_ad
.end method

.method public final text([CII)Lorg/xmlpull/v1/XmlSerializer;
    .registers 10

    const/4 v5, 0x1

    const/4 v4, 0x0

    iget-boolean v0, p0, La/d/g;->h:Z

    if-eqz v0, :cond_d

    const-string v0, ">"

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    iput-boolean v4, p0, La/d/g;->h:Z

    :cond_d
    iput-boolean v4, p0, La/d/g;->l:Z

    iput-boolean v4, p0, La/d/g;->k:Z

    add-int v1, p2, p3

    move v0, p2

    :goto_14
    if-ge p2, v1, :cond_6d

    aget-char v2, p1, p2

    const/16 v3, 0x5d

    if-ne v2, v3, :cond_28

    iget-boolean v2, p0, La/d/g;->k:Z

    if-eqz v2, :cond_25

    iput-boolean v5, p0, La/d/g;->l:Z

    :cond_22
    :goto_22
    add-int/lit8 p2, p2, 0x1

    goto :goto_14

    :cond_25
    iput-boolean v5, p0, La/d/g;->k:Z

    goto :goto_22

    :cond_28
    const/16 v3, 0x26

    if-ne v2, v3, :cond_43

    if-le p2, v0, :cond_33

    sub-int v2, p2, v0

    invoke-direct {p0, p1, v0, v2}, La/d/g;->a([CII)V

    :cond_33
    const-string v0, "&amp;"

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    add-int/lit8 v0, p2, 0x1

    :cond_3a
    :goto_3a
    iget-boolean v2, p0, La/d/g;->k:Z

    if-eqz v2, :cond_22

    iput-boolean v4, p0, La/d/g;->k:Z

    iput-boolean v4, p0, La/d/g;->l:Z

    goto :goto_22

    :cond_43
    const/16 v3, 0x3c

    if-ne v2, v3, :cond_56

    if-le p2, v0, :cond_4e

    sub-int v2, p2, v0

    invoke-direct {p0, p1, v0, v2}, La/d/g;->a([CII)V

    :cond_4e
    const-string v0, "&lt;"

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    add-int/lit8 v0, p2, 0x1

    goto :goto_3a

    :cond_56
    iget-boolean v3, p0, La/d/g;->l:Z

    if-eqz v3, :cond_3a

    const/16 v3, 0x3e

    if-ne v2, v3, :cond_3a

    if-le p2, v0, :cond_65

    sub-int v2, p2, v0

    invoke-direct {p0, p1, v0, v2}, La/d/g;->a([CII)V

    :cond_65
    const-string v0, "&gt;"

    invoke-direct {p0, v0}, La/d/g;->a(Ljava/lang/String;)V

    add-int/lit8 v0, p2, 0x1

    goto :goto_3a

    :cond_6d
    if-le v1, v0, :cond_73

    sub-int/2addr v1, v0

    invoke-direct {p0, p1, v0, v1}, La/d/g;->a([CII)V

    :cond_73
    return-object p0
.end method
