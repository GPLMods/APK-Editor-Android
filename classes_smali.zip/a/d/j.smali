.class public final La/d/j;
.super Ljava/lang/Object;


# instance fields
.field private a:[Ljava/lang/Object;

.field private b:I

.field private c:I


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    iput-object v0, p0, La/d/j;->a:[Ljava/lang/Object;

    const/4 v0, 0x0

    iput v0, p0, La/d/j;->b:I

    return-void
.end method

.method private static a(Ljava/util/ArrayList;Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_4
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1f

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/util/Pair;

    iget-object v1, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    iget-object v0, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    :goto_1e
    return-object v0

    :cond_1f
    const/4 v0, 0x0

    goto :goto_1e
.end method


# virtual methods
.method public final a(ILjava/lang/String;)Ljava/lang/String;
    .registers 8

    const/4 v3, 0x1

    const/4 v2, 0x0

    iget v0, p0, La/d/j;->b:I

    if-ne v0, v3, :cond_48

    iget-object v0, p0, La/d/j;->a:[Ljava/lang/Object;

    iget v1, p0, La/d/j;->c:I

    aget-object v0, v0, v1

    check-cast v0, Ljava/util/ArrayList;

    if-eqz v0, :cond_46

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ne v1, v3, :cond_42

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/util/Pair;

    iget-object v1, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v4

    if-ne v3, v4, :cond_6a

    iget-object v1, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    add-int/lit8 v3, v3, -0x1

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v1

    add-int/lit8 v3, v4, -0x1

    invoke-virtual {p2, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    if-ne v1, v3, :cond_6a

    iget-object v0, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    :cond_41
    :goto_41
    return-object v0

    :cond_42
    invoke-static {v0, p2}, La/d/j;->a(Ljava/util/ArrayList;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :cond_46
    move-object v0, v2

    goto :goto_41

    :cond_48
    iget-object v0, p0, La/d/j;->a:[Ljava/lang/Object;

    array-length v0, v0

    if-lt p1, v0, :cond_52

    iget-object v0, p0, La/d/j;->a:[Ljava/lang/Object;

    array-length v0, v0

    add-int/lit8 p1, v0, -0x1

    :cond_52
    move-object v0, v2

    :goto_53
    if-ltz p1, :cond_41

    iget-object v1, p0, La/d/j;->a:[Ljava/lang/Object;

    aget-object v1, v1, p1

    if-eqz v1, :cond_67

    iget-object v0, p0, La/d/j;->a:[Ljava/lang/Object;

    aget-object v0, v0, p1

    check-cast v0, Ljava/util/ArrayList;

    invoke-static {v0, p2}, La/d/j;->a(Ljava/util/ArrayList;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_41

    :cond_67
    add-int/lit8 p1, p1, -0x1

    goto :goto_53

    :cond_6a
    move-object v0, v2

    goto :goto_41
.end method

.method public final a(I)V
    .registers 4

    iget-object v0, p0, La/d/j;->a:[Ljava/lang/Object;

    array-length v0, v0

    if-le v0, p1, :cond_10

    iget-object v0, p0, La/d/j;->a:[Ljava/lang/Object;

    aget-object v0, v0, p1

    if-eqz v0, :cond_10

    iget-object v0, p0, La/d/j;->a:[Ljava/lang/Object;

    const/4 v1, 0x0

    aput-object v1, v0, p1

    :cond_10
    return-void
.end method

.method public final a(ILjava/lang/String;Ljava/lang/String;)V
    .registers 7

    iput p1, p0, La/d/j;->c:I

    iget-object v0, p0, La/d/j;->a:[Ljava/lang/Object;

    array-length v0, v0

    if-lt p1, v0, :cond_1c

    add-int/lit8 v0, p1, 0x1

    new-array v1, v0, [Ljava/lang/Object;

    const/4 v0, 0x0

    :goto_c
    iget-object v2, p0, La/d/j;->a:[Ljava/lang/Object;

    array-length v2, v2

    if-ge v0, v2, :cond_1a

    iget-object v2, p0, La/d/j;->a:[Ljava/lang/Object;

    aget-object v2, v2, v0

    aput-object v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_c

    :cond_1a
    iput-object v1, p0, La/d/j;->a:[Ljava/lang/Object;

    :cond_1c
    iget-object v0, p0, La/d/j;->a:[Ljava/lang/Object;

    aget-object v0, v0, p1

    if-nez v0, :cond_39

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-static {p2, p3}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, La/d/j;->a:[Ljava/lang/Object;

    aput-object v0, v1, p1

    iget v0, p0, La/d/j;->b:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/d/j;->b:I

    :goto_38
    return-void

    :cond_39
    iget-object v0, p0, La/d/j;->a:[Ljava/lang/Object;

    aget-object v0, v0, p1

    check-cast v0, Ljava/util/ArrayList;

    invoke-static {p2, p3}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_38
.end method
