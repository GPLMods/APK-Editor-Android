.class public final La/d/c;
.super Ljava/lang/Enum;


# static fields
.field public static final enum a:I

.field public static final enum b:I

.field public static final enum c:I

.field public static final enum d:I

.field public static final enum e:I

.field private static final synthetic f:[I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    sput v0, La/d/c;->a:I

    const/4 v0, 0x2

    sput v0, La/d/c;->b:I

    const/4 v0, 0x3

    sput v0, La/d/c;->c:I

    const/4 v0, 0x4

    sput v0, La/d/c;->d:I

    sput v1, La/d/c;->e:I

    new-array v0, v1, [I

    fill-array-data v0, :array_18

    sput-object v0, La/d/c;->f:[I

    return-void

    nop

    :array_18
    .array-data 4
        0x1
        0x2
        0x3
        0x4
        0x5
    .end array-data
.end method

.method public static a()[I
    .registers 1

    sget-object v0, La/d/c;->f:[I

    invoke-virtual {v0}, [I->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [I

    return-object v0
.end method
