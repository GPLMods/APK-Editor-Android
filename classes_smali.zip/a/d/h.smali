.class public final La/d/h;
.super Ljava/lang/Object;

# interfaces
.implements Lorg/xmlpull/v1/XmlSerializer;


# instance fields
.field private final a:[C

.field private b:I

.field private c:Ljava/io/Writer;

.field private d:Z

.field private e:I

.field private f:I

.field private g:[Ljava/lang/String;

.field private h:[I

.field private i:[Ljava/lang/String;

.field private j:[Z

.field private k:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x2000

    new-array v0, v0, [C

    iput-object v0, p0, La/d/h;->a:[C

    const/16 v0, 0xc

    new-array v0, v0, [Ljava/lang/String;

    iput-object v0, p0, La/d/h;->g:[Ljava/lang/String;

    new-array v0, v1, [I

    iput-object v0, p0, La/d/h;->h:[I

    const/16 v0, 0x8

    new-array v0, v0, [Ljava/lang/String;

    iput-object v0, p0, La/d/h;->i:[Ljava/lang/String;

    new-array v0, v1, [Z

    iput-object v0, p0, La/d/h;->j:[Z

    return-void
.end method

.method private final a(Ljava/lang/String;ZZ)Ljava/lang/String;
    .registers 10

    const/4 v1, 0x0

    iget-object v0, p0, La/d/h;->h:[I

    iget v2, p0, La/d/h;->f:I

    add-int/lit8 v2, v2, 0x1

    aget v0, v0, v2

    shl-int/lit8 v0, v0, 0x1

    add-int/lit8 v0, v0, -0x2

    move v3, v0

    :goto_e
    if-ltz v3, :cond_4f

    iget-object v0, p0, La/d/h;->i:[Ljava/lang/String;

    add-int/lit8 v2, v3, 0x1

    aget-object v0, v0, v2

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4b

    if-nez p2, :cond_28

    iget-object v0, p0, La/d/h;->i:[Ljava/lang/String;

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_4b

    :cond_28
    iget-object v0, p0, La/d/h;->i:[Ljava/lang/String;

    aget-object v2, v0, v3

    add-int/lit8 v0, v3, 0x2

    :goto_2e
    iget-object v4, p0, La/d/h;->h:[I

    iget v5, p0, La/d/h;->f:I

    add-int/lit8 v5, v5, 0x1

    aget v4, v4, v5

    shl-int/lit8 v4, v4, 0x1

    if-ge v0, v4, :cond_9a

    iget-object v4, p0, La/d/h;->i:[Ljava/lang/String;

    aget-object v4, v4, v0

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_48

    move-object v0, v1

    :goto_45
    if-eqz v0, :cond_4b

    :goto_47
    return-object v0

    :cond_48
    add-int/lit8 v0, v0, 0x1

    goto :goto_2e

    :cond_4b
    add-int/lit8 v0, v3, -0x2

    move v3, v0

    goto :goto_e

    :cond_4f
    if-nez p3, :cond_53

    move-object v0, v1

    goto :goto_47

    :cond_53
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_66

    const-string v0, ""

    :goto_5b
    iget-boolean v1, p0, La/d/h;->d:Z

    const/4 v2, 0x0

    iput-boolean v2, p0, La/d/h;->d:Z

    invoke-virtual {p0, v0, p1}, La/d/h;->setPrefix(Ljava/lang/String;Ljava/lang/String;)V

    iput-boolean v1, p0, La/d/h;->d:Z

    goto :goto_47

    :cond_66
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "n"

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v2, p0, La/d/h;->e:I

    add-int/lit8 v3, v2, 0x1

    iput v3, p0, La/d/h;->e:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, La/d/h;->h:[I

    iget v3, p0, La/d/h;->f:I

    add-int/lit8 v3, v3, 0x1

    aget v2, v2, v3

    shl-int/lit8 v2, v2, 0x1

    add-int/lit8 v2, v2, -0x2

    :goto_87
    if-ltz v2, :cond_94

    iget-object v3, p0, La/d/h;->i:[Ljava/lang/String;

    aget-object v3, v3, v2

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_97

    move-object v0, v1

    :cond_94
    if-eqz v0, :cond_66

    goto :goto_5b

    :cond_97
    add-int/lit8 v2, v2, -0x2

    goto :goto_87

    :cond_9a
    move-object v0, v2

    goto :goto_45
.end method

.method private final a()V
    .registers 5

    const/4 v3, 0x0

    iget v0, p0, La/d/h;->b:I

    if-lez v0, :cond_15

    iget-object v0, p0, La/d/h;->c:Ljava/io/Writer;

    iget-object v1, p0, La/d/h;->a:[C

    iget v2, p0, La/d/h;->b:I

    invoke-virtual {v0, v1, v3, v2}, Ljava/io/Writer;->write([CII)V

    iget-object v0, p0, La/d/h;->c:Ljava/io/Writer;

    invoke-virtual {v0}, Ljava/io/Writer;->flush()V

    iput v3, p0, La/d/h;->b:I

    :cond_15
    return-void
.end method

.method private a(C)V
    .registers 5

    iget v0, p0, La/d/h;->b:I

    const/16 v1, 0x2000

    if-lt v0, v1, :cond_9

    invoke-direct {p0}, La/d/h;->a()V

    :cond_9
    iget-object v0, p0, La/d/h;->a:[C

    iget v1, p0, La/d/h;->b:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, La/d/h;->b:I

    aput-char p1, v0, v1

    return-void
.end method

.method private a(Ljava/lang/String;)V
    .registers 8

    const/4 v0, 0x0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    move v2, v0

    :goto_6
    if-lez v1, :cond_29

    iget v0, p0, La/d/h;->b:I

    const/16 v3, 0x2000

    if-ne v0, v3, :cond_11

    invoke-direct {p0}, La/d/h;->a()V

    :cond_11
    iget v0, p0, La/d/h;->b:I

    rsub-int v0, v0, 0x2000

    if-le v0, v1, :cond_18

    move v0, v1

    :cond_18
    add-int v3, v2, v0

    iget-object v4, p0, La/d/h;->a:[C

    iget v5, p0, La/d/h;->b:I

    invoke-virtual {p1, v2, v3, v4, v5}, Ljava/lang/String;->getChars(II[CI)V

    add-int/2addr v2, v0

    sub-int/2addr v1, v0

    iget v3, p0, La/d/h;->b:I

    add-int/2addr v0, v3

    iput v0, p0, La/d/h;->b:I

    goto :goto_6

    :cond_29
    return-void
.end method

.method private final a(Ljava/lang/String;I)V
    .registers 8

    const/16 v4, 0x3b

    const/4 v0, 0x0

    :goto_3
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    if-ge v0, v1, :cond_b1

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v1

    sparse-switch v1, :sswitch_data_b2

    if-ne v1, p2, :cond_ac

    const/16 v2, 0x22

    if-ne v1, v2, :cond_a8

    const-string v1, "&quot;"

    :goto_18
    invoke-direct {p0, v1}, La/d/h;->a(Ljava/lang/String;)V

    :goto_1b
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :sswitch_1e
    const/4 v2, -0x1

    if-eq p2, v2, :cond_ac

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "&#"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, La/d/h;->a(Ljava/lang/String;)V

    goto :goto_1b

    :sswitch_38
    add-int/lit8 v1, v0, 0x4

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v2

    if-ge v1, v2, :cond_6e

    add-int/lit8 v1, v0, 0x1

    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v2, 0x61

    if-ne v1, v2, :cond_6e

    add-int/lit8 v1, v0, 0x2

    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v2, 0x6d

    if-ne v1, v2, :cond_6e

    add-int/lit8 v1, v0, 0x3

    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v2, 0x70

    if-ne v1, v2, :cond_6e

    add-int/lit8 v1, v0, 0x4

    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    if-ne v1, v4, :cond_6e

    add-int/lit8 v0, v0, 0x4

    const-string v1, "&amp;"

    invoke-direct {p0, v1}, La/d/h;->a(Ljava/lang/String;)V

    goto :goto_1b

    :cond_6e
    add-int/lit8 v1, v0, 0x3

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v2

    if-ge v1, v2, :cond_9a

    add-int/lit8 v1, v0, 0x1

    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v2, 0x6c

    if-ne v1, v2, :cond_9a

    add-int/lit8 v1, v0, 0x2

    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v2, 0x74

    if-ne v1, v2, :cond_9a

    add-int/lit8 v1, v0, 0x3

    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    if-ne v1, v4, :cond_9a

    add-int/lit8 v0, v0, 0x3

    const-string v1, "&lt;"

    invoke-direct {p0, v1}, La/d/h;->a(Ljava/lang/String;)V

    goto :goto_1b

    :cond_9a
    const-string v1, "&amp;"

    invoke-direct {p0, v1}, La/d/h;->a(Ljava/lang/String;)V

    goto/16 :goto_1b

    :sswitch_a1
    const-string v1, "&lt;"

    invoke-direct {p0, v1}, La/d/h;->a(Ljava/lang/String;)V

    goto/16 :goto_1b

    :cond_a8
    const-string v1, "&apos;"

    goto/16 :goto_18

    :cond_ac
    invoke-direct {p0, v1}, La/d/h;->a(C)V

    goto/16 :goto_1b

    :cond_b1
    return-void

    :sswitch_data_b2
    .sparse-switch
        0x9 -> :sswitch_1e
        0xa -> :sswitch_1e
        0xd -> :sswitch_1e
        0x26 -> :sswitch_38
        0x3c -> :sswitch_a1
    .end sparse-switch
.end method

.method private final a(Z)V
    .registers 8

    const/16 v5, 0x22

    const/4 v4, 0x0

    iget-boolean v0, p0, La/d/h;->d:Z

    if-nez v0, :cond_8

    :goto_7
    return-void

    :cond_8
    iget v0, p0, La/d/h;->f:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La/d/h;->f:I

    iput-boolean v4, p0, La/d/h;->d:Z

    iget-object v0, p0, La/d/h;->j:[Z

    array-length v0, v0

    iget v1, p0, La/d/h;->f:I

    if-gt v0, v1, :cond_26

    iget v0, p0, La/d/h;->f:I

    add-int/lit8 v0, v0, 0x4

    new-array v0, v0, [Z

    iget-object v1, p0, La/d/h;->j:[Z

    iget v2, p0, La/d/h;->f:I

    invoke-static {v1, v4, v0, v4, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v0, p0, La/d/h;->j:[Z

    :cond_26
    iget-object v0, p0, La/d/h;->j:[Z

    iget v1, p0, La/d/h;->f:I

    iget-object v2, p0, La/d/h;->j:[Z

    iget v3, p0, La/d/h;->f:I

    add-int/lit8 v3, v3, -0x1

    aget-boolean v2, v2, v3

    aput-boolean v2, v0, v1

    iget-object v0, p0, La/d/h;->h:[I

    iget v1, p0, La/d/h;->f:I

    add-int/lit8 v1, v1, -0x1

    aget v0, v0, v1

    :goto_3c
    iget-object v1, p0, La/d/h;->h:[I

    iget v2, p0, La/d/h;->f:I

    aget v1, v1, v2

    if-ge v0, v1, :cond_99

    const-string v1, " xmlns"

    invoke-direct {p0, v1}, La/d/h;->a(Ljava/lang/String;)V

    iget-object v1, p0, La/d/h;->i:[Ljava/lang/String;

    shl-int/lit8 v2, v0, 0x1

    aget-object v1, v1, v2

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_79

    const/16 v1, 0x3a

    invoke-direct {p0, v1}, La/d/h;->a(C)V

    iget-object v1, p0, La/d/h;->i:[Ljava/lang/String;

    shl-int/lit8 v2, v0, 0x1

    aget-object v1, v1, v2

    invoke-direct {p0, v1}, La/d/h;->a(Ljava/lang/String;)V

    :cond_63
    const-string v1, "=\""

    invoke-direct {p0, v1}, La/d/h;->a(Ljava/lang/String;)V

    iget-object v1, p0, La/d/h;->i:[Ljava/lang/String;

    shl-int/lit8 v2, v0, 0x1

    add-int/lit8 v2, v2, 0x1

    aget-object v1, v1, v2

    invoke-direct {p0, v1, v5}, La/d/h;->a(Ljava/lang/String;I)V

    invoke-direct {p0, v5}, La/d/h;->a(C)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_3c

    :cond_79
    invoke-virtual {p0}, La/d/h;->getNamespace()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_63

    iget-object v1, p0, La/d/h;->i:[Ljava/lang/String;

    shl-int/lit8 v2, v0, 0x1

    add-int/lit8 v2, v2, 0x1

    aget-object v1, v1, v2

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_63

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Cannot set default namespace for elements in no namespace"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_99
    iget-object v0, p0, La/d/h;->h:[I

    array-length v0, v0

    iget v1, p0, La/d/h;->f:I

    add-int/lit8 v1, v1, 0x1

    if-gt v0, v1, :cond_b3

    iget v0, p0, La/d/h;->f:I

    add-int/lit8 v0, v0, 0x8

    new-array v0, v0, [I

    iget-object v1, p0, La/d/h;->h:[I

    iget v2, p0, La/d/h;->f:I

    add-int/lit8 v2, v2, 0x1

    invoke-static {v1, v4, v0, v4, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v0, p0, La/d/h;->h:[I

    :cond_b3
    iget-object v0, p0, La/d/h;->h:[I

    iget v1, p0, La/d/h;->f:I

    add-int/lit8 v1, v1, 0x1

    iget-object v2, p0, La/d/h;->h:[I

    iget v3, p0, La/d/h;->f:I

    aget v2, v2, v3

    aput v2, v0, v1

    if-eqz p1, :cond_ca

    const-string v0, " />"

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    goto/16 :goto_7

    :cond_ca
    const/16 v0, 0x3e

    invoke-direct {p0, v0}, La/d/h;->a(C)V

    goto/16 :goto_7
.end method


# virtual methods
.method public final attribute(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    .registers 7

    const/16 v1, 0x22

    iget-boolean v0, p0, La/d/h;->d:Z

    if-nez v0, :cond_e

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "illegal position for attribute"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_e
    if-nez p1, :cond_12

    const-string p1, ""

    :cond_12
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_47

    const-string v0, ""

    :goto_1a
    const/16 v2, 0x20

    invoke-direct {p0, v2}, La/d/h;->a(C)V

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_2d

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-direct {p0, v0}, La/d/h;->a(C)V

    :cond_2d
    invoke-direct {p0, p2}, La/d/h;->a(Ljava/lang/String;)V

    const/16 v0, 0x3d

    invoke-direct {p0, v0}, La/d/h;->a(C)V

    invoke-virtual {p3, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    const/4 v2, -0x1

    if-ne v0, v2, :cond_4e

    move v0, v1

    :goto_3d
    invoke-direct {p0, v0}, La/d/h;->a(C)V

    invoke-direct {p0, p3, v0}, La/d/h;->a(Ljava/lang/String;I)V

    invoke-direct {p0, v0}, La/d/h;->a(C)V

    return-object p0

    :cond_47
    const/4 v0, 0x0

    const/4 v2, 0x1

    invoke-direct {p0, p1, v0, v2}, La/d/h;->a(Ljava/lang/String;ZZ)Ljava/lang/String;

    move-result-object v0

    goto :goto_1a

    :cond_4e
    const/16 v0, 0x27

    goto :goto_3d
.end method

.method public final cdsect(Ljava/lang/String;)V
    .registers 9

    const/4 v1, 0x0

    invoke-direct {p0, v1}, La/d/h;->a(Z)V

    const-string v0, "]]>"

    const-string v2, "]]]]><![CDATA[>"

    invoke-virtual {p1, v0, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    const-string v0, "<![CDATA["

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    move v0, v1

    :goto_12
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v2

    if-ge v0, v2, :cond_d4

    invoke-virtual {v3, v0}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const/16 v2, 0x20

    if-lt v4, v2, :cond_25

    const v2, 0xd7ff

    if-le v4, v2, :cond_3b

    :cond_25
    const/16 v2, 0x9

    if-eq v4, v2, :cond_3b

    const/16 v2, 0xa

    if-eq v4, v2, :cond_3b

    const/16 v2, 0xd

    if-eq v4, v2, :cond_3b

    const v2, 0xe000

    if-lt v4, v2, :cond_44

    const v2, 0xfffd

    if-gt v4, v2, :cond_44

    :cond_3b
    const/4 v2, 0x1

    :goto_3c
    if-eqz v2, :cond_46

    invoke-direct {p0, v4}, La/d/h;->a(C)V

    :goto_41
    add-int/lit8 v0, v0, 0x1

    goto :goto_12

    :cond_44
    move v2, v1

    goto :goto_3c

    :cond_46
    invoke-static {v4}, Ljava/lang/Character;->isHighSurrogate(C)Z

    move-result v2

    if-eqz v2, :cond_b4

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    if-ge v0, v2, :cond_b4

    const-string v2, "]]>"

    invoke-direct {p0, v2}, La/d/h;->a(Ljava/lang/String;)V

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {v3, v0}, Ljava/lang/String;->charAt(I)C

    move-result v2

    invoke-static {v2}, Ljava/lang/Character;->isLowSurrogate(C)Z

    move-result v5

    if-nez v5, :cond_92

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "Bad surrogate pair (U+"

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v4}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " U+"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_92
    invoke-static {v4, v2}, Ljava/lang/Character;->toCodePoint(CC)I

    move-result v2

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "&#"

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, ";"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, La/d/h;->a(Ljava/lang/String;)V

    const-string v2, "<![CDATA["

    invoke-direct {p0, v2}, La/d/h;->a(Ljava/lang/String;)V

    goto :goto_41

    :cond_b4
    const-string v2, "APKEDITOR"

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "Illegal character (U+"

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v4}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, ")"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_41

    :cond_d4
    const-string v0, "]]>"

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    return-void
.end method

.method public final comment(Ljava/lang/String;)V
    .registers 3

    const/4 v0, 0x0

    invoke-direct {p0, v0}, La/d/h;->a(Z)V

    const-string v0, "<!--"

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    invoke-direct {p0, p1}, La/d/h;->a(Ljava/lang/String;)V

    const-string v0, "-->"

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    return-void
.end method

.method public final docdecl(Ljava/lang/String;)V
    .registers 3

    const-string v0, "<!DOCTYPE"

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    invoke-direct {p0, p1}, La/d/h;->a(Ljava/lang/String;)V

    const/16 v0, 0x3e

    invoke-direct {p0, v0}, La/d/h;->a(C)V

    return-void
.end method

.method public final endDocument()V
    .registers 4

    :goto_0
    iget v0, p0, La/d/h;->f:I

    if-lez v0, :cond_1c

    iget-object v0, p0, La/d/h;->g:[Ljava/lang/String;

    iget v1, p0, La/d/h;->f:I

    mul-int/lit8 v1, v1, 0x3

    add-int/lit8 v1, v1, -0x3

    aget-object v0, v0, v1

    iget-object v1, p0, La/d/h;->g:[Ljava/lang/String;

    iget v2, p0, La/d/h;->f:I

    mul-int/lit8 v2, v2, 0x3

    add-int/lit8 v2, v2, -0x1

    aget-object v1, v1, v2

    invoke-virtual {p0, v0, v1}, La/d/h;->endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    goto :goto_0

    :cond_1c
    invoke-virtual {p0}, La/d/h;->flush()V

    return-void
.end method

.method public final endTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    .registers 7

    iget-boolean v0, p0, La/d/h;->d:Z

    if-nez v0, :cond_a

    iget v0, p0, La/d/h;->f:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, La/d/h;->f:I

    :cond_a
    if-nez p1, :cond_16

    iget-object v0, p0, La/d/h;->g:[Ljava/lang/String;

    iget v1, p0, La/d/h;->f:I

    mul-int/lit8 v1, v1, 0x3

    aget-object v0, v0, v1

    if-nez v0, :cond_36

    :cond_16
    if-eqz p1, :cond_26

    iget-object v0, p0, La/d/h;->g:[Ljava/lang/String;

    iget v1, p0, La/d/h;->f:I

    mul-int/lit8 v1, v1, 0x3

    aget-object v0, v0, v1

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_36

    :cond_26
    iget-object v0, p0, La/d/h;->g:[Ljava/lang/String;

    iget v1, p0, La/d/h;->f:I

    mul-int/lit8 v1, v1, 0x3

    add-int/lit8 v1, v1, 0x2

    aget-object v0, v0, v1

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5b

    :cond_36
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "</{"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "}"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "> does not match start"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_5b
    iget-boolean v0, p0, La/d/h;->d:Z

    if-eqz v0, :cond_78

    const/4 v0, 0x1

    invoke-direct {p0, v0}, La/d/h;->a(Z)V

    iget v0, p0, La/d/h;->f:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, La/d/h;->f:I

    :goto_69
    iget-object v0, p0, La/d/h;->h:[I

    iget v1, p0, La/d/h;->f:I

    add-int/lit8 v1, v1, 0x1

    iget-object v2, p0, La/d/h;->h:[I

    iget v3, p0, La/d/h;->f:I

    aget v2, v2, v3

    aput v2, v0, v1

    return-object p0

    :cond_78
    iget-object v0, p0, La/d/h;->j:[Z

    iget v1, p0, La/d/h;->f:I

    add-int/lit8 v1, v1, 0x1

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_94

    const-string v0, "\r\n"

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    const/4 v0, 0x0

    :goto_88
    iget v1, p0, La/d/h;->f:I

    if-ge v0, v1, :cond_94

    const-string v1, "  "

    invoke-direct {p0, v1}, La/d/h;->a(Ljava/lang/String;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_88

    :cond_94
    const-string v0, "</"

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    iget-object v0, p0, La/d/h;->g:[Ljava/lang/String;

    iget v1, p0, La/d/h;->f:I

    mul-int/lit8 v1, v1, 0x3

    add-int/lit8 v1, v1, 0x1

    aget-object v0, v0, v1

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_b1

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-direct {p0, v0}, La/d/h;->a(C)V

    :cond_b1
    invoke-direct {p0, p2}, La/d/h;->a(Ljava/lang/String;)V

    const/16 v0, 0x3e

    invoke-direct {p0, v0}, La/d/h;->a(C)V

    goto :goto_69
.end method

.method public final entityRef(Ljava/lang/String;)V
    .registers 3

    const/4 v0, 0x0

    invoke-direct {p0, v0}, La/d/h;->a(Z)V

    const/16 v0, 0x26

    invoke-direct {p0, v0}, La/d/h;->a(C)V

    invoke-direct {p0, p1}, La/d/h;->a(Ljava/lang/String;)V

    const/16 v0, 0x3b

    invoke-direct {p0, v0}, La/d/h;->a(C)V

    return-void
.end method

.method public final flush()V
    .registers 2

    const/4 v0, 0x0

    invoke-direct {p0, v0}, La/d/h;->a(Z)V

    invoke-direct {p0}, La/d/h;->a()V

    return-void
.end method

.method public final getDepth()I
    .registers 2

    iget-boolean v0, p0, La/d/h;->d:Z

    if-eqz v0, :cond_9

    iget v0, p0, La/d/h;->f:I

    add-int/lit8 v0, v0, 0x1

    :goto_8
    return v0

    :cond_9
    iget v0, p0, La/d/h;->f:I

    goto :goto_8
.end method

.method public final getFeature(Ljava/lang/String;)Z
    .registers 4

    const-string v0, "http://xmlpull.org/v1/doc/features.html#indent-output"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_f

    iget-object v0, p0, La/d/h;->j:[Z

    iget v1, p0, La/d/h;->f:I

    aget-boolean v0, v0, v1

    :goto_e
    return v0

    :cond_f
    const/4 v0, 0x0

    goto :goto_e
.end method

.method public final getName()Ljava/lang/String;
    .registers 3

    invoke-virtual {p0}, La/d/h;->getDepth()I

    move-result v0

    if-nez v0, :cond_8

    const/4 v0, 0x0

    :goto_7
    return-object v0

    :cond_8
    iget-object v0, p0, La/d/h;->g:[Ljava/lang/String;

    invoke-virtual {p0}, La/d/h;->getDepth()I

    move-result v1

    mul-int/lit8 v1, v1, 0x3

    add-int/lit8 v1, v1, -0x1

    aget-object v0, v0, v1

    goto :goto_7
.end method

.method public final getNamespace()Ljava/lang/String;
    .registers 3

    invoke-virtual {p0}, La/d/h;->getDepth()I

    move-result v0

    if-nez v0, :cond_8

    const/4 v0, 0x0

    :goto_7
    return-object v0

    :cond_8
    iget-object v0, p0, La/d/h;->g:[Ljava/lang/String;

    invoke-virtual {p0}, La/d/h;->getDepth()I

    move-result v1

    mul-int/lit8 v1, v1, 0x3

    add-int/lit8 v1, v1, -0x3

    aget-object v0, v0, v1

    goto :goto_7
.end method

.method public final getPrefix(Ljava/lang/String;Z)Ljava/lang/String;
    .registers 5

    const/4 v0, 0x0

    :try_start_1
    invoke-direct {p0, p1, v0, p2}, La/d/h;->a(Ljava/lang/String;ZZ)Ljava/lang/String;
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_4} :catch_6

    move-result-object v0

    return-object v0

    :catch_6
    move-exception v0

    new-instance v1, Ljava/lang/RuntimeException;

    invoke-virtual {v0}, Ljava/io/IOException;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public final getProperty(Ljava/lang/String;)Ljava/lang/Object;
    .registers 4

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Unsupported property"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final ignorableWhitespace(Ljava/lang/String;)V
    .registers 5

    const/4 v2, 0x0

    invoke-direct {p0, v2}, La/d/h;->a(Z)V

    iget-object v0, p0, La/d/h;->j:[Z

    iget v1, p0, La/d/h;->f:I

    aput-boolean v2, v0, v1

    invoke-direct {p0, p1}, La/d/h;->a(Ljava/lang/String;)V

    return-void
.end method

.method public final processingInstruction(Ljava/lang/String;)V
    .registers 3

    const/4 v0, 0x0

    invoke-direct {p0, v0}, La/d/h;->a(Z)V

    const-string v0, "<?"

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    invoke-direct {p0, p1}, La/d/h;->a(Ljava/lang/String;)V

    const-string v0, "?>"

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    return-void
.end method

.method public final setFeature(Ljava/lang/String;Z)V
    .registers 5

    const-string v0, "http://xmlpull.org/v1/doc/features.html#indent-output"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_f

    iget-object v0, p0, La/d/h;->j:[Z

    iget v1, p0, La/d/h;->f:I

    aput-boolean p2, v0, v1

    return-void

    :cond_f
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Unsupported Feature"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final setOutput(Ljava/io/OutputStream;Ljava/lang/String;)V
    .registers 5

    if-nez p1, :cond_a

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "os == null"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_a
    if-nez p2, :cond_24

    new-instance v0, Ljava/io/OutputStreamWriter;

    invoke-direct {v0, p1}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;)V

    :goto_11
    invoke-virtual {p0, v0}, La/d/h;->setOutput(Ljava/io/Writer;)V

    iput-object p2, p0, La/d/h;->k:Ljava/lang/String;

    if-eqz p2, :cond_23

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p2, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "utf"

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    :cond_23
    return-void

    :cond_24
    new-instance v0, Ljava/io/OutputStreamWriter;

    invoke-direct {v0, p1, p2}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/lang/String;)V

    goto :goto_11
.end method

.method public final setOutput(Ljava/io/Writer;)V
    .registers 7

    const/4 v4, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object p1, p0, La/d/h;->c:Ljava/io/Writer;

    iget-object v0, p0, La/d/h;->h:[I

    aput v2, v0, v3

    iget-object v0, p0, La/d/h;->h:[I

    aput v2, v0, v4

    iget-object v0, p0, La/d/h;->i:[Ljava/lang/String;

    const-string v1, ""

    aput-object v1, v0, v3

    iget-object v0, p0, La/d/h;->i:[Ljava/lang/String;

    const-string v1, ""

    aput-object v1, v0, v4

    iget-object v0, p0, La/d/h;->i:[Ljava/lang/String;

    const-string v1, "xml"

    aput-object v1, v0, v2

    iget-object v0, p0, La/d/h;->i:[Ljava/lang/String;

    const/4 v1, 0x3

    const-string v2, "http://www.w3.org/XML/1998/namespace"

    aput-object v2, v0, v1

    iput-boolean v3, p0, La/d/h;->d:Z

    iput v3, p0, La/d/h;->e:I

    iput v3, p0, La/d/h;->f:I

    return-void
.end method

.method public final setPrefix(Ljava/lang/String;Ljava/lang/String;)V
    .registers 8

    const/4 v4, 0x0

    invoke-direct {p0, v4}, La/d/h;->a(Z)V

    if-nez p1, :cond_8

    const-string p1, ""

    :cond_8
    if-nez p2, :cond_c

    const-string p2, ""

    :cond_c
    const/4 v0, 0x1

    invoke-direct {p0, p2, v0, v4}, La/d/h;->a(Ljava/lang/String;ZZ)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_18

    :goto_17
    return-void

    :cond_18
    iget-object v0, p0, La/d/h;->h:[I

    iget v1, p0, La/d/h;->f:I

    add-int/lit8 v1, v1, 0x1

    aget v2, v0, v1

    add-int/lit8 v3, v2, 0x1

    aput v3, v0, v1

    shl-int/lit8 v0, v2, 0x1

    iget-object v1, p0, La/d/h;->i:[Ljava/lang/String;

    array-length v1, v1

    add-int/lit8 v2, v0, 0x1

    if-ge v1, v2, :cond_3b

    iget-object v1, p0, La/d/h;->i:[Ljava/lang/String;

    array-length v1, v1

    add-int/lit8 v1, v1, 0x10

    new-array v1, v1, [Ljava/lang/String;

    iget-object v2, p0, La/d/h;->i:[Ljava/lang/String;

    invoke-static {v2, v4, v1, v4, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v1, p0, La/d/h;->i:[Ljava/lang/String;

    :cond_3b
    iget-object v1, p0, La/d/h;->i:[Ljava/lang/String;

    add-int/lit8 v2, v0, 0x1

    aput-object p1, v1, v0

    iget-object v0, p0, La/d/h;->i:[Ljava/lang/String;

    aput-object p2, v0, v2

    goto :goto_17
.end method

.method public final setProperty(Ljava/lang/String;Ljava/lang/Object;)V
    .registers 6

    new-instance v0, Ljava/lang/RuntimeException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Unsupported Property:"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final startDocument(Ljava/lang/String;Ljava/lang/Boolean;)V
    .registers 5

    const-string v0, "<?xml version=\"1.0\" "

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    if-eqz p1, :cond_14

    iput-object p1, p0, La/d/h;->k:Ljava/lang/String;

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p1, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "utf"

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    :cond_14
    iget-object v0, p0, La/d/h;->k:Ljava/lang/String;

    if-eqz v0, :cond_27

    const-string v0, "encoding=\""

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    iget-object v0, p0, La/d/h;->k:Ljava/lang/String;

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    const-string v0, "\" "

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    :cond_27
    if-eqz p2, :cond_3e

    const-string v0, "standalone=\'"

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_44

    const-string v0, "yes"

    :goto_36
    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    const-string v0, "\' "

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    :cond_3e
    const-string v0, "?>"

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    return-void

    :cond_44
    const-string v0, "no"

    goto :goto_36
.end method

.method public final startTag(Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    .registers 9

    const/4 v5, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, v1}, La/d/h;->a(Z)V

    iget-object v0, p0, La/d/h;->j:[Z

    iget v2, p0, La/d/h;->f:I

    aget-boolean v0, v0, v2

    if-eqz v0, :cond_1f

    const-string v0, "\r\n"

    invoke-direct {p0, v0}, La/d/h;->a(Ljava/lang/String;)V

    move v0, v1

    :goto_13
    iget v2, p0, La/d/h;->f:I

    if-ge v0, v2, :cond_1f

    const-string v2, "  "

    invoke-direct {p0, v2}, La/d/h;->a(Ljava/lang/String;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_13

    :cond_1f
    iget v0, p0, La/d/h;->f:I

    mul-int/lit8 v2, v0, 0x3

    iget-object v0, p0, La/d/h;->g:[Ljava/lang/String;

    array-length v0, v0

    add-int/lit8 v3, v2, 0x3

    if-ge v0, v3, :cond_38

    iget-object v0, p0, La/d/h;->g:[Ljava/lang/String;

    array-length v0, v0

    add-int/lit8 v0, v0, 0xc

    new-array v0, v0, [Ljava/lang/String;

    iget-object v3, p0, La/d/h;->g:[Ljava/lang/String;

    invoke-static {v3, v1, v0, v1, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v0, p0, La/d/h;->g:[Ljava/lang/String;

    :cond_38
    if-nez p1, :cond_77

    const-string v0, ""

    move-object v1, v0

    :goto_3d
    if-eqz p1, :cond_80

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_80

    iget-object v0, p0, La/d/h;->h:[I

    iget v3, p0, La/d/h;->f:I

    aget v0, v0, v3

    :goto_4b
    iget-object v3, p0, La/d/h;->h:[I

    iget v4, p0, La/d/h;->f:I

    add-int/lit8 v4, v4, 0x1

    aget v3, v3, v4

    if-ge v0, v3, :cond_80

    iget-object v3, p0, La/d/h;->i:[Ljava/lang/String;

    shl-int/lit8 v4, v0, 0x1

    aget-object v3, v3, v4

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_7d

    iget-object v3, p0, La/d/h;->i:[Ljava/lang/String;

    shl-int/lit8 v4, v0, 0x1

    add-int/lit8 v4, v4, 0x1

    aget-object v3, v3, v4

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_7d

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Cannot set default namespace for elements in no namespace"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_77
    invoke-direct {p0, p1, v5, v5}, La/d/h;->a(Ljava/lang/String;ZZ)Ljava/lang/String;

    move-result-object v0

    move-object v1, v0

    goto :goto_3d

    :cond_7d
    add-int/lit8 v0, v0, 0x1

    goto :goto_4b

    :cond_80
    iget-object v0, p0, La/d/h;->g:[Ljava/lang/String;

    add-int/lit8 v3, v2, 0x1

    aput-object p1, v0, v2

    iget-object v0, p0, La/d/h;->g:[Ljava/lang/String;

    add-int/lit8 v2, v3, 0x1

    aput-object v1, v0, v3

    iget-object v0, p0, La/d/h;->g:[Ljava/lang/String;

    aput-object p2, v0, v2

    const/16 v0, 0x3c

    invoke-direct {p0, v0}, La/d/h;->a(C)V

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_a3

    invoke-direct {p0, v1}, La/d/h;->a(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-direct {p0, v0}, La/d/h;->a(C)V

    :cond_a3
    invoke-direct {p0, p2}, La/d/h;->a(Ljava/lang/String;)V

    iput-boolean v5, p0, La/d/h;->d:Z

    return-object p0
.end method

.method public final text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    .registers 5

    const/4 v2, 0x0

    invoke-direct {p0, v2}, La/d/h;->a(Z)V

    iget-object v0, p0, La/d/h;->j:[Z

    iget v1, p0, La/d/h;->f:I

    aput-boolean v2, v0, v1

    const/4 v0, -0x1

    invoke-direct {p0, p1, v0}, La/d/h;->a(Ljava/lang/String;I)V

    return-object p0
.end method

.method public final text([CII)Lorg/xmlpull/v1/XmlSerializer;
    .registers 5

    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, p1, p2, p3}, Ljava/lang/String;-><init>([CII)V

    invoke-virtual {p0, v0}, La/d/h;->text(Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;

    return-object p0
.end method
