.class public final La/d/f;
.super La/d/d;


# direct methods
.method public constructor <init>(La/a/b/a/b;)V
    .registers 2

    invoke-direct {p0, p1}, La/d/d;-><init>(Ljava/io/DataInput;)V

    return-void
.end method

.method public constructor <init>(Ljava/io/InputStream;)V
    .registers 3

    new-instance v0, Ljava/io/DataInputStream;

    invoke-direct {v0, p1}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-direct {p0, v0}, La/d/d;-><init>(Ljava/io/DataInput;)V

    return-void
.end method


# virtual methods
.method public final a(IZ)Ljava/lang/String;
    .registers 6

    new-instance v1, Ljava/lang/StringBuilder;

    const/16 v0, 0x10

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    :goto_7
    add-int/lit8 v0, p1, -0x1

    if-eqz p1, :cond_17

    invoke-virtual {p0}, La/d/f;->readShort()S

    move-result v2

    if-eqz v2, :cond_17

    int-to-char v2, v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move p1, v0

    goto :goto_7

    :cond_17
    shl-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, La/d/f;->skipBytes(I)I

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final a(II)V
    .registers 9

    invoke-virtual {p0}, La/d/f;->readInt()I

    move-result v0

    if-eq v0, p2, :cond_8

    if-ge v0, p1, :cond_d

    :cond_8
    const/4 v0, -0x1

    invoke-virtual {p0, p1, v0}, La/d/f;->a(II)V

    :cond_c
    return-void

    :cond_d
    if-eq v0, p1, :cond_c

    new-instance v1, Ljava/io/IOException;

    const-string v2, "Expected: 0x%08x, actual: 0x%08x"

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    aput-object v0, v3, v4

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1
.end method
