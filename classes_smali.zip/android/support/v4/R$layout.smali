.class public final Landroid/support/v4/R$layout;
.super Ljava/lang/Object;


# static fields
.field public static final notification_action:I = 0x7f0300c0

.field public static final notification_action_tombstone:I = 0x7f0300c1

.field public static final notification_media_action:I = 0x7f0300c2

.field public static final notification_media_cancel_action:I = 0x7f0300c3

.field public static final notification_template_big_media:I = 0x7f0300c4

.field public static final notification_template_big_media_custom:I = 0x7f0300c5

.field public static final notification_template_big_media_narrow:I = 0x7f0300c6

.field public static final notification_template_big_media_narrow_custom:I = 0x7f0300c7

.field public static final notification_template_custom_big:I = 0x7f0300c8

.field public static final notification_template_icon_group:I = 0x7f0300c9

.field public static final notification_template_lines_media:I = 0x7f0300ca

.field public static final notification_template_media:I = 0x7f0300cb

.field public static final notification_template_media_custom:I = 0x7f0300cc

.field public static final notification_template_part_chronometer:I = 0x7f0300cd

.field public static final notification_template_part_time:I = 0x7f0300ce


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
