.class public final Landroid/support/v4/R$drawable;
.super Ljava/lang/Object;


# static fields
.field public static final notification_action_background:I = 0x7f0200ff

.field public static final notification_bg:I = 0x7f020100

.field public static final notification_bg_low:I = 0x7f020101

.field public static final notification_bg_low_normal:I = 0x7f020102

.field public static final notification_bg_low_pressed:I = 0x7f020103

.field public static final notification_bg_normal:I = 0x7f020104

.field public static final notification_bg_normal_pressed:I = 0x7f020105

.field public static final notification_icon_background:I = 0x7f020106

.field public static final notification_template_icon_bg:I = 0x7f02014c

.field public static final notification_template_icon_low_bg:I = 0x7f02014d

.field public static final notification_tile_bg:I = 0x7f020107

.field public static final notify_panel_notification_icon_bg:I = 0x7f020108


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
