.class public final Landroid/support/v4/R$bool;
.super Ljava/lang/Object;


# static fields
.field public static final abc_action_bar_embed_tabs:I = 0x7f0b0000


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
