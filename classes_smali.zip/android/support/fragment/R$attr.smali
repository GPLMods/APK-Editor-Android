.class public final Landroid/support/fragment/R$attr;
.super Ljava/lang/Object;


# static fields
.field public static final alpha:I = 0x7f0100b2

.field public static final coordinatorLayoutStyle:I = 0x7f010000

.field public static final font:I = 0x7f0100cc

.field public static final fontProviderAuthority:I = 0x7f0100c5

.field public static final fontProviderCerts:I = 0x7f0100c8

.field public static final fontProviderFetchStrategy:I = 0x7f0100c9

.field public static final fontProviderFetchTimeout:I = 0x7f0100ca

.field public static final fontProviderPackage:I = 0x7f0100c6

.field public static final fontProviderQuery:I = 0x7f0100c7

.field public static final fontStyle:I = 0x7f0100cb

.field public static final fontVariationSettings:I = 0x7f0100ce

.field public static final fontWeight:I = 0x7f0100cd

.field public static final keylines:I = 0x7f0100b5

.field public static final layout_anchor:I = 0x7f0100b8

.field public static final layout_anchorGravity:I = 0x7f0100ba

.field public static final layout_behavior:I = 0x7f0100b7

.field public static final layout_dodgeInsetEdges:I = 0x7f0100bc

.field public static final layout_insetEdge:I = 0x7f0100bb

.field public static final layout_keyline:I = 0x7f0100b9

.field public static final statusBarBackground:I = 0x7f0100b6

.field public static final ttcIndex:I = 0x7f0100cf


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
