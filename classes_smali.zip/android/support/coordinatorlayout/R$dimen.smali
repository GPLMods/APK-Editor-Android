.class public final Landroid/support/coordinatorlayout/R$dimen;
.super Ljava/lang/Object;


# static fields
.field public static final compat_button_inset_horizontal_material:I = 0x7f090052

.field public static final compat_button_inset_vertical_material:I = 0x7f090053

.field public static final compat_button_padding_horizontal_material:I = 0x7f090054

.field public static final compat_button_padding_vertical_material:I = 0x7f090055

.field public static final compat_control_corner_material:I = 0x7f090056

.field public static final compat_notification_large_icon_max_height:I = 0x7f090057

.field public static final compat_notification_large_icon_max_width:I = 0x7f090058

.field public static final notification_action_icon_size:I = 0x7f090062

.field public static final notification_action_text_size:I = 0x7f090063

.field public static final notification_big_circle_margin:I = 0x7f090064

.field public static final notification_content_margin_start:I = 0x7f090011

.field public static final notification_large_icon_height:I = 0x7f090065

.field public static final notification_large_icon_width:I = 0x7f090066

.field public static final notification_main_column_padding_top:I = 0x7f090012

.field public static final notification_media_narrow_margin:I = 0x7f090013

.field public static final notification_right_icon_size:I = 0x7f090067

.field public static final notification_right_side_padding_top:I = 0x7f09000f

.field public static final notification_small_icon_background_padding:I = 0x7f090068

.field public static final notification_small_icon_size_as_large:I = 0x7f090069

.field public static final notification_subtext_size:I = 0x7f09006a

.field public static final notification_top_pad:I = 0x7f09006b

.field public static final notification_top_pad_large_text:I = 0x7f09006c


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
