.class public final Landroid/support/mediacompat/R$style;
.super Ljava/lang/Object;


# static fields
.field public static final TextAppearance_Compat_Notification:I = 0x7f0a0077

.field public static final TextAppearance_Compat_Notification_Info:I = 0x7f0a0078

.field public static final TextAppearance_Compat_Notification_Info_Media:I = 0x7f0a0079

.field public static final TextAppearance_Compat_Notification_Line2:I = 0x7f0a0105

.field public static final TextAppearance_Compat_Notification_Line2_Media:I = 0x7f0a0106

.field public static final TextAppearance_Compat_Notification_Media:I = 0x7f0a007a

.field public static final TextAppearance_Compat_Notification_Time:I = 0x7f0a007b

.field public static final TextAppearance_Compat_Notification_Time_Media:I = 0x7f0a007c

.field public static final TextAppearance_Compat_Notification_Title:I = 0x7f0a007d

.field public static final TextAppearance_Compat_Notification_Title_Media:I = 0x7f0a007e

.field public static final Widget_Compat_NotificationActionContainer:I = 0x7f0a007f

.field public static final Widget_Compat_NotificationActionText:I = 0x7f0a0080


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
