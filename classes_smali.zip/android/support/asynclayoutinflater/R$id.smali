.class public final Landroid/support/asynclayoutinflater/R$id;
.super Ljava/lang/Object;


# static fields
.field public static final action_container:I = 0x7f0d01d4

.field public static final action_divider:I = 0x7f0d01db

.field public static final action_image:I = 0x7f0d01d5

.field public static final action_text:I = 0x7f0d01d6

.field public static final actions:I = 0x7f0d01e4

.field public static final async:I = 0x7f0d0032

.field public static final blocking:I = 0x7f0d0033

.field public static final chronometer:I = 0x7f0d01e0

.field public static final forever:I = 0x7f0d0034

.field public static final icon:I = 0x7f0d004c

.field public static final icon_group:I = 0x7f0d01e5

.field public static final info:I = 0x7f0d01e1

.field public static final italic:I = 0x7f0d0035

.field public static final line1:I = 0x7f0d0005

.field public static final line3:I = 0x7f0d0006

.field public static final normal:I = 0x7f0d0012

.field public static final notification_background:I = 0x7f0d01e3

.field public static final notification_main_column:I = 0x7f0d01dd

.field public static final notification_main_column_container:I = 0x7f0d01dc

.field public static final right_icon:I = 0x7f0d01e2

.field public static final right_side:I = 0x7f0d01de

.field public static final tag_transition_group:I = 0x7f0d000a

.field public static final tag_unhandled_key_event_manager:I = 0x7f0d000b

.field public static final tag_unhandled_key_listeners:I = 0x7f0d000c

.field public static final text:I = 0x7f0d000d

.field public static final text2:I = 0x7f0d000e

.field public static final time:I = 0x7f0d01df

.field public static final title:I = 0x7f0d000f


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
