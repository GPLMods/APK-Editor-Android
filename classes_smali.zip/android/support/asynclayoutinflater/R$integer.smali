.class public final Landroid/support/asynclayoutinflater/R$integer;
.super Ljava/lang/Object;


# static fields
.field public static final status_bar_notification_info_maxnum:I = 0x7f0e0004


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
