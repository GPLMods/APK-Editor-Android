.class public final Landroid/support/coreutils/R$color;
.super Ljava/lang/Object;


# static fields
.field public static final notification_action_color_filter:I = 0x7f0c0000

.field public static final notification_icon_bg_color:I = 0x7f0c0039

.field public static final ripple_material_light:I = 0x7f0c0046

.field public static final secondary_text_default_material_light:I = 0x7f0c0048


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
