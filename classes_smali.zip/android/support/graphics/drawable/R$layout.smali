.class public final Landroid/support/graphics/drawable/R$layout;
.super Ljava/lang/Object;


# static fields
.field public static final notification_action:I = 0x7f0300c0

.field public static final notification_action_tombstone:I = 0x7f0300c1

.field public static final notification_template_custom_big:I = 0x7f0300c8

.field public static final notification_template_icon_group:I = 0x7f0300c9

.field public static final notification_template_part_chronometer:I = 0x7f0300cd

.field public static final notification_template_part_time:I = 0x7f0300ce


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
